import { SearchIcon } from 'assets/svg';
import { windowWidth } from 'helpers/Constants';
import React from 'react';
import { View, TextInput, TouchableOpacity, StyleSheet } from 'react-native';

const CustomSearchBar = ({ value, onChange, onSearch }) => {
  return (
    <View style={styles.container}>
        <SearchIcon/>
      <TextInput
        style={styles.input}
        placeholder="Nhập nội dung cần tìm..."
        value={value}
        onChangeText={onChange}
      />
      <TouchableOpacity style={styles.button} onPress={onSearch}>
        {/* You can add a search icon or text here */}
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
    backgroundColor: '#FFFAEE',
    borderRadius: 15,
    borderWidth: 1, // You can adjust the border width as needed
    borderColor: '#DBA410', // You can adjust the border color as needed
    width: windowWidth - 300,
    marginLeft: 200
},
  input: {
    flex: 1,
    padding: 8,
  },
  button: {
    padding: 8,
  },
});

export default CustomSearchBar;
