import {ThongBaoIcon } from 'assets/svg';
import { Modal, StyleSheet, Text, View } from 'react-native';
import FastImageCustom from './FastImageCustom';
import { FontSize, dimensWidth } from 'helpers/Constants';
import TextCusTom from './TextCusTom';
import colors from 'helpers/Colors';
import React, { useCallback, useState } from 'react';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { useNavigation } from '@react-navigation/native';
import ThongBaoScreen from '../Screen/dashboard/thongbao/ThongBao.Screen';
import ModalProfile from '../Screen/dashboard/components/ModalProfile';

const HeaderWithAvatar: any = ({ children, urlOnline,notificationCount = '0', title, ...props}: any) => {
const navigation = useNavigation();  




const gotoThongBaoView = useCallback((item: any) => {
        navigation.navigate({
          name: "ThongBaoScreen",
         params: {item}
        })
      }, []);
      const[visibleModalProfile, setvisibleModalProfile] = useState(false);
      const [modalVisible, setModalVisible] = useState(false);
      
      const onReModalPress = useCallback(() => {
        setvisibleModalProfile(false);
      }, [modalVisible]);  
      
      const handleOpenNotifyView = () => {
        setModalVisible(true);
      };
    
      const handleCloseNotifyView = () => {
        setModalVisible(false);
      };


      const onPressProfile = useCallback(() =>
      {
        setvisibleModalProfile(true);
      },[visibleModalProfile])
      

    return (
        <View style={styles.container}>
            <Text style={styles.txtHeader}>Trang chủ</Text>
            <TextCusTom allowFontScaling={false} {...props} i18nKey={title} style={styles.textTitle} />
            <View style={styles.imgUser}>
                    <TouchableOpacity onPress={onPressProfile}>
                    <FastImageCustom  urlOnline={urlOnline} />
                    </TouchableOpacity>
                    </View>
            <View style={styles.viewRight}>
                    <TouchableOpacity onPress={handleOpenNotifyView}>
                    <>
                    <ThongBaoIcon />
                    <View style={styles.viewNotification}>
                        <TextCusTom i18nKey={notificationCount} style={styles.textNotification} />
                    </View>
                </>
                    </TouchableOpacity>
              
            </View>

            <Modal
        animationType="fade" // Cross-dissolve transition
        transparent={true}
        visible={modalVisible}
        onRequestClose={handleCloseNotifyView}
      >
        <ThongBaoScreen onCloseModal={handleCloseNotifyView} modalVisible={undefined} ActionJson={undefined} />
      </Modal>

      <ModalProfile
      onPressFilter={onPressProfile}
      confirmText={"Áp dụng"}
      refilterText={"Thiết lập lại"}
      modalVisible={visibleModalProfile}
      // onConfirmModal={confirmModalPress}
      onReFilterModal={onReModalPress}
      // onPressOpenCalendarPicker={onPressOpenCalendarPicker}
      // startDate={startDate}
      // endDate={endDate}
      // statusText={statusText}
      />

        </View>
    );
};
const styles = StyleSheet.create({
    container: { flexDirection: 'row', alignItems: 'center', padding: 20, backgroundColor: '#006885',height: 100 },
    textTitle: { fontSize: FontSize.LARGE_X, fontWeight: '700', color: colors.DarkCyan },
    viewRight: { flex: 1, position: 'absolute', right: 130 },
    viewNotification: { backgroundColor: colors.red, height: 20, 
        width: 20, borderRadius: 10, position: 'absolute', 
        right: -7, top: -5, 
        justifyContent: 'center', alignItems: 'center' },
    imgUser: {
        position:'absolute',
        right: -40,
        top: 20,
    },
    textNotification: { color: colors.white, fontSize: 12, },
    txtHeader: {
        fontSize: 30,
        fontWeight: '600',
        color:'white'
    }
});
export default React.memo(HeaderWithAvatar);
