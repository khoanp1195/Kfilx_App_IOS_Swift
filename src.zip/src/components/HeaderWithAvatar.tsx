import { ThongBaoIcon } from 'assets/svg';
import { Animated, Image, Modal, StyleSheet, Text, View } from 'react-native';
import FastImageCustom from './FastImageCustom';
import { FontSize, dimensWidth } from 'helpers/Constants';
import TextCusTom from './TextCusTom';
import colors from 'helpers/Colors';
import React, { useCallback, useRef, useState } from 'react';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { useNavigation } from '@react-navigation/native';
import ThongBaoScreen from '../Screen/dashboard/thongbao/ThongBao.Screen';
import ModalProfile from '../Screen/dashboard/components/ModalProfile';
import { transform } from 'typescript';
import FastImage from 'react-native-fast-image';


const HeaderWithAvatar: any = ({ item, 
  children, urlOnline,
   notificationCount = '0', 
   title, isCategory, isClickLeftMenu,
   dataSubCategory,
   id,
   dataCategory,
   isFavorite,
   filteredCategories,...props }: any) => {
  const navigation = useNavigation();
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleValue = useRef(new Animated.Value(0)).current

  const handleOpenNotifyView = () => {
    Animated.timing(fadeAnim, {
      toValue: 0.5,
      duration: 5000,
      useNativeDriver: true,
    }).start();
    // setModalVisible(true);
    navigation.navigate('ThongBaoScreen', { title: 'Your Title' });
  };
  console.log('item - profile here = >> ' + item)

  const gotoThongBaoView = useCallback((item: any) => {
    navigation.navigate({
      name: "ThongBaoScreen",
      params: { item }
    })
  }, []);
  const [visibleModalProfile, setvisibleModalProfile] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);

  const onReModalPress = useCallback(() => {
    setvisibleModalProfile(false);
  }, [modalVisible]);


  const handleCloseNotifyView = () => {
    setModalVisible(false);
  };


  const onPressProfile = useCallback(() => {
    // setVisible(true)
    setvisibleModalProfile(true);
  }, [visibleModalProfile])

  const onGoBack = useCallback(() => {
    navigation.goBack();
  }, [navigation]);


  console.log("dataSubCategory in HeaderWithAvatar = >>> " + dataSubCategory)

  //gotoDetailPress
  const gotoDetailPress = useCallback(
    (item: any) => {
    //  const cateParentID = item?.ID
    //  const filteredCategories = dataSubCategory.filter((category: { ParentId: null; }) => category.ParentId === cateParentID);    
    //   // Sort the filtered list by Rank
    //   filteredCategories.sort(({a, b} : any) => a?.Rank - b?.Rank);
      
    if (isFavorite)
    {
      navigation.navigate({
        name: "DoucumentFavoriteListView",
        params: { id: id, 
          titleChild: item?.Title,
          parenttitle: title,
          item: item,
          filteredCategories,
          titleChild: item?.Title,
          isClickLeftMenu: false,
          isFirst: true,
          dataCategory:dataCategory },
      });
    }
    else
    {
      navigation.navigate({
        name: "DoucumentListView",
        params: { id: id, 
          titleChild: item?.Title,
          parenttitle: title,
          item: item,
          filteredCategories,
          titleChild: item?.Title,
          isClickLeftMenu: false,
          isFirst: true,
          dataCategory:dataCategory },
      });
    }
 
    },
    [],
  )
  return (
    <View style={styles.container}>
      {isCategory && (
        <TouchableOpacity  onPress={isClickLeftMenu ? () => gotoDetailPress(dataSubCategory) : onGoBack} style={{ marginTop: 20 }}>
          <FastImage
            style={styles.icon_back}
            resizeMode='contain'
            source={require('../assets/images/icon_back.png')}
          />
        </TouchableOpacity>
      )}
      <Text style={styles.txtHeader}>{title}</Text>

      <TextCusTom allowFontScaling={false} {...props} i18nKey={title} style={styles.textTitle} />


      <View style={styles.imgUser}>
        <TouchableOpacity onPress={onPressProfile}>
          <FastImageCustom urlOnline={urlOnline} />
        </TouchableOpacity>
      </View>
      <View style={styles.viewRight}>
        <TouchableOpacity onPress={handleOpenNotifyView}>
          <>
            <ThongBaoIcon />

            {notificationCount > 0 ? (
              <View style={styles.viewNotification}>
                <TextCusTom i18nKey={notificationCount} style={styles.textNotification} />
              </View>
            ) : null}
          </>
        </TouchableOpacity>

      </View>

      {/* <Modal
        animationType="fade" // Cross-dissolve transition
        transparent={true}
        visible={modalVisible}
        onRequestClose={handleCloseNotifyView}
      >



        <ThongBaoScreen onCloseModal={handleCloseNotifyView} modalVisible={undefined} ActionJson={undefined} />
      </Modal> */}


      <ModalProfile
        onPressFilter={onPressProfile}
        modalVisible={visibleModalProfile}
        onReFilterModal={onReModalPress}
        item={item}
        
      />


    </View>
  );
};
const styles = StyleSheet.create({
  container: { 
    flexDirection: 'row', 
  alignItems: 'center',
   padding: 20,
   backgroundColor: '#006885', 
   height: 120
   },
  textTitle: { fontSize: FontSize.LARGE_X, fontWeight: '700', color: colors.DarkCyan },
  viewRight: {
    flex: 1,
    position: 'absolute',
    right: 100,
    top: 50
  },
  icon_back: {
    height: dimensWidth(15),
    width: dimensWidth(15),
    marginRight: dimensWidth(10),
    borderRadius: dimensWidth(20),
  },
  viewNotification: {
    backgroundColor: colors.red,
    height: 20,
    width: 20,
    borderRadius: 10,
    position: 'absolute',
    right: -7, top: -5,
    justifyContent: 'center', alignItems: 'center'
  },
  imgUser: {
    position: 'absolute',
    right: -40,
    top: 40,
  },
  textNotification: { color: colors.white, fontSize: 12, },
  txtHeader: {
    fontSize: 30,
    fontWeight: '600',
    color: 'white',
    top: 12,
    fontFamily: 'Heritage Sans',

  },
  modalBackGround: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    width: '60%',
    backgroundColor: 'white',
    paddingHorizontal: 20,
    paddingVertical: 390,
    borderRadius: 20,
    elevation: 20,
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    height: 100
  },
});
export default React.memo(HeaderWithAvatar);
