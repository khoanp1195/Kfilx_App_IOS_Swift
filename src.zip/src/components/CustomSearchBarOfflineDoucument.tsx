import { SearchIcon } from 'assets/svg';
import { windowWidth } from 'helpers/Constants';
import React from 'react';
import { View, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { useSelector } from 'react-redux';
import { RootState } from 'stories/index';

const CustomSearchBarOfflineDoucument = ({ value, onChange, onSearch }) => {
    const { languages, languagesText } = useSelector((state: RootState) => state.languages);
    return (
    <View style={styles.container}>
        <SearchIcon/>
      <TextInput
        style={styles.input}
        placeholder={languages.search_hint}
        value={value}
        onChangeText={onChange}
      />
      <TouchableOpacity style={styles.button} onPress={onSearch}>
        {/* You can add a search icon or text here */}
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
    backgroundColor: '#FFFAEE',
    borderRadius: 15,
    borderWidth: 1, // You can adjust the border width as needed
    borderColor: '#DBA410', // You can adjust the border color as needed
    width: windowWidth - 60,
    marginLeft: 30
},
  input: {
    flex: 1,
    padding: 8,
  },
  button: {
    padding: 8,
  },
});

export default CustomSearchBarOfflineDoucument;
