import {StyleSheet, View, Text, TouchableOpacity} from 'react-native';
import React, {FC} from 'react';
import { FontFamily,dimensWidth, dimnensHeight } from 'helpers/Constants';
import colors from 'helpers/Colors';
const ButtonCusTom: any = ({children,i18nKey,borderColorCustom= colors.white, bgColorCustom = colors.orange,colorCustom =colors.white,...props}: any) => {

  return (
   <TouchableOpacity style={[styles.container,{ backgroundColor: bgColorCustom, borderColor: borderColorCustom,}]} {...props}>
     <Text allowFontScaling={false} style={{color:colorCustom,fontFamily: FontFamily.HERITAGE_REGULAR, lineHeight:18}} >
      {i18nKey}
    </Text>
   </TouchableOpacity>
  );
};
 const styles = StyleSheet.create({
  container: {
    height: dimnensHeight(42),
    width: dimensWidth(150),
    margin:10,
    borderRadius:5,
    justifyContent: 'center',
    alignItems:'center',
    borderWidth:1,
    zIndex: 1, // Set the zIndex of this view
    position: 'absolute', // Position this view
    bottom: 220,

   }
  })
export default React.memo(ButtonCusTom);
