import { ThongBaoIcon } from 'assets/svg';
import { Modal, StyleSheet, Switch, Text, View } from 'react-native';
import FastImageCustom from './FastImageCustom';
import { FontSize, dimensWidth } from 'helpers/Constants';
import TextCusTom from './TextCusTom';
import colors from 'helpers/Colors';
import React, { useCallback, useState } from 'react';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { useNavigation } from '@react-navigation/native';
import ThongBaoScreen from '../Screen/dashboard/thongbao/ThongBao.Screen';
import ModalProfile from '../Screen/dashboard/components/ModalProfile';
import FastImage from 'react-native-fast-image';

const HeaderDetail: any = ({ item, children, urlOnline, notificationCount = '0', title,isThongBao, ...props }: any) => {
    const navigation = useNavigation();
    const onGoBack = useCallback(() => {
        if (isThongBao) {
          // Navigate back to the "ThongBaoScreen" without reloading
         navigation.navigate('ThongBaoScreen', { title: 'Your Title' });
        } else {
          // Navigate back to the previous screen
          navigation.goBack();
        }
      }, [navigation, isThongBao]);
    const [isEnabled, setIsEnabled] = useState(false);
    const toggleSwitch = () => setIsEnabled(previousState => !previousState);

    console.log("isThongBao from header => " + isThongBao)
    console.log('item - profile here = >> ' + item)
    return (
        <View style={styles.container} >
            <TouchableOpacity onPress={onGoBack} style={{marginTop: 20}}>
                <FastImage
                    style={styles.icon_back}
                    resizeMode='contain'
                    source={require('../assets/images/icon_back.png')}
                />
            </TouchableOpacity>
            <Text style={styles.txtHeader}>Loại văn bản</Text>
          <View style={styles.view_switch}>
          <Switch
                trackColor={{ false: 'lightgray', true: '#f5dd4b' }}
                thumbColor='white'
                ios_backgroundColor="#3e3e3e"
                onValueChange={toggleSwitch}
                value={isEnabled}
            />
          </View>

        </View>
    );
};
const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 20,
        backgroundColor: '#006885',
        height: 100
    },
    textTitle: { fontSize: FontSize.LARGE_X, fontWeight: '700', color: colors.DarkCyan },
    viewRight: { flex: 1, position: 'absolute', right: 130 },
    viewNotification: {
        backgroundColor: colors.red,
        height: 20,
        width: 20,
        borderRadius: 10,
        position: 'absolute',
        right: -7, top: -5,
        justifyContent: 'center', alignItems: 'center'
    },
    imgUser: {
        position: 'absolute',
        right: -40,
        top: 20,
    },
    textNotification: { color: colors.white, fontSize: 12, },
    txtHeader: {
        fontSize: 20,
        fontWeight: '600',
        color: 'white',
        marginLeft: -25,
        marginTop: 20
    },
    icon_back: {
        height: dimensWidth(15),
        width: dimensWidth(15),
        marginRight: dimensWidth(20),
        borderRadius: dimensWidth(20),
    },
    view_switch:{
        flex: 1, position: 'absolute', right: 20,
        Top: 30
    }
});
export default React.memo(HeaderDetail);
