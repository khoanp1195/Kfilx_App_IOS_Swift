import React, {FC} from 'react';
import {
  ImageBackground,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {FontSize} from 'helpers/Constants';
import colors from '../helpers/Colors';

interface Props {
  onRetryPress?: () => any;
}

const NoDataView: FC<Props> = (props: Props) => {
  return (
    <View style={styles.container}>
          <ImageBackground
    resizeMode='contain'
      style={styles.viewNoData}
      source={require('../assets/images/icon_noDocument.png')}>
      <Text style={styles.textNoData}>Không có dữ liệu</Text>
    </ImageBackground>
    </View>

  );
};

const styles = StyleSheet.create({
  container:{
    flex:1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  viewNoData: {
    alignItems: 'center',
    height: 300,
    width:300,
    justifyContent: 'center',
  },
  textNoData: {
    fontSize: 15,
    color: '#006885',
    marginTop: 230,
  },
});

export default React.memo(NoDataView);
