import React, {FC} from 'react';
import {StyleSheet} from 'react-native';
import {dimensWidth} from 'helpers/Constants';
import FastImage from 'react-native-fast-image';
import {RootState} from '../stories';
import {useSelector} from 'react-redux';

interface Props {
  onRetryPress?: () => any;
  urlOnline: string;
  priority?: any;
  resizeMode?: any;
  styleImg?: any;
}

const FastImageCustom: FC<Props> = (props: Props) => {
  const {token} = useSelector((state: RootState) => state.login);
  const {urlOnline = '', resizeMode, priority, styleImg = {}} = props;
  return (
    <FastImage
      style={[styles.container, styleImg]}
      source={{
        uri: urlOnline,
        headers: {Authorization: `${token}`},
        priority: priority ? priority : FastImage.priority.normal,
      }}
      defaultSource={require('../assets/images/img_avatar_grey.png')}
      resizeMode={resizeMode ? resizeMode : FastImage.resizeMode.cover}
    />
  );
};

const styles = StyleSheet.create({
  container: {
    height: dimensWidth(15),
    width: dimensWidth(15),
    marginRight: dimensWidth(20),
    borderRadius: dimensWidth(20),
    
  },
});

export default React.memo(FastImageCustom);
