export default {
  UseName: "Login",
  Register: "Register",
  placeHolderUseName: "Use Account",
  placeHolderPassword: "Password",
  HaveNoAccount: "You don’t have an account?",
  incorrect_login: "Login information is incorrect, please try again!",
  hello: "Hello",
  welcome: "Welcome to My App",
};
