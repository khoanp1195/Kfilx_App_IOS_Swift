export default {
  UseName: "Đăng nhập",
  Register: "Đăng ký",
  placeHolderUseName: "Tên đăng nhập",
  placeHolderPassword: "Mật khẩu",
  HaveNoAccount: "Bạn không có mật khẩu?",
  incorrect_login: "Thông tin đăng nhập không chính xác, vui lòng thử lại!",
  hello: "Xin chao",
  welcome: "Xin chao toi ung dung cua toi",
};
