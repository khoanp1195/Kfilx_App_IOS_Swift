import {Dimensions, StyleSheet} from 'react-native';
import {FontFamily, FontSize, dimensWidth, windowHeight, windowWidth} from 'helpers/Constants';
import colors from 'helpers/Colors';
const window = Dimensions.get('window');
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  text: {
    fontSize: FontSize.MEDIUM,
  },
  bg_login: {
    alignItems: 'center',
    width: windowWidth,
    height: windowHeight,
    backgroundColor: 'white',
    justifyContent:  'center'
  },
  logoPetrolimex: {
    marginBottom: 80,
    marginTop: 80,
    resizeMode: 'cover',
  },
  containerTextInput: {
    flexDirection: 'row',
    alignItems: 'center',
    height: dimensWidth(20),
    width: dimensWidth(150),
    backgroundColor: '#fff',
    borderColor: '#E5E5E5',
    paddingLeft: 18,
    borderRadius: 10,
    borderWidth:1,
    marginTop: 40,
    paddingRight: 10,
    zIndex: 1, // Set the zIndex of this view
    position: 'absolute', // Position this view
    // top: 410

  },
  containerTextInputPassword: {
    flexDirection: 'row',
    alignItems: 'center',
    height: dimensWidth(20),
    width: dimensWidth(150),
    backgroundColor: '#fff',
    borderColor: '#E5E5E5',
    paddingLeft: 18,
    borderRadius: 10,
    borderWidth:1,
    marginTop: 40,
    paddingRight: 10,
    zIndex: 1, // Set the zIndex of this view
    position: 'absolute', // Position this view
     top: 420

  },
  userNameInput: {
    paddingHorizontal: 10,
    flex: 1,
    

  },
  textWarning: {
    marginHorizontal:80,
    fontSize: 16,
    marginVertical: 10,
    color: colors.red,
    fontFamily: FontFamily.HERITAGE_REGULAR,
    textAlign: 'center'
  },
  textHaveNoAccount: {
    fontSize: 16,
    marginVertical: 10,
    color: colors.text_grey26,
    fontFamily: FontFamily.HERITAGE_REGULAR,
  },
  vnaImage:{
    height:35,
    width:310,
    position:'absolute',
    right: 50,
    bottom: 50,
    zIndex: 1, 
  },
  vnaBackgroundImage: {
    height:window.height,
    marginTop: -70,
    width:(window.width),
  }
});
export default styles;
