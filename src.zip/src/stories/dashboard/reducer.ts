
import {createSlice, createAsyncThunk} from '@reduxjs/toolkit';
import {get} from '../../services/ApiServices';
import {RESONSE_STATUS_SUCCESS} from 'helpers/Constants';
import {BASE_URL} from 'helpers/Constants';
import {isNullOrUndefined} from 'helpers/Functions';
import axios from 'axios';

export const getUnReadNotify = createAsyncThunk(
  'dashboard/getUnReadNotify',
  async () => {
    const res = await get(
      `/psd/API/ApiMobile.ashx?func=GetUnReadNotify&Params=Offset%2CLimit%2CisCount&Offset=0&Limit=0&isCount=1`,
    );
    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data;
      }
    }

    return null;
  },
);

//getDocumentMostView
export const getDocumentMostView = createAsyncThunk(
  'dashboard/getDocumentDocView',
  async(LangId: number) => {
      const res = await get (
        `/psd/API/ApiMobile.ashx?func=GetDocumentMostView&LangId=${LangId}&Params=LangId%2CCategoryId%2COffset%2CLimit&CategoryId=5&Offset=0&Limit=5`,
        );

        console.log('getDocumentMostView =>>> '  + res)
      if(!isNullOrUndefined(res)){
        if(res.data.status === RESONSE_STATUS_SUCCESS)
        {
          return res.data.data;
        }
      }
      return null;
  }
)

//getViewDocumentNew
export const getViewDocumentNew = createAsyncThunk(
  'dashboard/getViewDocumentNew',
  async(LangId: number) => {
    const res = await get (
      `/psd/API/ApiMobile.ashx?func=GetViewDocumentNew&LangId=${LangId}&Params=LangId%2COffset%2CLimit&Offset=0&Limit=5`,
    );
    if(!isNullOrUndefined(res)){
      if(res.data.status === RESONSE_STATUS_SUCCESS)
      {
        return res.data.data;
      }
    }
    return null;
  }
)

//GetListDoucumentFavorite
export const GetListDoucumentFavorite = createAsyncThunk(
  'dashboard/getDocumentFavorite',
  async (payload: any) => {
    const { limit, offset } = payload;
    const LangId = 1066;
    const Params = {
      Offset: 0,
      Limit: 5,
      LangId: LangId
    };
    console.log('Params', Params);
    try {
      let responseGetListDoucumentFavorite = null;
      const url =`https://vnadmsuatportal.vuthao.com/psd/API/ApiMobile.ashx?func=GetDocumentFavorite&LangId=${LangId}&Params=Offset%2CLimit&Offset=0&Limit=5`;
     console.log("url =>>> " + url)
      try{
        const response = await axios.get(url, {
          headers: {
            'Content-Type': 'application/json', // Adjust the content type as needed
          },
        });
        if (response?.status === 200) {
          responseGetListDoucumentFavorite = response?.data?.data?.Data;
          console.log('responseGetListDoucumentFavorite day nha : =>> ' + responseGetListDoucumentFavorite);
        } else {
          console.error('Load Data Failed:');
        }
        return {
          dataDocumentFavorite: response?.data?.data?.Data,
        };

      }catch(ex)
      {
        console.error('Error in GET request:', ex);
      }
      console.log('fetchGetListNotify =>>> ', responseGetListDoucumentFavorite);
      return null; // Return null if no response or status is not successful
    } catch (error) {
      console.error('Error fetching data:', error);
      throw error; // You might want to handle or log the error accordingly
    }
  }
);

//GetListNotify
export const GetListNotify = createAsyncThunk(
  'dashboard/GetListNotify',
  async (payload: any) => {
    const { limit, offset } = payload;
    const LangId = 1066;
    const Params = {
      Offset: 0,
      Limit: 5,
      LangId: LangId
    };
    console.log('Params', Params);
    try {
      let responseGetNotifyDocument = null;
      const url =`https://vnadmsuatportal.vuthao.com/psd/API/ApiMobile.ashx?func=GetTopNotify&LangId=${LangId}&Params=LangId%2COffset%2CLimit&Limit=${100}&Offset=0`;
     console.log("url =>>> " + url)
      try{
        const response = await axios.get(url, {
          headers: {
            'Content-Type': 'application/json', // Adjust the content type as needed
          },
        });
        if (response?.status === 200) {
          responseGetNotifyDocument = response?.data?.data?.Data;
          console.log('fetchGetListNotify day nha : =>> ' + responseGetNotifyDocument);
        } else {
          console.error('Load Data Failed:');
        }
        return {
          dataListNotify: response?.data?.data?.Data,
        };

      }catch(ex)
      {
        console.error('Error in GET request:', ex);
      }
      console.log('fetchGetListNotify =>>> ', responseGetNotifyDocument);
      return null; // Return null if no response or status is not successful
    } catch (error) {
      console.error('Error fetching data:', error);
      throw error; // You might want to handle or log the error accordingly
    }
  }
);

//GetListUnreadNotify
export const GetListUnreadNotify = createAsyncThunk(
  'dashboard/GetListUnreadNotify',
  async (payload: any) => {
    const { limit, offset,isCount } = payload;
    const LangId = 1066;
    const Params = {
      Offset: 0,
      Limit: 100,
      isCount: 0,
    };
    console.log('Params', Params);
    try {
      let responseGetListUnreadNotify = null;
      const url =`https://vnadmsuatportal.vuthao.com/psd/API/ApiMobile.ashx?func=GetUnReadNotify&Params=Offset%2CLimit%2CisCount&Limit=${100}&Offset=0&isCount=0`;
     console.log("url  GetListUnreadNotify =>>> " + url)
      try{
        const response = await axios.get(url, {
          headers: {
            'Content-Type': 'application/json',
          },
        });
        if (response?.status === 200) {
          responseGetListUnreadNotify = response?.data?.data?.Data;
          console.log('fetchGetListNotify day nha : =>> ' + responseGetListUnreadNotify);
        } else {
          console.error('Load Data Failed:');
        }
        return {
          dataListUnreadNotify : response?.data?.data?.Data,
        };

      }catch(ex)
      {
        console.error('Error in GET request:', ex);
      }
      console.log('GetListUnreadNotify =>>> ', responseGetListUnreadNotify);
      return null;
    } catch (error) {
      console.error('Error fetching data:', error);
      throw error;
    }
  }
);
//https://vnadmsuatportal.vuthao.com/psd/API/ApiMobile.ashx?func=GetUnReadNotify&Params=Offset%2CLimit%2CisCount&Offset=0&Limit=20&isCount=0


//fetchGetNewDocument
// export const fetchGetNewDocument = createAsyncThunk(
//   'dashboard/fetchGetNewDocument',
//   async (payload: any) => {
//     const { limit, offset } = payload;
//     const LangId = 1066;
//     const Params = {
//       Offset: 0,
//       Limit: 5,
//       LangId: LangId
//     };
//     console.log('Params', Params);
//     try {
//       let responseGetnewDocument = null;
//       const url =`https://vnadmsuatportal.vuthao.com/psd/API/ApiMobile.ashx?func=GetViewDocumentNew&LangId=${LangId}&Params=LangId%2COffset%2CLimit&Limit=${5}&Offset=0`;
//      console.log("url =>>> " + url)
//       try{
//         const response = await axios.get(url, {
//           headers: {
//             'Content-Type': 'application/json', // Adjust the content type as needed
//           },
//         });
//         if (response?.status === 200) {
//           responseGetnewDocument = response?.data.data;
//           console.log('responseGetnewDocument day nha : =>> ' + responseGetnewDocument);
//         } else {
//           console.error('Load Data Failed:');
//         }
//         return {
//           dataNewDocument: response?.data.data,
//         };

//       }catch(ex)
//       {
//         console.error('Error in GET request:', ex);
//       }
//       console.log('responseGetnewDocument =>>> ', responseGetnewDocument);
//       if (!isNullOrUndefined(responseGetnewDocument)) {
//         if (responseGetnewDocument.data.status === RESONSE_STATUS_SUCCESS) {
//           return responseGetnewDocument.data.data;
//         }
//       }
//       return null; // Return null if no response or status is not successful
//     } catch (error) {
//       console.error('Error fetching data:', error);
//       throw error; // You might want to handle or log the error accordingly
//     }
//   }
// );

//fetchGetNewDocument
export const GetNewDocument = createAsyncThunk(
  'dashboard/GetNewDocument',
  async (payload: any) => {
    const { limit, offset } = payload;
    const LangId = 1066;
    const Params = {
      Offset: 0,
      Limit: 5,
      LangId: LangId
    };
    console.log('Params', Params);
    try {
      let responseGetnewDocument = null;
      const url =`https://vnadmsuatportal.vuthao.com/psd/API/ApiMobile.ashx?func=GetViewDocumentNew&LangId=${LangId}&Params=LangId%2COffset%2CLimit&Limit=${5}&Offset=0`;
     console.log("url =>>> " + url)
      try{
        const response = await axios.get(url, {
          headers: {
            'Content-Type': 'application/json', // Adjust the content type as needed
          },
        });
        if (response?.status === 200) {
          responseGetnewDocument = response?.data.data;
          console.log('responseGetnewDocument day nha : =>> ' + responseGetnewDocument);
        } else {
          console.error('Load Data Failed:');
        }
        return {
          dataNewDocument: response?.data.data,
        };

      }catch(ex)
      {
        console.error('Error in GET request:', ex);
      }
      console.log('responseGetnewDocument =>>> ', responseGetnewDocument);
      if (!isNullOrUndefined(responseGetnewDocument)) {
        if (responseGetnewDocument.data.status === RESONSE_STATUS_SUCCESS) {
          return responseGetnewDocument.data.data;
        }
      }
      return null; // Return null if no response or status is not successful
    } catch (error) {
      console.error('Error fetching data:', error);
      throw error; // You might want to handle or log the error accordingly
    }
  }
);

//getAutoLoginMobile
export const getAutoLoginMobile = createAsyncThunk(
  'dashboard/getAutoLoginMobile',
  async () => {
    const res = await get(
      `https://vnadmsuatportal.vuthao.com/psd/API/User.ashx?func=mobileAutoLoginWeb`,
    );

    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return {
          DATAautoId: res?.data?.data,
        };
      }
    }

    return null;
  },
);

//GetCurrentUsers
export const fetchCurrentUsers = createAsyncThunk(
  'dashboard/fetchCurrentUsers',
  async () => {
    try {
      const url =`https://vnadmsuatportal.vuthao.com/psd/API/ApiMobile.ashx?func=CurrentUser`;
      console.log("url =>>> " + url)
        const response = await axios.get(url, {
          headers: {
            'Content-Type': 'application/json', // Adjust the content type as needed
          },
        });
        return {
          dataCurrentUsers: response?.data?.data[0],
        };
    
    } catch (error) {
      console.error('Error fetching data:', error);
      throw error;
    }
  }
);



//Get Interactive Doucuments
export const GetInteractDocument = createAsyncThunk(
  'dashboard/GetInteractDocument',
  async (payload: any) => {
    const { limit, offset } = payload;
    const LangId = 1066;
    const Params = {
      Offset: 0,
      Limit: 100,
      LangId: LangId
    };
    console.log('Params', Params);
    try {
      let responseGetInteractDocument = null;
      const url =`https://vnadmsuatportal.vuthao.com/psd/API/ApiMobile.ashx?func=GetInteractiveDocument&LangId=${LangId}&Params=LangId%2COffset%2CLimit&Limit=${100}&Offset=0`;
     console.log("url =>>> " + url)
      try{
        const response = await axios.get(url, {
          headers: {
            'Content-Type': 'application/json', // Adjust the content type as needed
          },
        });
        if (response?.status === 200) {
          responseGetInteractDocument = response?.data.data.Data;
          console.log('responseGetInteractDocument day nha : =>> ' + responseGetInteractDocument);
        } else {
          console.error('Load Data Failed:');
        }
        return {
          dataListInteractDocument: response?.data.data.Data,
        };

      }catch(ex)
      {
        console.error('Error in GET request:', ex);
      }
      console.log('responseGetInteractDocument =>>> ', responseGetInteractDocument);
      if (!isNullOrUndefined(responseGetInteractDocument)) {
        if (responseGetInteractDocument.data.status === RESONSE_STATUS_SUCCESS) {
          return responseGetInteractDocument.data.data.Data;
        }
      }
      return null; // Return null if no response or status is not successful
    } catch (error) {
      console.error('Error fetching data:', error);
      throw error; // You might want to handle or log the error accordingly
    }
  }
);



//GetListCommentDocument
export const GetListCommentDocument = createAsyncThunk(
  'home/GetListCommentDocument',
  async (payload: any) => {
    const { limit, offset } = payload;
    const LangId = 1066;
    const Params = {
      Offset: 0,
      Limit: 100,
    };
    try {
      let data = new FormData();
      const jsonData = {
        Parameters: {
          CommentTitle: null,
          CommentStorageCode: null,
          CommentVersion:null,
          CommentDate:null,
          CommentIsApproved: null,
          CommentStatus: null
        }
      };
    //https://vnadmsuatportal.vuthao.com/psd/API/ApiMobile.ashx?func=GetCommentByUser&Params=Offset%2CLimit&Offset=0&Limit=20&enc=RSA
      data.append("data", JSON.stringify(jsonData));
      let config = {
          method: 'post',
          url: `https://vnadmsuatportal.vuthao.com/psd/API/ApiMobile.ashx?func=GetCommentByUser&Params=Offset%2CLimit&Offset=0&Limit=100`,
          data: data,
          headers: {
              'Accept': 'application/json',
              'Content-Type': 'multipart/form-data',
          },
      };
      const response = await axios(config);
      console.log('responseGetListCommentDocument', response?.data);

      return {
        dataListComment: response?.data?.data?.Data,
      }
    } catch (ex) {
      console.error('Error in fetchGetWorkflowItem:', ex);
    }
  }
)



export const logout = createAsyncThunk(
  'login/logout',
  async () => {
    try {
      const url = `https://vnadmsuatportal.vuthao.com/psd/api/ApiMobile.ashx?func=SignOut&Params=DeviceId`;
      console.log("dashboard/logout =>>  =>>> " + url)
        const response = await axios.get(url, {
          headers: {
            'Content-Type': 'application/json', // Adjust the content type as needed
          },
        });
        return response      
    } catch (error) {
      console.error('Error fetching data:', error);
      throw error;
    }
  }
);


const dashBoardSlice = createSlice({
  name: 'dashboard',
  initialState: {
    isLoadingListNotify: false,
    dashboardCountData: 0,
    isLoading: false,
    totalRecord: 0,
    dataNewDocument:[],
    dataDocumentFavorite:[],
    dataDocumentMostView:[],
    dataListNotify:[],
    dataListUnreadNotify:[],
    dataCurrentUsers: [],
    DATAautoId: '',
    recentlyViewedDocs: [],
    dataListInteractDocument:[],
    dataListComment:[],

    token: '',
    isLogging: false,
    isAuth: false,
    isLogin: false,
  },
  reducers: {

    syncFormDashboardAction(state, action) {
      console.log('syncFormDashboardActionnnn:', action.payload);

      return {
        ...state,
        dataNewDocument: action.payload.dataNewDocument,
        notificationCount: action.payload.notificationCount,
        recentlyViewedDocs: action.payload.recentlyViewedDocs,
        dataDocumentMostView: action.payload.dataDocumentMostView,
        dataDocumentFavorite: action.payload.dataDocumentFavorite
      };
    },

    
    SetisLoadingListNotify(state,action){
      return {
        ...state,
        isLoadingListNotify: action.payload
      }
    },   
    logoutAction(state, action)
    {
        state.isLogin = false;
        state.isAuth = false
        state.token = '';
        state.isLogging = false
    }
  },
  extraReducers: builder => {
    builder.addCase(getUnReadNotify.fulfilled, (state: any, action) => {
      state.dashboardCountData = action.payload;
    });
    builder.addCase(getViewDocumentNew.fulfilled, (state: any, action) => {
      state.dataNewDocument = action.payload;
    });
    builder.addCase(getDocumentMostView.fulfilled,(state: any, action) =>{
      state.dataDocumentMostView = action.payload
    });
    builder.addCase(GetListDoucumentFavorite.fulfilled,(state: any, action) => {
      state.dataDocumentFavorite = action.payload?.dataDocumentFavorite
    });
    builder.addCase(GetListNotify.pending, (state) => {
      state.isLoadingListNotify = true;
    })
    builder.addCase(GetListNotify.fulfilled, (state: any, action) => {
      state.dataListNotify = action.payload?.dataListNotify
      state.isLoadingListNotify = false;
    });
    builder.addCase(GetListUnreadNotify.fulfilled, (state: any, action) => {
      state.dataListUnreadNotify = action.payload?.dataListUnreadNotify
    });
    builder.addCase(getAutoLoginMobile.fulfilled, (state: any, action) => {
      state.autoId = action.payload?.DATAautoId;
    });
    builder.addCase(fetchCurrentUsers.fulfilled, (state: any, action) => {
      state.dataCurrentUsers = action.payload?.dataCurrentUsers;
    });
    builder.addCase(GetInteractDocument.fulfilled, (state: any, action) => {
      state.dataListInteractDocument = action.payload?.dataListInteractDocument;
    });
    builder.addCase(GetListCommentDocument.fulfilled, (state: any, action) => {
      state.dataListComment = action.payload?.dataListComment;
    });
  },
});
export const {logoutAction, SetisLoadingListNotify } = dashBoardSlice.actions;
const {reducer} = dashBoardSlice;
export default reducer;
