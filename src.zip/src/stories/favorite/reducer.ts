
import {createSlice, createAsyncThunk} from '@reduxjs/toolkit';
import {get} from '../../services/ApiServices';
import {RESONSE_STATUS_SUCCESS} from 'helpers/Constants';
import {BASE_URL} from 'helpers/Constants';
import {isNullOrUndefined} from 'helpers/Functions';
import axios from 'axios';


//GetCategoryFromServer
export const GetFavoriteFromServer = createAsyncThunk(
    'dashboard/GetFavoriteFromServer',
    async () => {
      try {
        let responseFavoriteFolder = null;
        const url =`https://vnadmsuatportal.vuthao.com/psd/api/ApiMobile.ashx?func=Get&BeanName=FavoriteFolder`;
       console.log("url =>>> " + url)
        try{
          const response = await axios.get(url, {
            headers: {
              'Content-Type': 'application/json', // Adjust the content type as needed
            },
          });
          if (response?.status === 200) {
            responseFavoriteFolder = response?.data.data.FavoriteFolder;
            console.log('responseFavoriteFolder day nha : =>> ' + responseFavoriteFolder);
          } else {
            console.error('Load Data Failed:');
          }
          return {
            dataFavoriteFolder: response?.data.data.FavoriteFolder,
          };
  
        }catch(ex)
        {
          console.error('Error in GET request:', ex);
        }
        console.log('responseFavoriteFolder =>>> ', responseFavoriteFolder);
        if (!isNullOrUndefined(responseFavoriteFolder)) {
          if (responseFavoriteFolder.data.status === RESONSE_STATUS_SUCCESS) {
            return responseFavoriteFolder.data.data.FavoriteFolder;
          }
        }
        return null;
      } catch (error) {
        console.error('Error fetching data:', error);
        throw error;
      }
    }
  );


const favoritesSlice = createSlice({
  name: 'dashboard',
  initialState: {
    isLoadingListNotify: false,
    isLoading: false,
    dataFavoriteFolder:[],
    DATAautoId: '',
  },
  reducers: { 
    SetisLoadingListNotify(state,action){
      return {
        ...state,
        isLoadingListNotify: action.payload
      }
    },   
  },
  extraReducers: builder => {
    builder.addCase(GetFavoriteFromServer.fulfilled, (state: any, action) => {
      state.dataFavoriteFolder = action.payload?.dataFavoriteFolder;
    });
  },
});
export const { SetisLoadingListNotify } = favoritesSlice.actions;
const {reducer} = favoritesSlice;
export default reducer;
