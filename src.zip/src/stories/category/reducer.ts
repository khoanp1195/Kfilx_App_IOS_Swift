
import {createSlice, createAsyncThunk} from '@reduxjs/toolkit';
import {get} from '../../services/ApiServices';
import {RESONSE_STATUS_SUCCESS} from 'helpers/Constants';
import {BASE_URL} from 'helpers/Constants';
import {isNullOrUndefined} from 'helpers/Functions';
import axios from 'axios';


//GetCategoryFromServer
export const GetCategoryFromServer = createAsyncThunk(
    'dashboard/GetCategoryFromServer',
    async (LangId: number) => {
      try {
        let responseGetCategoryFromServer = null;
        const url =`https://vnadmsuatportal.vuthao.com/psd/api/ApiMobile.ashx?func=GetDocumentAreaCategory&LangId=${LangId}`;
       console.log("url =>>> " + url)
        try{
          const response = await axios.get(url, {
            headers: {
              'Content-Type': 'application/json', // Adjust the content type as needed
            },
          });
          if (response?.status === 200) {
            responseGetCategoryFromServer = response?.data.data;
          } else {
            console.error('Load Data Failed:');
          }
          return {
            dataCategory: response?.data.data,
          };
  
        }catch(ex)
        {
          console.error('Error in GET request:', ex);
        }
        if (!isNullOrUndefined(responseGetCategoryFromServer)) {
          if (responseGetCategoryFromServer.data.status === RESONSE_STATUS_SUCCESS) {
            return responseGetCategoryFromServer.data.data;
          }
        }
        return null;
      } catch (error) {
        console.error('Error fetching data:', error);
        throw error;
      }
    }
  );

//https://vnadmsuatportal.vuthao.com/psd/api/ApiMobile.ashx?func=SelectByArea&LangId=1033&Offset=0&Limit=20&Params=LangId,Offset,Limit&enc=RSA 



  //GetListSubCategory
  export const GetListSubCategory = createAsyncThunk(
    'home/GetListSubCategory',
    async (payload: any) => {
      const {
        limit,offset,id,langId
      } = payload
      try {
        let data = new FormData();
        const jsonData = {
          Parameters: {
            AreaCategoryId: id,
            DocumentGroupId: '1',
            Title:'',
            Code:'',
            StorageCode: '',
            Int2: ''
          }
        };
        data.append("data", JSON.stringify(jsonData));
        let config = {
            method: 'post',
            url: `https://vnadmsuatportal.vuthao.com/psd/api/ApiMobile.ashx?func=SelectByArea&LangId=${langId}&Offset=${offset}&Limit=${limit}&Params=LangId,Offset,Limit&enc=RSA`,
            data: data,
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'multipart/form-data',
            },
        };
        const response = await axios(config);  
        return {
          dataSubCategory: response?.data?.data?.Data,
        }
      } catch (ex) {
        console.error('Error in GetListSubCategory:', ex);
      }
    }
  )


  
const categoriesSlice = createSlice({
  name: 'dashboard',
  initialState: {
    isLoadingListNotify: false,
    isLoading: false,
    dataCategory:[],
    DATAautoId: '',
    dataSubCategory: []
  },
  reducers: { 
    // syncFormCategoryAction(state,action){
    //     return{
    //       ...state,
    //       dataCategory: action.payload?.dataCategory
    //     }
    // },

    // setCategoryDocAction(state,action) {
    //   return{
    //     ...state,
    //     dataCategory: action.payload
    //   }
    // },

    SetisLoadingListNotify(state,action){
      return {
        ...state,
        isLoadingListNotify: action.payload
      }
    },   
  },
  extraReducers: builder => {
    builder.addCase(GetCategoryFromServer.fulfilled, (state: any, action) => {
      state.dataCategory = action.payload?.dataCategory;
    });
    builder.addCase(GetListSubCategory.fulfilled, (state: any, action) => {
      state.dataSubCategory = action.payload?.dataSubCategory;
    });
  },
});
export const {SetisLoadingListNotify,setCategoryDocAction } = categoriesSlice.actions;
const {reducer} = categoriesSlice;
export default reducer;
