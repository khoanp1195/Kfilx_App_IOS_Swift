
import {createSlice, createAsyncThunk} from '@reduxjs/toolkit';
import {get} from '../../services/ApiServices';
import {RESONSE_STATUS_SUCCESS} from 'helpers/Constants';
import {BASE_URL} from 'helpers/Constants';
import {isNullOrUndefined} from 'helpers/Functions';
import axios from 'axios';


//GetCategoryFromServer
export const GetCategoryFromServer = createAsyncThunk(
    'dashboard/GetCategoryFromServer',
    async () => {
      try {
        let responseGetCategoryFromServer = null;
        const url =`https://vnadmsuatportal.vuthao.com/psd/api/ApiMobile.ashx?func=GetDocumentAreaCategory`;
       console.log("url =>>> " + url)
        try{
          const response = await axios.get(url, {
            headers: {
              'Content-Type': 'application/json', // Adjust the content type as needed
            },
          });
          if (response?.status === 200) {
            responseGetCategoryFromServer = response?.data.data;
            console.log('responseGetCategoryFromServer day nha : =>> ' + responseGetCategoryFromServer);
          } else {
            console.error('Load Data Failed:');
          }
          return {
            dataCategory: response?.data.data,
          };
  
        }catch(ex)
        {
          console.error('Error in GET request:', ex);
        }
        console.log('responseGetCategoryFromServer =>>> ', responseGetCategoryFromServer);
        if (!isNullOrUndefined(responseGetCategoryFromServer)) {
          if (responseGetCategoryFromServer.data.status === RESONSE_STATUS_SUCCESS) {
            return responseGetCategoryFromServer.data.data;
          }
        }
        return null;
      } catch (error) {
        console.error('Error fetching data:', error);
        throw error;
      }
    }
  );

//https://vnadmsuatportal.vuthao.com/psd/api/ApiMobile.ashx?func=SelectByArea&LangId=1033&Offset=0&Limit=20&Params=LangId,Offset,Limit&enc=RSA 

  //GetListSubCategory
  export const GetListSubCategory = createAsyncThunk(
    'home/GetListSubCategory',
    async (categoryID: String) => {
      // const { limit, offset } = payload;
      const LangId = 1066;
      const Params = {
        Offset: 0,
        Limit: 100,
      };
      try {
        console.log("categoryID= >>>>>   >>> " + categoryID)
        let data = new FormData();
        const jsonData = {
          Parameters: {
            AreaCategoryId: categoryID,
            DocumentGroupId: '1',
            Title:'',
            Code:'',
            StorageCode: '',
            Int2: ''
          }
        };
        data.append("data", JSON.stringify(jsonData));
        let config = {
            method: 'post',
            url: `https://vnadmsuatportal.vuthao.com/psd/api/ApiMobile.ashx?func=SelectByArea&LangId=1033&Offset=0&Limit=20&Params=LangId,Offset,Limit&enc=RSA`,
            data: data,
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'multipart/form-data',
            },
        };
        const response = await axios(config);
        console.log('GetListSubCategory', response?.data);
  
        return {
          DataSubCategory: response?.data?.data?.Data,
        }
      } catch (ex) {
        console.error('Error in GetListSubCategory:', ex);
      }
    }
  )
const categoriesSlice = createSlice({
  name: 'dashboard',
  initialState: {
    isLoadingListNotify: false,
    isLoading: false,
    dataCategory:[],
    DATAautoId: '',
    DataSubCategory: []
  },
  reducers: { 
    SetisLoadingListNotify(state,action){
      return {
        ...state,
        isLoadingListNotify: action.payload
      }
    },   
  },
  extraReducers: builder => {
    builder.addCase(GetCategoryFromServer.fulfilled, (state: any, action) => {
      state.dataCategory = action.payload?.dataCategory;
    });
    builder.addCase(GetListSubCategory.fulfilled, (state: any, action) => {
      state.DataSubCategory = action.payload?.DataSubCategory;
    });
  },
});
export const { SetisLoadingListNotify } = categoriesSlice.actions;
const {reducer} = categoriesSlice;
export default reducer;
