
import {createSlice, createAsyncThunk} from '@reduxjs/toolkit';
import {get} from '../../services/ApiServices';
import {RESONSE_STATUS_SUCCESS} from 'helpers/Constants';
import {BASE_URL} from 'helpers/Constants';
import {isNullOrUndefined} from 'helpers/Functions';
import axios from 'axios';


//GetCategoryFromServer
export const GetCategoryFromServer = createAsyncThunk(
    'dashboard/GetCategoryFromServer',
    async () => {
      try {
        let responseGetCategoryFromServer = null;
        const url =`https://vnadmsuatportal.vuthao.com/psd/api/ApiMobile.ashx?func=GetDocumentAreaCategory`;
       console.log("url =>>> " + url)
        try{
          const response = await axios.get(url, {
            headers: {
              'Content-Type': 'application/json', // Adjust the content type as needed
            },
          });
          if (response?.status === 200) {
            responseGetCategoryFromServer = response?.data.data;
            console.log('responseGetCategoryFromServer day nha : =>> ' + responseGetCategoryFromServer);
          } else {
            console.error('Load Data Failed:');
          }
          return {
            dataCategory: response?.data.data,
          };
  
        }catch(ex)
        {
          console.error('Error in GET request:', ex);
        }
        console.log('responseGetCategoryFromServer =>>> ', responseGetCategoryFromServer);
        if (!isNullOrUndefined(responseGetCategoryFromServer)) {
          if (responseGetCategoryFromServer.data.status === RESONSE_STATUS_SUCCESS) {
            return responseGetCategoryFromServer.data.data;
          }
        }
        return null;
      } catch (error) {
        console.error('Error fetching data:', error);
        throw error;
      }
    }
  );


const categoriesSlice = createSlice({
  name: 'dashboard',
  initialState: {
    isLoadingListNotify: false,
    isLoading: false,
    dataCategory:[],
    DATAautoId: '',
  },
  reducers: { 
    SetisLoadingListNotify(state,action){
      return {
        ...state,
        isLoadingListNotify: action.payload
      }
    },   
  },
  extraReducers: builder => {
    builder.addCase(GetCategoryFromServer.fulfilled, (state: any, action) => {
      state.dataCategory = action.payload?.dataCategory;
    });
  },
});
export const { SetisLoadingListNotify } = categoriesSlice.actions;
const {reducer} = categoriesSlice;
export default reducer;
