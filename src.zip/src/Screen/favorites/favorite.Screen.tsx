import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Alert, ScrollView } from 'react-native';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { useDispatch, useSelector } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import SortableGridView from 'react-native-sortable-gridview'
import { GetCategoryFromServer } from 'stories/category/reducer';
import { Header } from '@react-navigation/stack';
import FastImage from 'react-native-fast-image';
import { dimensWidth, windowHeight, windowWidth } from 'helpers/Constants';
import HeaderWithAvatar from 'components/HeaderWithAvatar';
import { GetFavoriteFromServer } from 'stories/favorite/reducer';


const FavoriteScreen = () => {
  const dispatch = useDispatch<ThunkDispatch<any,any,any>>();
  const [dataFavoriteState, setdataFavoriteState] = useState([]);
  const dataFavorite = useSelector(
    (state: any) => state.favorite
  )

  //fetchGetDataCategory
  const fetchGetListDataFavoriteRequest = useCallback((payload: any) => {
    dispatch(GetFavoriteFromServer())
  }, [dispatch])
  useEffect(() => {
    fetchGetListDataFavoriteRequest({})
  }, [fetchGetListDataFavoriteRequest])

  useEffect(() => {
    setdataFavoriteState(dataFavorite?.dataFavoriteFolder);
  }, [dataFavorite])
  const filteredCategories = dataFavorite?.dataFavoriteFolder.filter((category: { ParentId: null; }) => category?.ParentId === null);

  return (
    <View style={styles.container}>
          <HeaderWithAvatar title="Mục yêu thích" />
      <FastImage
        style={styles.vnaBackgroundImage}
        resizeMode='contain'
        source={require('../../../src/assets/images/img_background_home.png')}
      />
      <ScrollView>
        <SortableGridView
          data={filteredCategories}
          numPerRow={5} // let each row has four items. Default is 3
          aspectRatio={1.2} // let height = width * 1.2. Default is 1
          gapWidth={8} // let the gap between items become to 8. Default is 16
          paddingTop={8} // let container's paddingTop become to 8. Default is 16
          paddingBottom={8} // let container's paddingBottom become to 8. Default is 16
          paddingLeft={8} // let container's paddingLeft become to 8. Default is 16
          paddingRight={8} // let container's paddingRight become to 8. Default is 16
          onDragStart={() => {
            console.log('CustomLayout onDragStart');
          }}
          onDragRelease={(data) => {
            console.log('CustomLayout onDragRelease', data);
          }}
          renderItem={(item, index) => {
            
            return (
              <View>
                <TouchableOpacity style={[styles.item, { backgroundColor: '#E2F9FF' }]}>
                  <View style={styles.text}>
                    <FastImage style={styles.img_content}
                  resizeMode='contain'
                  source={require('../../../src/assets/images/icon_Favorite.png')}
                    />
                  </View>
                </TouchableOpacity>
                <View style={{ marginTop: 122, justifyContent: 'center', alignContent: 'center', alignItems: 'center' }}>
                  <Text style={[{ marginTop: 66, color: item.color }]}>{item.Title}</Text>
                </View>
              </View>

            )
          }}
        />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffff',

  },
  img_content: {
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    height: dimensWidth(40),
    width: dimensWidth(40), alignContent: 'center',
    elevation: 4,
    borderRadius: 8,

  },
  text: {
    justifyContent: 'center',
    alignContent: 'center',
    alignItems: 'center'
  },
  textDescription: {
    marginTop: 10
  },
  item: {
    borderRadius: 5,
    shadowColor: "#000",
    flexDirection: 'column',
    shadowOffset: {
      width: 5,
      height: 5,
    },
    shadowOpacity: 0.5,
    shadowRadius: 3.84,

    elevation: 5,
    backgroundColor: 'white',
    position: 'absolute',
    width: 160,
    height: 160,
    top: 0,
    left: 42,
    right: 0,
    bottom: 0,
    marginTop: 20,
    justifyContent: 'center',
    alignItems: 'center',
    alignContent: 'center'

  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 16,
  },
  vnaBackgroundImage: {
    height: windowHeight,
    marginTop: 70,
    width: (windowWidth),
    position: 'absolute',
    zIndex: 0
  },
  fullName: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 100,
    textAlign: 'center',
    color: '#0b5e5c'

  },
  fieldContainer: {
    flex: 1,
  },
  fieldLabel: {
    marginRight: 8,
    fontSize: 18,
    color: 'rgba(128, 128, 128, 0.5)',
  },
  fieldTitle: {
    marginStart: 10
  },


  fieldValue: {
    marginLeft: 20,
    fontSize: 18,
    color: '#0b5e5c',
  },
  icon: {
    marginRight: 10,
  },
  viewTitle1: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 116,
    backgroundColor: '#FFFF',
  },

  viewTitleInfo: {
    flexDirection: 'row',
    paddingVertical: 10,
    paddingHorizontal: 20,
    height: 50,
    backgroundColor: '#FFFF',
  },


  fieldTitle1: {
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 20,
    color: '#0b5e5c',
  },

  viewTitle2: {
    height: 220,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(128, 128, 128, 0.2)',

  },
  image: {
    width: 100,
    height: 100,
    borderRadius: 50, // Make the image round for an avatar effect
    marginBottom: -65,
  },

  grayLine: {
    width: '90%', // Set the desired width of the line
    height: 1,
    marginLeft: 10,   // Set the height of the line
    backgroundColor: 'rgba(128, 128, 128, 0.3)', // Gray color
  },

  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
});

export default FavoriteScreen;
