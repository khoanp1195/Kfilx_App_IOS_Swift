import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Alert, ScrollView } from 'react-native';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { useDispatch, useSelector } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import SortableGridView from 'react-native-sortable-gridview'
import { GetCategoryFromServer } from 'stories/category/reducer';
import { Header } from '@react-navigation/stack';
import FastImage from 'react-native-fast-image';
import { dimensWidth, windowHeight, windowWidth } from 'helpers/Constants';
import HeaderWithAvatar from 'components/HeaderWithAvatar';
import { GetFavoriteFromServer } from 'stories/favorite/reducer';
import styles from './favorite.Style';
import { fetchCurrentUsers } from 'stories/dashboard/reducer';


const FavoriteScreen = () => {
  const dispatch = useDispatch<ThunkDispatch<any,any,any>>();
  const [dataFavoriteState, setdataFavoriteState] = useState([]);
  const dataFavorite = useSelector(
    (state: any) => state.favorite
  )
  const currentUser = useSelector((state: any) => state.dashboard);
  const { languages, languagesText } = useSelector((state: RootState) => state.languages);
  const {
    dataCurrentUser,
  } = currentUser;

  //fetchGetDataCategory
  const fetchGetListDataFavoriteRequest = useCallback((payload: any) => {
    dispatch(GetFavoriteFromServer())
  }, [dispatch])
  useEffect(() => {
    fetchGetListDataFavoriteRequest({})
  }, [fetchGetListDataFavoriteRequest])
  useEffect(() => {
    dispatch(fetchCurrentUsers());
  }, [languagesText])

  useEffect(() => {
    setdataFavoriteState(dataFavorite?.dataFavoriteFolder);
  }, [dataFavorite])
  const filteredCategories = dataFavorite?.dataFavoriteFolder.filter((category: { ParentId: null; }) => category?.ParentId === null);

  return (
    <View style={styles.container}>
      <HeaderWithAvatar item={currentUser.dataCurrentUsers} title={languages.tab_favorite}  urlOnline={currentUser.dataCurrentUsers?.ImagePath} />
      <FastImage
        style={styles.vnaBackgroundImage}
        resizeMode='contain'
        source={require('../../../src/assets/images/img_background_home.png')}
      />
      <ScrollView>
        <SortableGridView
          data={filteredCategories}
          numPerRow={5} // let each row has four items. Default is 3
          aspectRatio={1.2} // let height = width * 1.2. Default is 1
          gapWidth={8} // let the gap between items become to 8. Default is 16
          paddingTop={8} // let container's paddingTop become to 8. Default is 16
          paddingBottom={8} // let container's paddingBottom become to 8. Default is 16
          paddingLeft={8} // let container's paddingLeft become to 8. Default is 16
          paddingRight={8} // let container's paddingRight become to 8. Default is 16
          onDragStart={() => {
            console.log('CustomLayout onDragStart');
          }}
          onDragRelease={(data) => {
            console.log('CustomLayout onDragRelease', data);
          }}
          renderItem={(item, index) => {
            
            return (
              <View>
                <TouchableOpacity style={[styles.item, { backgroundColor: '#E2F9FF' }]}>
                  <View style={styles.text}>
                    <FastImage style={styles.img_content}
                  resizeMode='contain'
                  source={require('../../../src/assets/images/icon_Favorite.png')}
                    />
                  </View>
                </TouchableOpacity>
                <View style={{ marginTop: 122, justifyContent: 'center', alignContent: 'center', alignItems: 'center' }}>
                  <Text style={[{ marginTop: 66, color: item.color }]}>{item.Title}</Text>
                </View>
              </View>
            )
          }}
        />
      </ScrollView>
    </View>
  );
};
export default FavoriteScreen;
