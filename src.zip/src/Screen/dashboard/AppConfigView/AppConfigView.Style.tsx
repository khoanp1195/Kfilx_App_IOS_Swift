import { StyleSheet, Platform, Dimensions } from 'react-native';
import colors from '../../../helpers/Colors';
import { dimensWidth, dimnensHeight, FontFamily, FontSize, windowHeight, windowWidth } from 'helpers/Constants';
import { Colors } from 'react-native/Libraries/NewAppScreen';
const window = Dimensions.get('window');
const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#ffff',
    },
    lbl_thoat:{
      position: 'absolute',
      right: 40,
      fontSize: 50,
      top: 10
    },
    itemAvatar: {
      height: dimensWidth(17),
      width: dimensWidth(17),
      marginLeft: dimensWidth(5),
      borderRadius: dimensWidth(20),
      marginTop: 15
    },
    icon_back:{
      height: dimensWidth(10),
      width: dimensWidth(10),
      position: 'absolute',
      right: 40,
      top: 10
    },
    containerFlatList: {
      width: windowWidth - 40,
      marginLeft: 16,
    },
    item: {
      flexDirection: 'row',
      backgroundColor: 'white',
      marginBottom: dimensWidth(5),
  
      justifyContent: 'center',
      height: 70
    },
    flexDirectionBetween: {
      flexDirection: 'row',
    },
    title: {
      fontSize: FontSize.SMALL,
      color: 'black',
      fontWeight: '500',
      fontFamily: 'arial',
      marginBottom: 6,
  
    },
    date: {
      fontSize: 13,
      color:  'gray',
      fontWeight: '400',
      fontFamily: 'arial',
      marginBottom: 6,
      marginLeft: 20
      
    },
    category: {
      fontSize: dimensWidth(13),
      color:  'lightgray',
      fontWeight: '400',
      fontFamily: 'arial',
      marginBottom: 6,
      marginRight: dimensWidth(5)
    },
    title_header:{
      fontSize: 24,
      fontWeight: 'bold',
      top: 50,
      width: 350,
      textAlign: 'center',
      alignContent: 'center',
      justifyContent: 'center'  
    },
    flexDirectionRowTab: {
      flexDirection: 'row',
      alignItems: 'center',
      alignSelf: 'baseline',
      marginLeft: 16,
      marginTop: 75,
      backgroundColor: '#F0F0F0',//colors.tab_bg_blue,
      borderColor: 'gray',
      padding: 0,
      width: windowWidth - 40,
      height: dimensWidth(15),
    },
    onPressActiveTab: {
      backgroundColor: colors.white,
      width: windowWidth/2 - 40 ,
      borderRadius: dimensWidth(2),
      height: dimensWidth(19),
      borderWidth: 0.4,
      borderColor: '#F0F0F0',
      textAlign:'center'
    },
    onPressInActiveTab: {
      paddingVertical: 6,
      paddingHorizontal: 275,
      borderRadius: dimensWidth(18),
      textAlign:'center',
  
    },
    cellContent: {
      width: windowWidth,
      height: 70
    },
    cellHeader: {
      padding: 7,
      width: windowWidth - 90,
      backgroundColor: '#f0f0f0',
      borderColor: '#ccc',
      marginLeft: 70,
      paddingHorizontal: 60
    },
  
    titleActiveTab: {
      fontSize: 17,
      lineHeight: dimensWidth(18),
      textAlign: 'center',
      color: 'black',//colors.primary
      fontWeight: '700',
      fontFamily: 'arial',
    },
    titleInActiveTab: {
      fontSize: 17,
      lineHeight: dimensWidth(17),
      textAlign: 'center',
      color: 'black',
      fontWeight: '400',
      fontFamily: 'arial',
    },
    viewScrollViewGrid: {
      flexDirection: 'row',
      width: windowWidth,   
    },
    settingItem: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      height: 70,
      paddingHorizontal: 15
  },
  viewLeft: {
  },
  viewRight: {
      flexDirection: 'row',
      alignItems: 'center',
  },
  itemTitle: {
      flex: 1,
      color: colors.black_121,
      fontSize: 28,
      fontWeight: '400',
      fontFamily: FontFamily.HERITAGE_REGULAR,
  },
  textHeader: {
      color: colors.black_121,
      fontSize: 16,
      fontWeight: '400',
      fontFamily: FontFamily.HERITAGE_REGULAR,
      width: 100,
      textAlign: 'center',
      marginRight: -5

  },
  textHeader_title: {
    color: colors.black_121,
    fontSize: 16,
    fontWeight: '400',
    fontFamily: FontFamily.HERITAGE_REGULAR,
    width: 100,
    textAlign: 'center',
    marginRight: -5

},
  headerContainer: {
      paddingTop: 10,
      flexDirection: 'row',
      justifyContent: 'flex-end',
      alignItems: 'center',

  },
  view_setting: {
    marginTop: 70,
    width: windowWidth - 50,
    marginLeft: 25

  }
  });
export default styles;