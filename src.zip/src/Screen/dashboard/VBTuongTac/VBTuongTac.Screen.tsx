import React, { FC, useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Alert, FlatList, RefreshControl, Animated, ScrollView, ActivityIndicator } from 'react-native';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { useDispatch, useSelector } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaView } from 'react-native-safe-area-context';
import { GetInteractDocument, GetListNotify, GetListUnreadNotify, getAutoLoginMobile } from 'stories/dashboard/reducer';
import { arrayIsEmpty } from 'helpers/Functions';
import NoDataView from 'components/NoDataView';
import { FontSize, dimensWidth, windowWidth } from 'helpers/Constants';
import colors from 'helpers/Colors';
import HTML from 'react-native-render-html';
import FastImage from 'react-native-fast-image';
import { Col, Row } from 'react-native-flex-grid';
import FastImageCustom from 'components/FastImageCustom';
import styles from './VBTuongTac.Style';
import { useNavigation } from '@react-navigation/native';
import { RootState } from 'stories/index';

interface Props {
  modalVisible: Boolean;
  onCloseModal: () => void;
  ActionJson: any;
}
const VBTuongTac: FC<Props> = ({
  modalVisible,
  onCloseModal,
  ...props
}: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const [Offset, setOffset] = useState(0);
  const [dataInteractDocumentState, setdataInteractDocumentState] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  let initialPayloadNotify = { limit: 100, offset: Offset }
  let initialPayloadUnReadNotify = { limit: 100, offset: Offset, isCount: 0 }
  const [payloadNotify, setpayloadNotify] = useState<any>(initialPayloadNotify);
  const [payloadUnReadNotify, setpayloadUnReadNotify] = useState<any>(initialPayloadUnReadNotify);
  const navigation = useNavigation()
  const fadeAnim = new Animated.Value(1); // Initialize opacity to 1 (fully visible)
  const {languages,languagesText } = useSelector((state: RootState) => state.languages);
  const dataInteractDocument = useSelector(
    (state: any) => state.dashboard
  )
  const isLoadMoreInteractive = useSelector(
    (state: any) => state.dashboard
  )
  const {totalRecordInteractive} = dataInteractDocument;
  const isLoadingdataInteractDocument = useSelector((state: any) => state.dashboard)


  //fetchGetListDataInteractDocumentRequest
  const fetchGetListDataInteractDocumentRequest = useCallback((payload: any) => {
    dispatch(GetInteractDocument(payload))
  }, [dispatch])
  useEffect(() => {
    const langId = languagesText === 'EN' ? 1033 :1066
    fetchGetListDataInteractDocumentRequest({langId ,limit: 20, offset: Offset })
  }, [dispatch,languagesText,Offset])


  //onRefresh
  const onRefresh = useCallback(() => {
    setOffset(0);
    setRefreshing(false);
  }, [refreshing]);

  //dataInteractDocument
  useEffect(() => {
    setdataInteractDocumentState(dataInteractDocument.dataListInteractDocument);
    setRefreshing(false)
  }, [dataInteractDocument])

  const onGoBack = useCallback(() => {
    navigation.goBack();
  }, [navigation]);

  const handleLoadmore = async() => {
    if (dataInteractDocument.dataListInteractDocument.length < totalRecordInteractive) {
        setOffset(dataInteractDocument.dataListInteractDocument.length);
    }
   }

  const renderFooter = (isLoading: boolean, refreshing: boolean, isLoadMoreInteractive: boolean, Offset: any) => {
    return (
      //Footer View with Load More button
      <View style={styles.footer}>
        {isLoading && !refreshing && isLoadMoreInteractive && Offset !== 0 ? (
          <ActivityIndicator color="blue" style={{ marginLeft: 8 }} />
        ) : null}
      </View>
    );
  };


  const gotoDetailPress = useCallback(
    (ResourceUrl: any) => {
      dispatch(getAutoLoginMobile());
      navigation.navigate({
        name: "DashboardDetailScreen",
        params: { urlThongBao: ResourceUrl },
      });
      console.log("item?.Link =>>> " + ResourceUrl)
    },
    [dispatch, navigation],
  )
  const ItemGrid = ({ item, gotoDetail,index }: any) => {
    const {
      Title,
      StorageCode,
      Created,
      Type,
      Thumbnail,
      ResourceUrl
    } = item;
    const idOdd = index % 2 === 0;
    const formatDate = (dateString: any) => {
      const parsedDate = new Date(dateString);
      const formattedDate =
        parsedDate.toLocaleTimeString().slice(0, 5) + " " +
        parsedDate.toLocaleDateString('en-GB', {
          day: '2-digit',
          month: '2-digit',
          year: 'numeric'
        });
      return formattedDate;
    };
    return (
      <ScrollView horizontal style={[styles.viewScrollViewGrid, idOdd && { backgroundColor: '#F1FAFF' }]} >
        <View>


          <View key={index} >
            <TouchableOpacity  onPress={() => gotoDetail(ResourceUrl)}>
            <Row style={styles.cellContent}>
              <Col style={{ padding: 10, width: 210, flexDirection: 'row' }}>
                <FastImage style={{
                  height: dimensWidth(15),
                  width: dimensWidth(15),
                  marginLeft: dimensWidth(2),
                }}
                  source={{ uri: item.Thumbnail }}
                />
                <Text style={{ width: 320, marginLeft: 10, marginTop: 10, color: 'rgb(0, 104, 133)' }}>{item.StorageCode}</Text>
              </Col>
              <Col style={{ padding: 10, width: 210 }}>
                <Text style={{ width: 270, marginLeft: 80 }}>{item.Title}</Text>
              </Col>
              <Col style={{ marginLeft: -350, padding: 10 }}>
                {/* <Text style={{textAlign: 'center'}}>{item.Title}</Text> */}
              </Col>
              <Col style={{ padding: 10 }}>
                <Text style={{ marginLeft: 120 }}>{formatDate(item.Created)}</Text>
              </Col>
              <Col style={{ padding: 10 }}>
                <Text style={{ marginLeft: 55 }}>{item.Type}</Text>
              </Col>
            </Row>
            </TouchableOpacity >
          </View>
          <View>
          </View>
        </View>
      </ScrollView>
    );


  }


  return (
    <SafeAreaView style={{ flex: 1 }}>
      <View style={styles.container}>
        <View style={{ alignItems: 'center' }}>
          <Text style={styles.title_header}>{languages.docs_interaction}</Text>
        </View>

        <TouchableOpacity
          activeOpacity={1}
          style={{ backgroundColor: 'blue' }}
          onPress={onGoBack}
        >
          {/* <Text style={styles.lbl_thoat} numberOfLines={1}>
              {"X"}
            </Text> */}
          <FastImage
            style={styles.icon_back}
            resizeMode='contain'
            source={require('../../../../src/assets/images/icon_closeForm.png')}
          />
        </TouchableOpacity>

        <View style={styles.flexDirectionRowTab}>
          <View>
            <Row style={styles.cellHeader}>
              <Col style={[{
                padding: 7,
                marginLeft: 10,
                backgroundColor: '#f0f0f0',
                borderColor: '#ccc',
              }]}>
                <Text style={{ fontWeight: 'bold' }}>{languages.m_v_n_b_n}</Text></Col>
              <Col style={[{
                padding: 7,
                marginLeft: 100,
                backgroundColor: '#f0f0f0',
                borderColor: '#ccc',
              }]}><Text style={{ fontWeight: 'bold' }}>{languages.t_n_v_n_b_n}</Text></Col>
              <Col style={[{
                padding: 7,
                marginLeft: 220,
                backgroundColor: '#f0f0f0',
                borderColor: '#ccc',
              }]}><Text style={{ fontWeight: 'bold', width: 200, marginLeft: -10 }}>{languages.Interaction_day}</Text></Col>
              <Col style={styles.cellHeader}><Text style={{ fontWeight: 'bold' }}>{languages.category}</Text></Col>
            </Row>
          </View>

        </View>

        {!arrayIsEmpty(dataInteractDocumentState) ?
          (
            <FlatList
              contentContainerStyle={styles.containerFlatList}
              data={dataInteractDocumentState}
              extraData={dataInteractDocumentState}
              refreshControl={
                <RefreshControl refreshing={isLoadingdataInteractDocument} onRefresh={onRefresh} tintColor='#0b5e5c' />
              }
              renderItem={({ item, index }) => (
                <ItemGrid item={item} gotoDetail={gotoDetailPress}  index={index} />// gotoDetail={gotoDetailPress}
              )
              }
              keyExtractor={(item, index) => String(index)}
              showsVerticalScrollIndicator={false}
              onEndReachedThreshold={0.5}
              onEndReached={handleLoadmore}
              ListFooterComponent={renderFooter(isLoadingdataInteractDocument,refreshing,isLoadMoreInteractive,Offset)}
            />
          ) :
          (<NoDataView onRetryPress={function () {
            throw new Error("Function not implemented.");
          }} />
          )}
      </View>

    </SafeAreaView>
  );
};

export default VBTuongTac;