
import React, { useCallback, useEffect, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
 import { WebView } from 'react-native-webview';
import Header from '../../components/HeaderDetail'
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from 'redux-thunk';
import { getAutoLoginMobile } from 'stories/dashboard/reducer';
import { RootState } from 'stories/index';
import colors from 'helpers/Colors';
import { checkIsEmpty } from 'helpers/Functions';
import axios from 'axios';

type Props = {
    navigation: any
    route: any
}
// ...
const DashboardDetail = ({route, navigation}: Props) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const {languages,languagesText } = useSelector((state: RootState) => state.languages);
    const autoId  = useSelector((state: RootState) => state.dashboard);
    const [autoIdState, setAutoIdState] = useState(null)
    const {id} = route.params

    const [data, setData] = useState(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await axios.get('https://vnadmsuatportal.vuthao.com/psd/API/User.ashx?func=mobileAutoLoginWeb');
      // Replace 'YOUR_API_ENDPOINT_HERE' with the actual URL of your API

      // Assuming the response data structure is similar to the provided JSON
      const responseData = response.data;

      // Extract the "data" value from the response
      const dataValue = responseData.data;

      // Update the state with the data
      setData(dataValue);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  return (
    <View style={{ flex: 1,backgroundColor: colors.white }}>
       <Header />
       {/* <WebView
          source={{ uri:  `https://vnadmsuatportal.vuthao.com/psd/frontend/pages/VNADetailVB.aspx?rid=${id}&gid=1&cid=3&Mobile=1&autoid=${data}&lang=${languagesText.toLowerCase()}` }}
          sharedCookiesEnabled
          thirdPartyCookiesEnabled
          allowFileAccess
          cacheEnabled
        /> */}
        {/* <Header />
        {
          !checkIsEmpty(autoIdState) &&
          <WebView source={{ uri: `https://vnadmsuatportal.vuthao.com/psd/frontend/pages/VNADetailVB.aspx?rid=842&gid=1&cid=3&Mobile=1&autoid=d0bc1bb5-06e4-490e-ab83-5019a4d1385e&lang=vi` }} />
        
        } */}
    </View>
  );
}

export default DashboardDetail

const styles = StyleSheet.create({})