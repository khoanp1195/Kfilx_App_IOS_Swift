
import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { WebView } from 'react-native-webview';
import Header from '../../components/HeaderWithAvatar'
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from 'redux-thunk';
import { getAutoLoginMobile } from 'stories/dashboard/reducer';
import { RootState } from 'stories/index';
import colors from 'helpers/Colors';
import { checkIsEmpty } from 'helpers/Functions';

type Props = {
    navigation: any
    route: any
}
// ...
const DashboardDetail = ({route, navigation}: Props) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const {languages,languagesText } = useSelector((state: RootState) => state.languages);
    const {autoId } = useSelector((state: RootState) => state.dashboard);
    const [autoIdState, setAutoIdState] = useState(null)
    const {id} = route.params

    useEffect(() => {     
        dispatch(getAutoLoginMobile());
    }, [id, navigation])
    useEffect(() => {
      setAutoIdState(autoId)
    }, [autoId])

  return (
    <View style={{ flex: 1,backgroundColor: colors.white }}>
        <Header />
        {
          !checkIsEmpty(autoIdState) &&
          <WebView source={{ uri: `https://vnadmsuatportal.vuthao.com/psd/frontend/pages/VNADetailVB.aspx?rid=${id}&gid=1&cid=3&Mobile=1&autoid=${autoIdState}&lang=${languagesText.toLowerCase()}` }} />

        }
    </View>
  );
}

export default DashboardDetail

const styles = StyleSheet.create({})