import {StyleSheet, Platform, Dimensions} from 'react-native';
import colors from '../../helpers/Colors';
import {dimensWidth, dimnensHeight, FontSize, windowHeight} from 'helpers/Constants';
import { Colors } from 'react-native/Libraries/NewAppScreen';
const window = Dimensions.get('window');
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  avatar: {
    height: dimensWidth(36),
    width: dimensWidth(36),
    marginRight: dimensWidth(12),
    marginLeft: dimensWidth(15),
    borderRadius: dimensWidth(18),
  },

  processingDocx: {
    padding: 20,
    height: dimensWidth(220),
    width: dimensWidth(200),
    marginLeft: dimensWidth(10),
    borderRadius: dimensWidth(10),
  },
  coordinationDocx: {
    height: dimensWidth(150),
    width: '100%',
    alignItems: 'center',
    marginRight: dimensWidth(8),
    borderRadius: dimensWidth(10),
  },
  imgNotification: {
    padding: 20,
    position: 'absolute',
    bottom: dimensWidth(5),
    height: dimensWidth(120),
    width: dimensWidth(200),
    marginRight: dimensWidth(8),
    borderRadius: dimensWidth(10),
  },
  viewAvatar: {
    width: '100%',
    height: dimnensHeight(55),
    backgroundColor: '#025ED8',
    flexDirection: 'row',
    alignItems: 'center',
  },

  titleAvatar: {
    fontSize: FontSize.LARGE,
    color: colors.white,
    fontWeight: '400',
    fontFamily: 'arial',
  },
  dashboard: {
    fontSize: FontSize.LARGE_XX,
    lineHeight: dimensWidth(26),
    color: colors.white,
    fontWeight: '700',
    fontFamily: 'arial',
    marginLeft: dimensWidth(15),
    marginBottom: dimensWidth(6),
    marginTop: dimensWidth(15)
  },
  titleDashboard: {
    fontSize: dimensWidth(52),
    color: colors.white,
    fontWeight: '700',
    fontFamily: 'arial',
    marginBottom: dimnensHeight(5),
  },
  flexDirectionRow: {
    flexDirection: 'column',
  },
  contentDashboard: {
    fontSize: FontSize.LARGE,
    color: colors.white,
    fontWeight: '700',
    fontFamily: 'arial',
  },
  titleVanban: {
    fontSize: FontSize.LARGE,
    color: colors.white,
    fontWeight: '700',
    fontFamily: 'arial',
    marginBottom: dimnensHeight(5),
  },
  contentVanban: {
    fontSize: FontSize.SMALL,
    color: colors.white,
    fontWeight: '700',
    fontFamily: 'arial',
  },
  contentDescription: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: '400',
    fontFamily: 'arial',
  },
  squareDescription: {height: 18, width: 18, marginRight: 5, borderRadius: 5},
  viewDescription: {
    position: 'absolute',
    bottom: 10,
    width: '100%',
    flexDirection: 'column',
    marginHorizontal: 15,
  },
  viewTitleChart: {
    position: 'absolute',
    top: 0,
    marginTop: 30,
    width: '100%',
    alignItems: 'center',
    zIndex: 99,
  },
  titleChart: {
    fontSize: FontSize.LARGE_X,
    color: colors.black,
    fontWeight: '700',
    fontFamily: 'arial',
  },
  viewContainerChart: {
    flex: 1,
    borderTopLeftRadius: 8,
    borderTopRightRadius: 8,
    borderBottomLeftRadius: 8,
    borderBottomRightRadius: 8,
    overflow: 'hidden',
    marginBottom: dimensWidth(10),
    marginLeft: 15,
    marginRight: 5,
    backgroundColor: 'white',
    marginTop: windowHeight < 800 ? dimnensHeight(30): 0
  },
  viewChart: {
    width: '135%',
    height: '135%',
    marginLeft: -(dimensWidth(70)),
    marginTop: -(dimensWidth(15)),
  },
  viewChartIos: {
    width: '125%',
    height: '125%',
    marginLeft: -dimensWidth(35),
    marginTop: -(dimensWidth(15)),
    // marginTop: -15,
  },
  flexOne: {
    flex: 1,
    flexDirection: 'row'
  },
  vnaBackgroundImage: {
    height:window.height,
    width:(window.width) * 1,
    rotation: 8,
    translateX: 8,
    position:'absolute',
    zIndex: 1, 
   
    
  },
  item: {
    backgroundColor: '#f9c2ff',
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
    height: 170,width:130
  },
  header:{
    backgroundColor: '#006885',
    position: 'absolute',
    top: 0,
    left:0,
    right: 0,
    width: window.width,
    height: 70,
    zIndex:1

  },
  itemNewDocuments: {
    flexDirection: 'row',
    backgroundColor: 'rgba(0, 0, 0, 0)',
    marginHorizontal: dimensWidth(15),
    borderRadius: 5,
    width: 100,
    height: 350,
    paddingHorizontal: 98,
    marginLeft: 31,
    borderWidth: 0.2
  },

  itemNewDocumentsChild: {
    flexDirection: 'row',
    backgroundColor: 'green',
    borderRadius: 3,
    width: 185,
    height: 270,
    borderColor:'lightgray',
    borderWidth: 0.2,
    position: 'absolute',
  },

  titleItemNewDoc: {
    position: 'absolute',
    bottom: 30,
    left: 25,
    width:230,
    color: '#262626',
    fontSize: 15,
    fontWeight:'bold'
    

  },
  dateItemNewDoc: {
    position: 'absolute',
    textAlign: 'center',
    alignItems: 'center',
    bottom: 5,
    color: '#7B7B7B', left: 15,
  },
  profileImgContainer: {
    position: 'absolute',
    right: 15,
    backgroundColor: 'rgba(0, 0, 0, 0)',
    top: 10,
    borderRadius: 40,
    height: 50,
    width: 50,
    display: 'flex',
    justifyContent: 'center', // Center horizontally
    alignItems: 'center', // Center vertically}}
  },
  profileImg:{
    height: 50,
    width: 50,
    borderRadius: 40,
  }
});
export default styles;
