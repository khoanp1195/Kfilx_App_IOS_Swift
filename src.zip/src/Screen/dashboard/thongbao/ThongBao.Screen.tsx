import React, { FC, useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image,  TouchableOpacity, Alert, FlatList, RefreshControl } from 'react-native';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { useDispatch, useSelector } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaView } from 'react-native-safe-area-context';
import { GetListNotify, GetListUnreadNotify } from 'stories/dashboard/reducer';
import { arrayIsEmpty } from 'helpers/Functions';
import NoDataView from 'components/NoDataView';
import { FontSize, dimensWidth, windowWidth } from 'helpers/Constants';
import colors from 'helpers/Colors';
 import HTML from 'react-native-render-html';
import FastImage from 'react-native-fast-image';

interface Props {
    modalVisible: Boolean;
    onCloseModal: () => void;
    ActionJson: any;
  }
  const Item = ({ item, gotoDetail, index }: any) => {
    const {
      ID,
      ActionTime,
      Content
    } = item;
    console.log('Content day nha =>>> ' + ActionTime);
    const htmlContent = Content
    let plainText = '';

    // const handleTextExtraction = (text) => {
    //   plainText = text;
    // };

    const isOdd  = index % 2 === 0;

    return (
      <TouchableOpacity style={[styles.item, isOdd && {backgroundColor: '#F1FAFF'} ]}>
            <FastImage
            style={styles.itemAvatar}
            resizeMode='contain'
      source={require('../../../../src/assets/images/icon_itemNotify.png')}
    />
        <View style={{ flex: 1, flexDirection: 'column', marginLeft: 7 }}>
        <Text style={styles.title} numberOfLines={2}>{plainText}</Text>  
       <Text>
         <HTML source={{ html: htmlContent }}/>
       </Text>
          <Text style={styles.date}>{ActionTime}</Text>
        </View>
      </TouchableOpacity>
    );
  };

  const ThongBaoScreen: FC<Props> = ({
    modalVisible,
    onCloseModal,
    ...props
  }: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any,any,any>>();
  const [Offset, setOffset] = useState(0);
  const [tabName, setTabName] = useState(TABNAME.TatCa);
  const [dataNotifyState, setdataNotifyState] = useState([]);
  const [dataUnReadNotifyState, setdataUnReadNotifyState] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  let initialPayloadNotify = { limit:100,offset: Offset}
  let initialPayloadUnReadNotify = { limit:100,offset: Offset,isCount: 0}
  const [payloadNotify, setpayloadNotify] = useState<any>(initialPayloadNotify);
  const [payloadUnReadNotify, setpayloadUnReadNotify] = useState<any>(initialPayloadUnReadNotify);

  const dataNotify = useSelector(
    (state: any) => state.dashboard
  )
  const dataListUnreadNotify = useSelector(
    (state: any) => state.dashboard
  )
  const isLoadingListNotify = useSelector((state: any) => state.home)

  //fetchGetListDataNotifyRequest
  const fetchGetListDataNotifyRequest = useCallback((payload: any) => {
        dispatch(GetListNotify(payload))
  }, [dispatch])
  useEffect(() => {
    fetchGetListDataNotifyRequest({limit:100, Offset})
  }, [fetchGetListDataNotifyRequest])


    //fetchGetListdataListUnreadNotify
    const fetchGetListDataUnReadNotifyRequest = useCallback((payload: any) => {
      dispatch(GetListUnreadNotify(payload))
    }, [dispatch])
    useEffect(() => {
      fetchGetListDataUnReadNotifyRequest({limit:100, Offset})
    }, [fetchGetListDataUnReadNotifyRequest])


  const changeTabTatCa = useCallback(() => {
    setOffset(0)
    setTabName(TABNAME.TatCa)
  },[]);

  const changeTabChuaXem = useCallback(() => {
    setOffset(0)
    setTabName(TABNAME.ChuaXem);
    setpayloadUnReadNotify(initialPayloadUnReadNotify)
  }, [dataListUnreadNotify]);


//onRefresh
  const onRefresh = useCallback(() =>{
    setRefreshing(true);
    setOffset(0);
    setpayloadNotify(initialPayloadNotify)
    dispatch(GetListNotify(initialPayloadNotify));
  },[refreshing]);

  //dataNotify
  useEffect(() => {
    setdataNotifyState(dataNotify.dataListNotify);
    setRefreshing(false)
  },[dataNotify])

 //dataUnReadNotify
 useEffect(() => {
  setdataUnReadNotifyState(dataListUnreadNotify.dataListUnreadNotify);
  setRefreshing(false)
},[dataListUnreadNotify])

  return (
    <SafeAreaView style={{flex: 1}}>
        <View style={styles.container}>
            <View style={{alignItems: 'center'}}>
            <Text style={styles.title_header}>Thông báo</Text>
            </View>

        <TouchableOpacity
            activeOpacity={1}
            style={{backgroundColor: 'blue'}}
            onPress={onCloseModal}
          >
            <Text style={styles.lbl_thoat} numberOfLines={1}>
              {"X"}
            </Text>
          </TouchableOpacity>

          <View style={styles.flexDirectionRowTab}>
            <TouchableOpacity
              activeOpacity={1}
              onPress={changeTabTatCa}
              style={
                tabName === TABNAME.TatCa
                  ? styles.onPressActiveTab
                  : styles.onPressInActiveTab
              }
            >
              <Text
                style={
                  tabName === TABNAME.TatCa
                    ? styles.titleActiveTab
                    : styles.titleInActiveTab
                }
              >   Tất cả
                {/* {TABNAME.DangXL} */}
              </Text>
            </TouchableOpacity>
        
        
            <TouchableOpacity
              activeOpacity={1}
             onPress={changeTabChuaXem}
              style={
                tabName === TABNAME.ChuaXem
                  ? styles.onPressActiveTab
                  : styles.onPressInActiveTab
              }
            >
              <Text
                style={
                  tabName === TABNAME.ChuaXem
                    ? styles.titleActiveTab
                    : styles.titleInActiveTab
                }
              > Chưa xem
                {/* {TABNAME.DaXL} */}
              </Text>
            </TouchableOpacity>
          </View>  
                  {!arrayIsEmpty(dataNotifyState) && tabName === TABNAME.TatCa ? 
                  (       
                  <FlatList
                    contentContainerStyle={styles.containerFlatList}
                    data={dataNotifyState}
                    extraData={dataNotifyState}
                    
                    refreshControl={
                      <RefreshControl refreshing={isLoadingListNotify} onRefresh={onRefresh} tintColor='#0b5e5c' />
                    }
                    renderItem={({ item, index }) => (     
                          <Item item={item} index={index}/>// gotoDetail={gotoDetailPress}
                          )
                  }
                    keyExtractor={(item,index) => String(index)}
                    showsVerticalScrollIndicator={false}
                    onEndReachedThreshold={0.5}
                    // onEndReached={handleLoadmore}
                    // ListFooterComponent={renderFooter(isLoadingDangXuLy,refreshing,isLoadMoreDangXuly,Offset)}
                  />
                  ):!arrayIsEmpty(dataUnReadNotifyState) && tabName == TABNAME.ChuaXem ?
                  (
                    <FlatList
                    contentContainerStyle={styles.containerFlatList}
                    data={dataUnReadNotifyState}
                    extraData={dataUnReadNotifyState}
                    
                    refreshControl={
                      <RefreshControl refreshing={isLoadingListNotify} onRefresh={onRefresh} tintColor='#0b5e5c' />
                    }
                    renderItem={({ item, index }) => (     
                          <Item item={item} index={index}/>// gotoDetail={gotoDetailPress}
                          )
                  }
                    keyExtractor={(item,index) => String(index)}
                    showsVerticalScrollIndicator={false}
                    onEndReachedThreshold={0.5}
                    // onEndReached={handleLoadmore}
                    // ListFooterComponent={renderFooter(isLoadingDangXuLy,refreshing,isLoadMoreDangXuly,Offset)}
                  />
                  ):
                  
                  (<NoDataView onRetryPress={function () {
                      throw new Error("Function not implemented.");
                    } } />
                      )}
        </View>

    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffff',
  },
  lbl_thoat:{
    position: 'absolute',
    right: 40,
    fontSize: 50,
    top: 10
  },
  itemAvatar: {
    height: dimensWidth(17),
    width: dimensWidth(17),
    marginLeft: dimensWidth(5),
    borderRadius: dimensWidth(20),
    marginTop: 15
  },
  containerFlatList: {
    width: windowWidth - 40,
    marginLeft: 16,
  },
  item: {
    flexDirection: 'row',
    backgroundColor: 'white',
    marginBottom: dimensWidth(5),

    justifyContent: 'center',
    height: 70
  },
  flexDirectionBetween: {
    flexDirection: 'row',
  },
  title: {
    fontSize: FontSize.SMALL,
    color: 'black',
    fontWeight: '500',
    fontFamily: 'arial',
    marginBottom: 6,

  },
  date: {
    fontSize: 13,
    color:  'gray',
    fontWeight: '400',
    fontFamily: 'arial',
    marginBottom: 6,
    marginLeft: 20
    
  },
  category: {
    fontSize: dimensWidth(13),
    color:  'lightgray',
    fontWeight: '400',
    fontFamily: 'arial',
    marginBottom: 6,
    marginRight: dimensWidth(5)
  },
  title_header:{
    fontSize: 22,
    fontWeight: '600',
    top: 50,
    width: 250,
    textAlign: 'center',
    alignContent: 'center',
    justifyContent: 'center'  
  },
  flexDirectionRowTab: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'baseline',
    marginLeft: 16,
    marginTop: 75,
    backgroundColor: '#F0F0F0',//colors.tab_bg_blue,
    borderColor: 'gray',
    borderWidth: 0.4,
    padding: 0,
    width: windowWidth - 40,
    height: dimensWidth(20),
    borderRadius: dimensWidth(2),
  },
  onPressActiveTab: {
    backgroundColor: colors.white,
    width: windowWidth/2.24,
    borderRadius: dimensWidth(2),
    height: dimensWidth(19),
    borderWidth: 0.4,
    borderColor: '#F0F0F0',
    textAlign:'center'
  },
  onPressInActiveTab: {
    paddingVertical: 6,
    paddingHorizontal: 275,
    borderRadius: dimensWidth(18),
    textAlign:'center',

  },

  titleActiveTab: {
    fontSize: 17,
    lineHeight: dimensWidth(18),
    textAlign: 'center',
    color: 'black',//colors.primary
    fontWeight: '700',
    fontFamily: 'arial',
  },
  titleInActiveTab: {
    fontSize: 17,
    lineHeight: dimensWidth(17),
    textAlign: 'center',
    color: 'black',
    fontWeight: '400',
    fontFamily: 'arial',
  },
});

export default ThongBaoScreen;
export enum TABNAME {
    TatCa = "Tất cả",
    ChuaXem = "Chưa xem",
  }