import { StyleSheet, Platform, Dimensions } from 'react-native';
import colors from '../../../helpers/Colors';
import { dimensWidth, dimnensHeight, FontSize, windowHeight, windowWidth } from 'helpers/Constants';
import { Colors } from 'react-native/Libraries/NewAppScreen';
const window = Dimensions.get('window');
const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#ffff',
    },
    lbl_thoat:{
      position: 'absolute',
      right: 40,
      fontSize: 50,
      top: 10
    },
    itemAvatar: {
      height: dimensWidth(17),
      width: dimensWidth(17),
      marginLeft: dimensWidth(5),
      borderRadius: dimensWidth(20),
      marginTop: 15
    },
    icon_back:{
      height: dimensWidth(10),
      width: dimensWidth(10),
      position: 'absolute',
      right: 40,
      top: 10
    },
    containerFlatList: {
      width: windowWidth - 40,
      marginLeft: 16,
    },
    item: {
      flexDirection: 'row',
      backgroundColor: 'white',
      marginBottom: dimensWidth(5),
  
      justifyContent: 'center',
      height: 70
    },
    flexDirectionBetween: {
      flexDirection: 'row',
    },
    title: {
      fontSize: FontSize.SMALL,
      color: 'black',
      fontWeight: '500',
      fontFamily: 'arial',
      marginBottom: 6,
  
    },
    date: {
      fontSize: 13,
      color:  'gray',
      fontWeight: '400',
      fontFamily: 'arial',
      marginBottom: 6,
      marginLeft: 20
      
    },
    category: {
      fontSize: dimensWidth(13),
      color:  'lightgray',
      fontWeight: '400',
      fontFamily: 'arial',
      marginBottom: 6,
      marginRight: dimensWidth(5)
    },
    title_header:{
      fontSize: 22,
      fontWeight: '600',
      top: 50,
      width: 250,
      textAlign: 'center',
      alignContent: 'center',
      justifyContent: 'center'  
    },
    flexDirectionRowTab: {
      flexDirection: 'row',
      alignItems: 'center',
      alignSelf: 'baseline',
      marginLeft: 16,
      marginTop: 75,
      backgroundColor: '#F0F0F0',//colors.tab_bg_blue,
      borderColor: 'gray',
      borderWidth: 0.4,
      padding: 0,
      width: windowWidth - 40,
      height: dimensWidth(20),
      borderRadius: dimensWidth(2),
    },
    onPressActiveTab: {
      backgroundColor: colors.white,
      width: windowWidth/2 - 40 ,
      borderRadius: dimensWidth(2),
      height: dimensWidth(19),
      borderWidth: 0.4,
      borderColor: '#F0F0F0',
      textAlign:'center'
    },
    onPressInActiveTab: {
      paddingVertical: 6,
      paddingHorizontal: 275,
      borderRadius: dimensWidth(18),
      textAlign:'center',
      marginLeft: 70
  
    },
  
    titleActiveTab: {
      fontSize: 17,
      lineHeight: dimensWidth(18),
      textAlign: 'center',
      color: 'black',//colors.primary
      fontWeight: '700',
      fontFamily: 'arial',
    },
    titleInActiveTab: {
      fontSize: 17,
      lineHeight: dimensWidth(17),
      textAlign: 'center',
      color: 'black',
      fontWeight: '400',
      fontFamily: 'arial',
    },
  });
export default styles;