import { Image, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import TextCusTom from 'components/TextCusTom'
import FastImageCustom from 'components/FastImageCustom'
import { FontSize, dimensWidth } from 'helpers/Constants'
import colors from 'helpers/Colors'
import { format_dd_mm_yy } from 'helpers/Functions'
import { TouchableOpacity } from 'react-native-gesture-handler'

const DocumentViewItem = ({gotoDetail, item}: any) => {
    const formatDate = format_dd_mm_yy(item?.PublishDate)
  return (
    <TouchableOpacity  onPress={() => gotoDetail(item)} style={[styles.itemNewDocuments, { backgroundColor: 'rgba(0, 0, 0, 0)' }]}>
    <View style={styles.itemNewDocumentsChild}>
        <FastImageCustom urlOnline={item?.Thumbnail} styleImg={styles.itemNewDocumentsChild}/>
    </View>
    <TextCusTom i18nKey={item?.FileTitle} style={styles.titleItemNewDoc} numberOfLines={2}/>
    <TextCusTom i18nKey={formatDate} style={styles.dateItemNewDoc}/>
  </TouchableOpacity>
  )
}
export default DocumentViewItem

const styles = StyleSheet.create({
    itemContainer:{
        width: 160,
        height: 250,
        marginLeft: 20
    },
    imgThumbnail:{
        height: 200,
        width: 160
    },
    cap1:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey26,
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'center'
    },
    itemNewDocuments: {
      flexDirection: 'row',
      backgroundColor: 'rgba(0, 0, 0, 0)',
      marginHorizontal: dimensWidth(15),
      borderRadius: 5,
      width: 100,
      height: 350,

      paddingHorizontal: 98,
      marginLeft: 31
    },
  
    itemNewDocumentsChild: {
      flexDirection: 'row',
      backgroundColor: 'white',
      borderRadius: 3,
      width: 185,
      height: 270,
      borderColor:'lightgray',
      borderWidth: 0.5,
      position: 'absolute',
    },
  
    titleItemNewDoc: {
      position: 'absolute',
      bottom: 30,
      right: -5,
      width:210,
      textAlign: 'center',
      color: '#262626',
      fontSize: 15,
      fontWeight:'bold'
      
  
    },
    dateItemNewDoc: {
      position: 'absolute',
      textAlign: 'center',
      alignItems: 'center',
      bottom: 5,
      color: '#7B7B7B',    
      right: 65,
      
    },
})