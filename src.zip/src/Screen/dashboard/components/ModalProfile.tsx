import React, { FC, useMemo, useCallback, useState } from "react";
import {
  Modal,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Platform,
  FlatList,
} from "react-native";
import { useSelector } from "react-redux";
import { RootState } from "../../../stories";
import { useNavigation } from "@react-navigation/native";
import { SafeAreaProvider, SafeAreaView } from "react-native-safe-area-context";
import { FontSize, dimensWidth, windowWidth } from "helpers/Constants";
import FastImage from "react-native-fast-image";
import { ScrollView } from "react-native-gesture-handler";


const Item = ({ item, gotoDetail, index }: any) => {
    const {
      title,
      imgPath
    } = item;
 
    const image= imgPath

    return (
      <TouchableOpacity style={[styles.item ]}>
            <FastImage
            style={styles.itemIcon}
            resizeMode='contain'
      source={require('../../../../src/assets/images/icon_dSBinhLuan.png')}
    />
  
        <View style={{ flex: 1, flexDirection: 'column' }}>
        <Text style={styles.title} numberOfLines={2}>{title}</Text>  
          {/* <Text style={styles.date}>{ActionTime}</Text> */}
          <View style={styles.dashed} /><View/>
        </View>
      </TouchableOpacity>
    );
  };

interface Props {
  modalVisible: Boolean;
  onConfirmModal: () => void;
  onReFilterModal: () => void;
  confirmText: String;
  refilterText: String;
  props: FC<Props>;
  tabName: String;
  funtionVBDi: any;
  onPressProcessedDocx: () => void;
  onPressWaitProcesseDocx: () => void;
  onPressChooseType: () => void;
  onPressFilter: () => void;
  onPressSearch: () => void;
  onPressOpenCalendarPicker: (typeModal: string) => void;
  onPressChooseLanhDao: () => void;
  tinhTrang: String;
  navigation: any;
  startDate: any;
  endDate: any;
  statusText: any,
  lanhDaoNameSellectedState: any;
}
const ModalProfile: FC<Props> = ({
  modalVisible,
  onConfirmModal,
  onReFilterModal,
  confirmText,
  refilterText,
  funtionVBDi,
  onPressFilter,
  tabName,
  onPressWaitProcesseDocx,
  onPressProcessedDocx,
  tinhTrang,
  onPressChooseType,
  onPressSearch,
  onPressOpenCalendarPicker,
  startDate,
  endDate,
  statusText,
  onPressChooseLanhDao,
  lanhDaoNameSellectedState,
  ...props
}: Props) => {
  const lanhDaoNameSellectedName = useMemo(() => {
    if (!lanhDaoNameSellectedState) return "";
    const lanhDaoqName = lanhDaoNameSellectedState.find(
      (it) => it.isSellected
    )?.Title;

    return lanhDaoqName;
  }, [lanhDaoNameSellectedState]);


  const [filterText, setFilterText] = useState("");
  const onPressChooseTypePress = useCallback(() => {
    onPressChooseType();
  }, [onPressChooseType]);
  const onChangeFilterText = useCallback(
    (text: string) => {
      setFilterText(text);
    },
    [filterText]
  );
  const [isFilter, setIsFilter] = useState(false)
  const [visbleModalFilter, setVisbleModalFiltert] = useState(false);
  const onPressFilterhide = useCallback(() => {
    setVisbleModalFiltert(false);
  }, [visbleModalFilter]);
  const [scroll, setScroll] = useState(false);

  const DataForm1 = [
    {
      id: '1',
      title: 'Văn bản tương tác',
      imgPath: '../../../../src/assets/images/icon_vBTuongTac.png'
    },
    {
      id: '2',
      title: 'Danh sách bình luận',
      imgPath: '../../../../src/assets/images/icon_dSBinhLuan.png'
    },
    {
      id: '3',
      title: 'Văn bản ngoại tuyến',
      imgPath: '../../../../src/assets/images/icon_VBNgoaiTuyen.png'
    },
  ];
  const DataForm2 = [
    {
      id: '1',
      title: 'Cài đặt nhắt nhở thông báo',
      imgPath: '../../../../src/assets/images/icon_vBTuongTac.png'
    },
    {
      id: '2',
      title: 'Ngôn ngữ',
      imgPath: '../../../../src/assets/images/icon_dSBinhLuan.png'
    },
    {
      id: '3',
      title: 'Phiên bản',
      imgPath: '../../../../src/assets/images/icon_VBNgoaiTuyen.png'
    },
  ];

  const DATASignOut = [
    {
      id: '1',
      title: 'SignOut',
      imgPath: '../../../../src/assets/images/icon_vBTuongTac.png'
    },
  ];

  

  return (
    <Modal
      transparent={true}
      visible={modalVisible}
      {...props}
      style={styles.centeredView}
    >
      <SafeAreaProvider style={styles.centeredView}>
        <SafeAreaView>
        <View style={styles.modalView}>
          <ScrollView>
          <View style={styles.headerView}>
          <Text style={styles.title_header}>Tài khoản</Text>
          <TouchableOpacity style={styles.filterIcon} onPress={onReFilterModal}>
                <Text>X</Text>
            </TouchableOpacity>

          </View>
          <View style={styles.searchView}>

          <FastImage
            style={styles.itemAvatar}
            resizeMode='contain'
                source={require('../../../../src/assets/images/img_avatar_grey.png')}
                />
        <View style={{ flex: 1, flexDirection: 'column', marginLeft: 20, marginBottom: 100 }}>
        <Text style={styles.title} numberOfLines={2}>vnadmsuat.adminsite</Text>  
          <Text style={styles.date}>vnadmsuat.adminsite.Vuthao.com</Text>
        </View>


        <View style={styles.typeChild}>
            <Text style={styles.textType}>Đại hội cổ đông</Text>
          </View>
          </View>

          
          <View style={styles.type2}>
        <FlatList
        contentContainerStyle={styles.containerFlatList}
        data={DataForm1}
        extraData={DataForm1}
        scrollEnabled={scroll}
        renderItem={({ item, index }) => (     
              <Item item={item} index={index}/>// gotoDetail={gotoDetailPress}
        )
      }
        keyExtractor={(item,index) => String(index)}
        showsVerticalScrollIndicator={false}
        onEndReachedThreshold={0.5}
      />
          </View>
        
        
        
          <View style={styles.type2}>
        <FlatList 
        contentContainerStyle={styles.containerFlatList}
        data={DataForm2}
        extraData={DataForm2}
        scrollEnabled={scroll}
        renderItem={({ item, index }) => (     
              <Item item={item} index={index}/>// gotoDetail={gotoDetailPress}
        )
      }
        keyExtractor={(item,index) => String(index)}
        showsVerticalScrollIndicator={false}
        onEndReachedThreshold={0.5}
      />
          </View>
        

          <View style={styles.typeSignOut}>
        <FlatList
        contentContainerStyle={styles.containerFlatList}
        data={DATASignOut}
        extraData={DATASignOut}
        scrollEnabled={scroll}
        renderItem={({ item, index }) => (     
              <Item item={item} index={index}/>// gotoDetail={gotoDetailPress}
        )
      }
        keyExtractor={(item,index) => String(index)}
        showsVerticalScrollIndicator={false}
        onEndReachedThreshold={0.5}
      />
          </View>
          </ScrollView>
          </View>
        </SafeAreaView>
      </SafeAreaProvider>
    </Modal>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    height: 250,
    backgroundColor: "rgba(0,0,0,0.4)",
  }, 
   containerFlatList: {
    marginTop: 0,
    

  },
  item: {
    flexDirection: 'row',
    backgroundColor: 'white',
    height: 70,
    justifyContent: 'center',

  },
  modalView: {
    width: windowWidth/2 + 100,
    backgroundColor: '#F1FAFF',
    height: 810,
    marginLeft: windowWidth/5 + 10,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 22,
    },
    
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    paddingBottom: 40,
    opacity: 1,
    marginTop: 90,
    borderRadius: 16
  },
  title_header:{
    fontSize: 30,
    fontWeight: 'bold',
    textAlign:"center",
    alignItems:'center',
    alignContent: 'center'
  },
  filterIcon: {
    width: 20,  
    height: 20,   
    position: 'absolute',
    top: 20,   
    right: 20,     
  },

  button: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  typeChild: {
    borderWidth: 0.5,
    borderColor: 'black',
    borderRadius: 10,
    position: 'absolute',
    top: 140,
    left: 25,
    width: windowWidth/2 - 30,
    height: 50,
    justifyContent: 'center'
  },
  dateView: {
    flex: 1,
    margin: -1,
  },
  dashed: {
    borderWidth: 1,
    borderColor: "black",
    borderStyle: "dashed",
    overflow: "visible",
    width: windowWidth / 2 - 20,
    position: 'absolute',
     top:57,
     right: 20
  },
  date: {},
  chooseTypeView: {
    flexDirection: "row",
    marginTop: dimensWidth(10),
    paddingVertical: dimensWidth(25),
    backgroundColor: 'white',
    width: "100%",
    alignItems: "center",
  },

  searchView:{
    flexDirection: "row",
    marginTop: 10,
    backgroundColor: 'white',
    justifyContent: "center",
    width: windowWidth/2 + 20,
    paddingVertical: 20,
    alignItems: "center",
    height: 220,
    alignContent: 'center',
    marginLeft: 40,
    borderRadius: 10,
    borderWidth: 0.5,
    borderColor: 'black'
  },

  type2:{
    flexDirection: "row",
    marginTop: 35,
    backgroundColor: 'white',
    justifyContent: "center",
    width: windowWidth/2 + 20,
    paddingVertical: 20,
    alignItems: "center",
    height: 250,
    alignContent: 'center',
    marginLeft: 40,
    borderRadius: 10,
    borderWidth: 0.5,
    borderColor: 'black'
  },

  typeSignOut:{
    flexDirection: "row",
    marginTop: 35,
    backgroundColor: 'white',
    justifyContent: "center",
    width: windowWidth/2 + 20,
    paddingVertical: 20,
    alignItems: "center",
    height: 87,
    alignContent: 'center',
    marginLeft: 40,
    borderRadius: 10,
    borderWidth: 0.5,
    borderColor: 'black'
  },

  headerView:{
    flexDirection: "row",
    marginTop: dimensWidth(3),
    justifyContent: "center",
    width: "100%",
    paddingVertical: dimensWidth(10),
    alignItems: "center",
    textAlign:'center',
  },

  titleDateSentTo:{
    flexDirection: "row",
    marginTop: dimensWidth(10),
    backgroundColor: 'white',
    justifyContent: "space-between",
    width: "100%",
    paddingVertical: dimensWidth(25),
    alignItems: "center",
  },

  filterDateView: {
    flexDirection: "row",
    backgroundColor: 'white',
  },
  flexDirection: {
    height: dimensWidth(50),
    flexDirection: "row",
    marginTop: dimensWidth(10),
  },
  modalConfirmText: {
    fontSize: FontSize.MEDIUM,
    color: 'white',
    fontWeight: "400",
    fontFamily: "arial",
  },
  modalReFilterText: {
    fontSize: FontSize.SMALL,
    color: "#00524E",
    fontWeight: "400",
    fontFamily: "arial",
  },
  stroke: {
    borderWidth: 1,
    borderColor: "#E5E5E5",
    marginVertical: dimensWidth(7.5),
    borderStyle: "dashed",
  },
  buttonReFilter: {
    height: dimensWidth(34),
    paddingHorizontal: dimensWidth(12),
    borderRadius: dimensWidth(4),
    alignItems: "center",
    justifyContent: "center",
  },
  buttonConfirm: {
    backgroundColor:  "#00524E",
    height: dimensWidth(34),
    paddingHorizontal: dimensWidth(25),
    borderRadius: dimensWidth(4),
    alignItems: "center",
    justifyContent: "center",
  },
  textDate: {
    fontSize: FontSize.MEDIUM,
    color: 'black',
    fontWeight: "400",
    fontFamily: "arial",
    marginVertical: dimensWidth(14),
  },
  textTitleDate: {
    fontSize: FontSize.SMALL,
    color: 'lightblack',
    fontWeight: "400",
    fontFamily: "arial",
    marginTop: dimensWidth(14),
  },
  textType: {
    fontSize: 18,
    color: 'lightblack',
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  textFiltedType: {
    fontSize: 16,
    color: '#0b5e5c',
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 210,
  },
  itemAvatar: {
    height: dimensWidth(27),
    width: dimensWidth(27),
    marginLeft: dimensWidth(5),
    borderRadius: dimensWidth(20),
    marginBottom: 90
  },
  itemIcon: {
    height: dimensWidth(14),
    width: dimensWidth(14),
    marginLeft: dimensWidth(5),

    marginBottom: 130
  },
  title: {
    fontSize: 16,
    width: 200,
    color: 'black',
    fontFamily: 'arial',
    marginTop: 10,
    left: 20
  },
});

export default ModalProfile;
