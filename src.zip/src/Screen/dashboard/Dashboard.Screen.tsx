import { FlatList, Image, RefreshControl, SectionList, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import React, { useCallback, useEffect, useState } from 'react';
import stylesD from './Dashboard.Style';
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from 'redux-thunk';
import { GetListDoucumentFavorite, getDocumentMostView, getUnReadNotify, getViewDocumentNew } from 'stories/dashboard/reducer';
import { arrayIsEmpty } from 'helpers/Functions';
import FastImage from 'react-native-fast-image';
import { ThongBaoIcon, UserGreyIcon } from 'assets/svg';
import { ScrollView } from 'react-native-gesture-handler';
import { FontSize, windowHeight, windowWidth } from 'helpers/Constants';
import HeaderWithAvatar from 'components/HeaderWithAvatar';
import TextCusTom from 'components/TextCusTom';
import NoDataView from 'components/NoDataView';
import colors from 'helpers/Colors';
import { RootState } from 'stories/index';
import DocumentViewItem from './components/DocumentViewItem';
import ModalProfile from './components/ModalProfile';

type Props = {
  navigation: any;
  route: any;
};

//ItemNewDoc
const Item = ({ item, index }: any) => {
  const { Title, IssueDate, Thumbnail } = item
  return (
    <TouchableOpacity style={[stylesD.itemNewDocuments, { backgroundColor: 'rgba(0, 0, 0, 0)' }]}>
      <View style={stylesD.itemNewDocumentsChild}>
        <Image
          style={stylesD.itemNewDocumentsChild}
          source={{ uri: Thumbnail }}
        />
      </View>
      <Text style={stylesD.titleItemNewDoc}>{Title}</Text>
      <Text style={stylesD.dateItemNewDoc}>{IssueDate}</Text>

    </TouchableOpacity>
  )
}


const DashboardScreen = ({navigation}: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const [Offset, setOffset] = useState(0);
  const { languages, languagesText } = useSelector((state: RootState) => state.languages);


  //dataNewDocument
  const dataNewDocument = useSelector(
    (state: any) => state.dashboard
  )
  //documentMostViewList
  const documentMostViewList = useSelector(
    (state:any) => state.dashboard
  )
  //documentFavoriteList
  const documentFavoriteList = useSelector(
    (state:any) => state.dashboard
  )
  const dataRecently: never[] = []
//notificationCount
const notificationCount = useSelector(
  (state: any) => state.dashboard
)

const [refreshing, setRefreshing] = useState(false);
  
  useEffect(() => {
    (async () => {
      await console.log('qurery',);
    })();
  }, []);


  useEffect(() => {
    const langId = languagesText === 'EN' ? 1033 : 1066
    dispatch(getViewDocumentNew(1066))
    // dispatch(GetListDoucumentFavorite(1066))
    dispatch(getDocumentMostView(1066))
    dispatch(getUnReadNotify())
  }, [languagesText])

  const onRefresh = useCallback(() => {
    const langId = languagesText === 'EN' ? 1033 : 1066
    dispatch(getViewDocumentNew(langId))
    // dispatch(GetListDoucumentFavorite(langId))
    dispatch(getDocumentMostView(langId))
    dispatch(getUnReadNotify())
  }, [languagesText]);


//GetNewDocument 
  const fetchGetDataNewDoucumentRequest = useCallback((payload: any) => {
    dispatch(getViewDocumentNew(payload))
  }, [dispatch])
  useEffect(() => {
    fetchGetDataNewDoucumentRequest({ limit: 5, Offset })
  }, [fetchGetDataNewDoucumentRequest])

//GetDoucumentMostView
const fetchGetDoucumentMostViewRequest = useCallback((payload: any) =>{
  dispatch(getDocumentMostView(payload))
}, [dispatch])
useEffect(() => {
  fetchGetDoucumentMostViewRequest({LangId: 1066})
},[fetchGetDoucumentMostViewRequest])

//GetdocumentFavoriteList
const fetchGetDocumentFavoriteRequest = useCallback((payload: any) => {
  dispatch(GetListDoucumentFavorite(payload))
}, [dispatch])
useEffect(() => {
  fetchGetDocumentFavoriteRequest({ limit: 5, Offset })
},[fetchGetDocumentFavoriteRequest])

//notificationCount
const fetchnotificationCountRequest = useCallback(() => {
  dispatch(getUnReadNotify())
}, [dispatch])
useEffect(() => {
  fetchnotificationCountRequest()
},[fetchnotificationCountRequest])

  const [dataHome, setDataHome] = useState<any>([
    {
      data: [
        {
          title: 'Văn bản mới nhất', viewDocumentNewData: dataNewDocument?.dataNewDocument
        },
        { title: 'Vừa xem', recentlyViewedDocumentData: [] },
        { title: 'Văn bản xem nhiều nhất', documentFavoriteData: documentFavoriteList?.dataDocumentFavorite },
        { title: 'Văn bản yêu thích nhất', documentMostViewData: documentMostViewList?.dataDocumentMostView },
      ]
    }
  ]);
  useEffect(() => {
    setDataHome([
      {
        data: [
          {
            title: "Văn bản mới nhất", data: dataNewDocument?.dataNewDocument
          },
          { title: "Văn bản xem gần nhất", data: [] },
          { title: "Văn bản yêu thích", data: documentFavoriteList?.dataDocumentFavorite  },
          { title: "Văn bản xem nhiều nhất", data: documentMostViewList?.dataDocumentMostView},
        ]
      }
    ])
  }, [dataNewDocument, documentMostViewList, documentFavoriteList])

  return (
    <View style={styles.container}>
      <HeaderWithAvatar title={languages.bottomtab_home} notificationCount={notificationCount?.dashboardCountData}  urlOnline={'https://i.pinimg.com/564x/8a/39/1e/8a391e1c786ddc9dce81721033987ff2.jpg'}/>
      <FastImage
            style={styles.vnaBackgroundImage}
            resizeMode='contain'
      source={require('../../../src/assets/images/img_background_home.png')}
    />

      {!arrayIsEmpty(dataHome) ? 
                  (       
                    <SectionList sections={dataHome}
                    refreshControl={
                      <RefreshControl refreshing={refreshing}  onRefresh={onRefresh} tintColor='#0054AE' />
                    }
                    renderItem={({ item }) => (
                      <View>
                        <TextCusTom i18nKey={item.title} style={styles.textTitle} />
                        {!arrayIsEmpty(dataNewDocument.dataNewDocument) ? (
                          <FlatList
                            contentContainerStyle={styles.containerFlatList}
                            data={item.data}
                            horizontal={true}
                            renderItem={({ item }) => (
                              <DocumentViewItem item={item} />//gotoDetail={gotoDetailPress}
                            )}
                            showsHorizontalScrollIndicator={false}
                            keyExtractor={(item: any, index) => item.ID.toString()}
                          />
                        ) :
                          !arrayIsEmpty(dataRecently) ? (
                            <NoDataView onRetryPress={function () {
                              throw new Error("Function not implemented.");
                            } } />
                          ):
                        (
                          <NoDataView onRetryPress={function () {
                            throw new Error("Function not implemented.");
                          } } />
                        )}
                        <View style={styles.line} />
                      </View>
                    )}
                    keyExtractor={(item, index) => item.title}>
                  </SectionList>
                  ):
                  (<NoDataView onRetryPress={function () {
                      throw new Error("Function not implemented.");
                    } } />
                      )}     
  

    </View>
  );
};
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#E2F9FF' },
  containerFlatList: {

  },
  textTitle: { color: '#DBA410', fontSize: 20, fontWeight: '700', margin: 20 },
  line: {
    marginLeft: 20,
    height: 1,
    backgroundColor: 'gray',
    marginTop: 20
  },
  sectionHeader: {
    paddingTop: 2,
    paddingLeft: 10,
    paddingRight: 10,
    paddingBottom: 2,
    fontSize: 22,
    fontWeight: 'bold',
    color: "#fff",
    backgroundColor: '#8fb1aa',
  },
  item: {
    padding: 10,
    fontSize: 18,
    height: 44,
  },
  vnaBackgroundImage: {
    height: windowHeight,
    marginTop: 70,
    width:(windowWidth),
    position: 'absolute',
    zIndex: 0
  }
});
export default React.memo(DashboardScreen);