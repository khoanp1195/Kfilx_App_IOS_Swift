import React, { FC, useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image,  TouchableOpacity, Alert, FlatList, RefreshControl, Animated, ScrollView } from 'react-native';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { useDispatch, useSelector } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaView } from 'react-native-safe-area-context';
import { GetInteractDocument, GetListCommentDocument, GetListNotify, GetListUnreadNotify } from 'stories/dashboard/reducer';
import { arrayIsEmpty } from 'helpers/Functions';
import NoDataView from 'components/NoDataView';
import { FontSize, dimensWidth, windowWidth } from 'helpers/Constants';
import colors from 'helpers/Colors';
 import HTML from 'react-native-render-html';
import FastImage from 'react-native-fast-image';
 import { Col, Row } from 'react-native-flex-grid';
import FastImageCustom from 'components/FastImageCustom';
import styles from './DSBinhLuan.Style';

interface Props {
    modalVisible: Boolean;
    onCloseModal: () => void;
    ActionJson: any;
  }
  const Item = ({ item, gotoDetail, index }: any) => {
    const {
      ID,
      ActionTime,
      Content
    } = item;
    console.log('Content day nha =>>> ' + ActionTime);
    const htmlContent = Content
    let plainText = '';

    const renderers = {
      div: (_: any, children: any) => children,
      label: (_: any, children: any) => children,
      strong: (_: any, children: any) => children,
      textAction: (_: any, children: any) => children,
    };

    // const handleTextExtraction = (text) => {
    //   plainText = text;
    // };

    const isOdd  = index % 2 === 0;

    return (
      <TouchableOpacity style={[styles.item, isOdd && {backgroundColor: '#F1FAFF'} ]}>
            <FastImage
            style={styles.itemAvatar}
            resizeMode='contain'
      source={require('../../../../src/assets/images/icon_itemNotify.png')}
    />
        <View style={{ flex: 1, flexDirection: 'column', marginLeft: 7 }}>
        <Text style={styles.title} numberOfLines={2}>{plainText}</Text>  
       <Text>
         <HTML source={{ html: htmlContent }}/>
       </Text>
          <Text style={styles.date}>{ActionTime}</Text>
        </View>
      </TouchableOpacity>
    );
  };

  const DSBinhLuan: FC<Props> = ({
    modalVisible,
    onCloseModal,
    ...props
  }: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any,any,any>>();
  const [Offset, setOffset] = useState(0);
  const [dataCommentState, setdataCommentState] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  let initialPayloadNotify = { limit:100,offset: Offset}
  let initialPayloadUnReadNotify = { limit:100,offset: Offset,isCount: 0}
  const [payloadNotify, setpayloadNotify] = useState<any>(initialPayloadNotify);
  const [payloadUnReadNotify, setpayloadUnReadNotify] = useState<any>(initialPayloadUnReadNotify);

  const fadeAnim = new Animated.Value(1); // Initialize opacity to 1 (fully visible)


  const dataComment = useSelector(
    (state: any) => state.dashboard
  )
  const isLoadingdataComment = useSelector((state: any) => state.dashboard)

  //fetchGetListDataCommentRequest
  const fetchGetListDataCommentRequest = useCallback((payload: any) => {
        dispatch(GetListCommentDocument(payload))
  }, [dispatch])
  useEffect(() => {
    fetchGetListDataCommentRequest({limit:100, Offset})
  }, [fetchGetListDataCommentRequest])



//onRefresh
  const onRefresh = useCallback(() =>{
    setOffset(0);
    setpayloadNotify(initialPayloadNotify)
    dispatch(GetListNotify(initialPayloadNotify));
    setRefreshing(false);
  },[refreshing]);

  useEffect(() => {
    setdataCommentState(dataComment.dataListComment);
    setRefreshing(false)
  },[dataComment])


  console.log('dataComment.dataListComment - data =>>> ' +  dataComment.dataListComment)


const ItemGrid = ({ item, index }: any) => {
  const {
    Title,
    StorageCode,
    Created,
    Type,
    Thumbnail,
    IsApproved,
    Status,
    Content
  } = item;

  const htmlContent = Content
  const idOdd = index % 2 === 0;
  const formatDate = (dateString: any) => {
    const parsedDate = new Date(dateString);
    const formattedDate =
      parsedDate.toLocaleTimeString().slice(0, 5) + " " +
      parsedDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
      });
    return formattedDate;
  };

  //FormatTextStatusToString
  const FormatTextStatusToString = (itemp: any) => {
      if(item.Status == -1)
      {
        return 'Đã xóa'
      }
      if (item.IsApproved === null || item.IsApproved === 0)
      {
         return "Chờ phê duyệt";
      }
      if (item.IsApproved === 1)
      {
          return "Đã phê duyệt";
      }

      if ((item.IsApproved === 0))
      {
          return "Bị từ chối";
      }
      else
          return "Nodata"
  }

  //ColorStatusToString
  const ColorStatusToString = (itemp: any)  => {
    if(item.Status == -1)
    {
      return '#FFCDCD'
    }
    if (item.IsApproved === null || item.IsApproved === 0)
    {
       return "#D1E9FF";
    }
    if (item.IsApproved === 1)
    {
        return "#D1FECE";
    }

    if ((item.IsApproved === 0))
    {
        return "#FFCDCD";
    }
    else
        return "white"
}

  console.log('IsApproved =>>> ' + item.IsApproved)
  return (
    <ScrollView horizontal style={[styles.viewScrollViewGrid, idOdd && {backgroundColor: '#F1FAFF'}]} >
      <View>
    

        <View key={index} >
    <Row style={styles.cellContent}>
    <Col style={{ padding: 10, width: 210 , flexDirection:'row'}}>
 <FastImage style={{  height: dimensWidth(15),
    width: dimensWidth(15),
    marginLeft: dimensWidth(2),
    }}
     source={{ uri: item.Thumbnail }}
/>
<Text style={{width:320,marginLeft: 10, marginTop: 10,color:'rgb(0, 104, 133)'}}>{item.Title}</Text>
      </Col>
      <Col style={{ padding: 10, width: 210 }}>
        <Text style={{width:270,marginLeft: 80, flexDirection:'row'}}> <HTML source={{ html: htmlContent }}/></Text>
      </Col>
      <Col style={{ marginLeft: -350, padding: 10 }}>
        {/* <Text style={{textAlign: 'center'}}>{item.Title}</Text> */}
      </Col>
      <Col style={{ padding: 10 }}>
        <Text style={{marginLeft: 120}}>{formatDate(item.Created)}</Text>
      </Col>
      <Col style={{ padding: 10 }}>
        <Text style={{marginLeft: 55,width: 170,height:20, borderRadius: 10,textAlign:'center',backgroundColor:ColorStatusToString(item.IsApproved)}}>{FormatTextStatusToString(item.IsApproved)}</Text>
      </Col>
    </Row>
  </View>
      <View>
</View>
      </View>
    </ScrollView>
  );

  
}
  return (
    <SafeAreaView style={{flex: 1}}>
        <View style={styles.container}>
            <View style={{alignItems: 'center'}}>
            <Text style={styles.title_header}>Danh sách bình luận</Text>
            </View>

        <TouchableOpacity
            activeOpacity={1}
            style={{backgroundColor: 'blue'}}
            onPress={onCloseModal}
          >
            {/* <Text style={styles.lbl_thoat} numberOfLines={1}>
              {"X"}
            </Text> */}
                     <FastImage
                  style={styles.icon_back}
                  resizeMode='contain'
                source={require('../../../../src/assets/images/icon_closeForm.png')}
              />
          </TouchableOpacity>

          <View style={styles.flexDirectionRowTab}>
          <View>    
              <Row style={styles.cellHeader}>
          <Col style={[{
            padding: 7,
            marginLeft: 10,
            backgroundColor: '#f0f0f0',
            borderColor: '#ccc',
          }]}>
            <Text style={{fontWeight:'bold'}}>Tên văn bản</Text></Col>
          <Col style={[{
            padding: 7,
            marginLeft: 100,
            backgroundColor: '#f0f0f0',
            borderColor: '#ccc',
          }]}><Text style={{fontWeight:'bold', width: 300}}>Nội dung văn bản</Text></Col>
          <Col style={[{
            padding: 7,
            marginLeft: 220,
            backgroundColor: '#f0f0f0',
            borderColor: '#ccc',
          }]}><Text style={{fontWeight:'bold', width: 200, marginLeft: -10}}>Ngày bình luận</Text></Col>
          <Col style={styles.cellHeader}><Text style={{fontWeight:'bold'}}>Trạng thái</Text></Col>
        </Row>
        </View> 
      
          </View>  

                  {!arrayIsEmpty(dataCommentState) ? 
                  (    
                  <FlatList
                    contentContainerStyle={styles.containerFlatList}
                    data={dataCommentState}
                    extraData={dataCommentState}    
                    refreshControl={
                      <RefreshControl refreshing={isLoadingdataComment} onRefresh={onRefresh} tintColor='#0b5e5c' />
                    }
                    renderItem={({ item, index }) => (     
                          <ItemGrid item={item} index={index}/>// gotoDetail={gotoDetailPress}
                          )
                  }
                    keyExtractor={(item,index) => String(index)}
                    showsVerticalScrollIndicator={false}
                    onEndReachedThreshold={0.5}
                    // onEndReached={handleLoadmore}
                    // ListFooterComponent={renderFooter(isLoadingDangXuLy,refreshing,isLoadMoreDangXuly,Offset)}
                  />
                  ):           
                  (<NoDataView onRetryPress={function () {
                      throw new Error("Function not implemented.");
                    } } />
                      )}
        </View>

    </SafeAreaView>
  );
};

export default DSBinhLuan;
export enum TABNAME {
    TatCa = "Tất cả",
    ChuaXem = "Chưa xem",
  }