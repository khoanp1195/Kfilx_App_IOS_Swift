import React, { useCallback, useEffect, useState } from 'react';
import { View, FlatList, Text, StyleSheet, Image, TouchableOpacity, Alert } from 'react-native';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { useDispatch, useSelector } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import HeaderWithAvatar from 'components/HeaderWithAvatar';
import FastImage from 'react-native-fast-image';
import { dimensWidth, windowHeight, windowWidth } from 'helpers/Constants';
import CustomSearchBar from 'components/CustomSearchBar';
import { SearchIcon } from 'assets/svg';
import { fetchCurrentUsers } from 'stories/dashboard/reducer';
import styles from './lookup.Style';

const LookupScreen = () => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const [searchText, setSearchText] = useState('');
  //dataCurrentUser
  const dataCurentUser = useSelector(
    (state: any) => state.dashboard
  )

  //GetCurrentUser
  const fetchUserProfileRequest = useCallback(() => {
    dispatch(fetchCurrentUsers());
  }, [dispatch])

  useEffect(() => {
    fetchUserProfileRequest();
  }, [fetchUserProfileRequest]);

  const handleSearch = () => {
    // Implement your search logic here
    console.log('Searching for:', searchText);
  };

  const dataString = `${dataCurentUser?.dataCurrentUsers?.TopUsedKey}`
  const inputString = dataString;
  const stringArray = inputString.split(',');
  const objectArray = stringArray.map(item => ({ tittle: item }));
  console.log("objectArray =>>> " + objectArray);

  return (
    <View style={styles.container}>
      <FastImage
        style={styles.vnaBackgroundImage}
        resizeMode='contain'
        source={require('../../../src/assets/images/img_background_home.png')}
      />
      <HeaderWithAvatar title="Tiềm kiếm" />
      <Text style={styles.txtHeader}>Tìm kiếm</Text>

      <CustomSearchBar
        value={searchText}
        onChange={setSearchText}
        onSearch={handleSearch}
      />
      <Text style={styles.subTitle}>Xu hướng</Text>
      <FlatList
        data={objectArray}
        renderItem={({ item, index }) => {
          return (
            <View>
              <TouchableOpacity style={[styles.item, { backgroundColor: 'transparent' }]}>
                <SearchIcon />
                <View style={styles.text}>
                  <Text style={[{ marginTop: 10, color: item.color, marginLeft: 20 }]}>{item.tittle}</Text>
                  {/* <FastImage style={styles.img_content}
                  source={{ uri: path }}
                /> */}
                </View>


              </TouchableOpacity>
              {/* <View style={{ marginTop: 122, justifyContent: 'center', alignContent: 'center', alignItems: 'center' }}>
              <Text style={[{ marginTop: 66, color: item.color }]}>{item.tittle}</Text>
              <Text style={[{ height: 50, marginTop: 10, color: 'gray', width: 210 }]}>{item.Description}</Text>
            </View> */}
            </View>

          )
        }}
        keyExtractor={(item) => item.id}
        numColumns={2} // Number of columns in your collection view
      />
    </View>
  );
};
export default LookupScreen;
