import React, { useCallback, useEffect, useState } from 'react';
import { View,FlatList, Text, StyleSheet, Image,  TouchableOpacity, Alert } from 'react-native';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { useDispatch, useSelector } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import HeaderWithAvatar from 'components/HeaderWithAvatar';
import FastImage from 'react-native-fast-image';
import { dimensWidth, windowHeight, windowWidth } from 'helpers/Constants';
import CustomSearchBar from 'components/CustomSearchBar';
import { SearchIcon } from 'assets/svg';
import { fetchCurrentUsers } from 'stories/dashboard/reducer';

const LookupScreen = () => {
  const dispatch = useDispatch<ThunkDispatch<any,any,any>>();
  const [searchText, setSearchText] = useState('');
    //dataCurrentUser
    const dataCurentUser = useSelector(
      (state: any) => state.dashboard
    )

      //GetCurrentUser
  const fetchUserProfileRequest = useCallback(() => {
    dispatch(fetchCurrentUsers());
  }, [dispatch])

  useEffect(() => {
    fetchUserProfileRequest();
  }, [fetchUserProfileRequest]);

  const handleSearch = () => {
    // Implement your search logic here
    console.log('Searching for:', searchText);
  };
 
  const data = [
    { id: '1', text: 'Item 1' },
    { id: '2', text: 'Item 2' },
    { id: '3', text: 'Item 3' },
    { id: '4', text: 'Item 4' },
    { id: '5', text: 'Item 5' },
    { id: '6', text: 'Item 6' },
    // Add more items as needed
  ];
  const dataString = `${dataCurentUser?.dataCurrentUsers?.TopUsedKey}`
  const inputString = dataString;
  const stringArray = inputString.split(',');
  const objectArray = stringArray.map(item => ({ tittle: item }));
  console.log("objectArray =>>> " + objectArray);
  


return (
    <View style={styles.container}>
          <FastImage
        style={styles.vnaBackgroundImage}
        resizeMode='contain'
        source={require('../../../src/assets/images/img_background_home.png')}
      />
       <HeaderWithAvatar title="Tiềm kiếm"/>
        <Text style={styles.txtHeader}>Tìm kiếm</Text>

        <CustomSearchBar
        value={searchText}
        onChange={setSearchText}
        onSearch={handleSearch}
      />
              <Text style={styles.subTitle}>Xu hướng</Text>
              <FlatList
      data={objectArray}
      renderItem={({ item, index }) =>{
        return (
          <View>
            <TouchableOpacity style={[styles.item, { backgroundColor: 'transparent' }]}>
            <SearchIcon/>
              <View style={styles.text}>
              <Text style={[{ marginTop: 10 , color: item.color,marginLeft: 20 }]}>{item.tittle}</Text>
                {/* <FastImage style={styles.img_content}
                  source={{ uri: path }}
                /> */}
              </View>


            </TouchableOpacity>
            {/* <View style={{ marginTop: 122, justifyContent: 'center', alignContent: 'center', alignItems: 'center' }}>
              <Text style={[{ marginTop: 66, color: item.color }]}>{item.tittle}</Text>
              <Text style={[{ height: 50, marginTop: 10, color: 'gray', width: 210 }]}>{item.Description}</Text>
            </View> */}
          </View>

        )
      }}
      keyExtractor={(item) => item.id}
      numColumns={2} // Number of columns in your collection view
    />

    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffff',
  },
  img_content: {
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    height: dimensWidth(40),
    width: dimensWidth(40), alignContent: 'center',
    elevation: 4,
    borderRadius: 8,

  },
  
  txtHeader:{
    fontSize: 35,
    fontWeight: '600',
    padding: 30,
    marginLeft: 140
  },
  text: {
    justifyContent: 'center',
    alignContent: 'center',
    alignItems: 'center',
    flexDirection:'row'
  },
  item: {
    margin:10, 
    padding: 16,
    backgroundColor: 'transparent',
    borderRadius: 8,
    marginLeft: 200,
    width: 200,
    marginHorizontal:100,
    flexDirection: 'row'


  },
  subTitle:{
    fontSize: 22,
    fontWeight: '600',
    padding: 30,
    marginLeft: 140
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 16,
  },
  fullName: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 100,
    textAlign: 'center',
    color:'#0b5e5c'

  },
  fieldContainer: {
    flex: 1,
  },
  fieldLabel: {
    marginRight: 8,
    fontSize: 18,   
     color: 'rgba(128, 128, 128, 0.5)',
  },
fieldTitle:{
  marginStart: 10
},
 
  image: {
    width: 100,
    height: 100,
    borderRadius: 50, // Make the image round for an avatar effect
    marginBottom: -65, 
  },

  grayLine: {
    width: '90%', // Set the desired width of the line
    height: 1, 
    marginLeft: 10,   // Set the height of the line
    backgroundColor: 'rgba(128, 128, 128, 0.3)', // Gray color
  },
  vnaBackgroundImage: {
    height: windowHeight,
    marginTop: 70,
    width: (windowWidth),
    position: 'absolute',
    zIndex: 0
  },

});

export default LookupScreen;
