import React, { useCallback, useEffect, useState } from 'react';
import { View, FlatList, Text, StyleSheet, Image, TouchableOpacity, Alert, TextInput } from 'react-native';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { useDispatch, useSelector } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import HeaderWithAvatar from 'components/HeaderWithAvatar';
import FastImage from 'react-native-fast-image';
import { dimensWidth, windowHeight, windowWidth } from 'helpers/Constants';
import CustomSearchBar from 'components/CustomSearchBar';
import { SearchIcon } from 'assets/svg';
import { fetchCurrentUsers, getAutoLoginMobile } from 'stories/dashboard/reducer';
import styles from './LookupDetail.Style';
import { RootState } from 'stories/index';
import { useNavigation } from '@react-navigation/native';
import { WebView } from 'react-native-webview';
import LoadingDots from "react-native-loading-dots";
type Props = {
  navigation: any
  route: any
}

const LookupDetail = ({route,navigation}: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const {searchKey} = route.params
  const autoId  = useSelector((state: RootState) => state.dashboard);
  const [searchText, setSearchText] = useState('');
  const { languages, languagesText } = useSelector((state: RootState) => state.languages);
  const dataCurentUser = useSelector(
    (state: any) => state.dashboard
  )
  const [isShowWebView, setisShowWebView] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  //GetCurrentUser
  const fetchUserProfileRequest = useCallback(() => {
    dispatch(fetchCurrentUsers());
  }, [dispatch])

  useEffect(() => {
    fetchUserProfileRequest();
  }, [fetchUserProfileRequest]);

  const handleSearch = () => {
    SearchData(searchText);
    // searchKey = searchText

    console.log('Searching for:', searchText);
  };

   // Function to handle WebView load finish
   const handleWebViewLoadFinish = () => {
    // Set isLoading to false when the WebView finishes loading
    setIsLoading(false);
  };

  // const handleBeginEditing = () => {
  //   // Show data, load search keys, and focus the text input
  //   ShowData();
  //   LoadSearchKeysData();
  //   FocusTextField(true);
  // };

  // const handleEndEditing = () => {
  //   // Unfocus the text input
  //   FocusTextField(false);
  // };

  const dataString = `${dataCurentUser?.dataCurrentUsers?.TopUsedKey}`
  const inputString = dataString;
  const stringArray = inputString.split(',');
  const objectArray = stringArray.map(item => ({ tittle: item }));
  console.log("objectArray =>>> " + objectArray);


  const encodedSearchKey = searchKey.replace(/\+/g, "%20");
  const loginKey = autoId; // Replace with your actual login key
  const langId = languagesText === 'EN' ? 1033 :1066
  
  const baseUrl = `https://vnadmsuatportal.vuthao.com/psd/frontend/pages/VNASearchDocument.aspx`;
  const queryParams = {
    kwd: encodedSearchKey,
    searchunittype: 0,
    gid: 1,
    autoid: loginKey,
    lang: langId,
  };
  
  let url  
//baseUrl + '?' + Object.entries(queryParams).map(([key, value]) => `${key}=${value}`).join('&');
  const SearchData = (key: any) => {
    // searchKey = key;
  
    // if (!searchKeys.includes(key)) {
    //   if (searchKeys.length === 10) {
    //     searchKeys.shift();
    //   }
    //   searchKeys.push(key);
    // }
    url = baseUrl + '?' + Object.entries(queryParams).map(([key, value]) => `${key}=${value}`).join('&');
    setisShowWebView(true)
    console.log("SearchData - URL =>> " + url)
 
  };

  

  const gotoBack = useCallback(
    () => {
      navigation.navigate({
        name: "LookupScreen",
      });
    },
    [dispatch, navigation],
  )

  return (
    <View style={styles.container}>
      <FastImage
        style={styles.vnaBackgroundImage}
        resizeMode='contain'
        source={require('../../../../src/assets/images/img_background_home.png')}
      />
      <HeaderWithAvatar item={dataCurentUser.dataCurrentUsers} title={languages.tab_search} urlOnline={dataCurentUser.dataCurrentUsers?.ImagePath} />
<View style={{flexDirection:'row', marginTop: 30}}>

    <TextInput
        value={searchText}
        onChange={setSearchText}
        onSubmitEditing={handleSearch}
        style={styles.input} 
         searchKey= {searchKey}
      />
<TouchableOpacity onPress={() => gotoBack()} style ={{marginLeft: 20}}>
        <Text>Cancel</Text>
      </TouchableOpacity>
</View>
    
   
      <View style = {styles.containerWebview}>
      <WebView
             source={{
               uri: `${url}`
             }}
             sharedCookiesEnabled
             thirdPartyCookiesEnabled
             allowFileAccess
             cacheEnabled
             onLoad={() => handleWebViewLoadFinish()} // Call the function when WebView finishes loading
             style={styles.webview}
       />
      </View>
        



    </View>
  );
};
export default LookupDetail;

