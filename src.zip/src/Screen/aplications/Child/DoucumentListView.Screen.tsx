import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Alert, ScrollView, FlatList } from 'react-native';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { useDispatch, useSelector } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import SortableGridView from 'react-native-sortable-gridview'
import { GetCategoryFromServer, GetListSubCategory } from 'stories/category/reducer';
import FastImage from 'react-native-fast-image';
import { FontSize, dimensWidth, windowHeight, windowWidth } from 'helpers/Constants';
import HeaderWithAvatar from 'components/HeaderWithAvatar';
import { fetchCurrentUsers } from 'stories/dashboard/reducer';
import { RootState } from 'stories/index';
import styles from './DoucumentListView.Style';
import HeaderDetail from 'components/HeaderDetail';
import Header from 'components/Header';
import colors from 'helpers/Colors';
import FastImageCustom from 'components/FastImageCustom';
import ModalLeftMenu from './ModalLeftMenu';
import { arrayIsEmpty, format_dd_mm_yy } from 'helpers/Functions';
import NoDataView from 'components/NoDataView';

import TextCusTom from 'components/TextCusTom';

type Props = {
  navigation: any
  route: any
}
const DocumentItem = ({ gotoDetail, item, index }: any) => {

  const formatDate = format_dd_mm_yy(item?.PublishDate)
  console.log("item?.Thumbnail" + item?.Thumbnail)
  return (
    <TouchableOpacity onPress={() => gotoDetail(item)} style={[stylesDoucument.itemNewDocuments, { backgroundColor: 'rgba(0, 0, 0, 0)' }]}>
    <View style={stylesDoucument.itemNewDocumentsChild}>
    <FastImage style={{
              height: dimensWidth(15),
              width: dimensWidth(15),
              marginLeft: dimensWidth(2),
            }}
              source={{ uri: item?.Thumbnail }}
            />
    </View>
    <TextCusTom i18nKey={item?.Title} style={stylesDoucument.titleItemNewDoc} numberOfLines={2} />
    <TextCusTom i18nKey={formatDate} style={stylesDoucument.dateItemNewDoc} />
  </TouchableOpacity>
  )
}

const DoucumentListView = ({ route }: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const [dataCategoryState, setdataCategoryState] = useState([]);
  const dataSubCategory = useSelector(
    (state: any) => state.category
  )
  const currentUser = useSelector((state: any) => state.dashboard);
  const { languages, languagesText } = useSelector((state: RootState) => state.languages);
  const {
    dataCurrentUser,
  } = currentUser;
  const [visibleModalLeftMenu, setvisibleModalLeftMenu] = useState(false);
  const [dataSubCategoryState, setdataSubCategoryState] = useState([]);
  const { id } = route.params
  const [Offset, setOffset] = useState(0);

  useEffect(() => {
    dispatch(fetchCurrentUsers());
  }, [languagesText])
  const onReModalPress = useCallback(() => {
    setvisibleModalLeftMenu(false);
  }, [visibleModalLeftMenu]);

  //GetListSubCategory
  useEffect(() => {
    const limit = 20;
    const langId = languagesText === 'EN' ? 1033 : 1066
    const payload = { limit, Offset, id, langId };
    dispatch(GetListSubCategory(payload));
  }, [dispatch]);

  useEffect(() => {
    setdataSubCategoryState(dataSubCategory?.dataSubCategory);
  }, [dataSubCategory])
  //documents = documents.OrderByDescending(o => o.IssueDate).ToList();
  // console.log("dataSubCategory " + dataSubCategory)
  const onPressLeftMenu = useCallback(() => {
    // setVisible(true)
    setvisibleModalLeftMenu(true);
  }, [visibleModalLeftMenu])
  return (
    <View style={{ flex: 1, backgroundColor: colors.white }}>
      <HeaderWithAvatar item={currentUser.dataCurrentUsers} title={languages.tab_category} urlOnline={currentUser.dataCurrentUsers?.ImagePath} isCategory={true} />
      <View style={styles.view_header}>
        <TouchableOpacity style={{ marginTop: 20 }} onPress={onPressLeftMenu}>
          <FastImage
            style={styles.icon_back}
            resizeMode='contain'
            source={require('../../../assets/images/icon_menu_category.png')}
          />
        </TouchableOpacity>
        <Text style={styles.txtHeader}>Loại văn bản</Text>
        <View style={styles.imgUser}>

          <TouchableOpacity style={styles.view_right}>
            <FastImage
              style={styles.icon_back}
              resizeMode='contain'
              source={require('../../../assets/images/icon_changeTypeCategory.png')}
            />
          </TouchableOpacity>


        </View>
        <View style={styles.dashed} />
        <View style={{ marginTop: 100 }}>
          {!arrayIsEmpty(dataSubCategoryState) ? (
            <View style={{ marginLeft: -160, height: windowHeight, width: windowWidth, backgroundColor: 'gray' }}>
              <ScrollView>
                <SortableGridView
                  data={dataSubCategory?.dataSubCategory}
                  numPerRow={5} // let each row has four items. Default is 3
                  aspectRatio={1.2} // let height = width * 1.2. Default is 1
                  gapWidth={8} // let the gap between items become to 8. Default is 16
                  paddingTop={8} // let container's paddingTop become to 8. Default is 16
                  paddingBottom={8} // let container's paddingBottom become to 8. Default is 16
                  paddingLeft={8} // let container's paddingLeft become to 8. Default is 16
                  paddingRight={8} // let container's paddingRight become to 8. Default is 16
                  onDragStart={() => {
                    console.log('CustomLayout onDragStart');
                  }}
                  onDragRelease={(data) => {
                    console.log('CustomLayout onDragRelease', data);
                  }}
                  renderItem={({ item, index }) => (
                    <DocumentItem item={item} index={index} />
                  )}
                />
              </ScrollView>
            </View>
          ) : (
            <NoDataView />
          )}


        </View>


      </View>



      <ModalLeftMenu
        onPressFilter={onPressLeftMenu}
        modalVisible={visibleModalLeftMenu}
        onReFilterModal={onReModalPress}
        ID={dataSubCategory?.dataSubCategory?.ID}

      />
    </View>
  );
};


export default DoucumentListView;
const stylesDoucument = StyleSheet.create({
  itemContainer: {
    width: 160,
    height: 250,
    marginLeft: 20
  },
  imgThumbnail: {
    height: 200,
    width: 160
  },
  cap1: {
    fontSize: FontSize.SMALL,
    color: colors.text_grey26,
    fontWeight: '400',
    marginTop: 7,
    textAlign: 'center'
  },
  // itemNewDocuments: {
  //   flexDirection: 'row',
  //   backgroundColor: 'rgba(0, 0, 0, 0)',
  //   marginHorizontal: dimensWidth(15),
  //   borderRadius: 5,
  //   width: 100,
  //   height: 350,

  //   paddingHorizontal: 98,
  //   marginLeft: 31
  // },

  itemNewDocuments: {
    flexDirection: 'row',
    backgroundColor: 'rgba(0, 0, 0, 0)',
    marginHorizontal: dimensWidth(15),
    borderRadius: 5,
    width: 100,
    height: 350,

    paddingHorizontal: 98,
    marginLeft: 31,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,

  },
  itemNewDocumentsChild: {
    flexDirection: 'row',
    backgroundColor: 'white',
    borderRadius: 3,
    width: 185,
    height: 270,
    borderColor: 'lightgray',
    borderWidth: 0.5,
    position: 'absolute',
  },

  titleItemNewDoc: {
    position: 'absolute',
    bottom: 30,
    right: -5,
    width: 210,
    textAlign: 'center',
    color: '#262626',
    fontSize: 15,
    fontWeight: 'bold'


  },
  dateItemNewDoc: {
    position: 'absolute',
    textAlign: 'center',
    alignItems: 'center',
    bottom: 5,
    color: '#7B7B7B',
    right: 65,

  },
})