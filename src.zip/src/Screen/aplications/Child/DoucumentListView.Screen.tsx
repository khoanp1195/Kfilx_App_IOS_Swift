import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Alert, ScrollView } from 'react-native';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { useDispatch, useSelector } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import SortableGridView from 'react-native-sortable-gridview'
import { GetCategoryFromServer, GetListSubCategory } from 'stories/category/reducer';
import FastImage from 'react-native-fast-image';
import { dimensWidth, windowHeight, windowWidth } from 'helpers/Constants';
import HeaderWithAvatar from 'components/HeaderWithAvatar';
import { fetchCurrentUsers } from 'stories/dashboard/reducer';
import { RootState } from 'stories/index';
import styles from './DoucumentListView.Style';
import HeaderDetail from 'components/HeaderDetail';
import Header from 'components/Header';
import colors from 'helpers/Colors';
import FastImageCustom from 'components/FastImageCustom';
import ModalLeftMenu from './ModalLeftMenu';

type Props = {
  navigation: any
  route: any
}

const DoucumentListView = ({route}: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const [dataCategoryState, setdataCategoryState] = useState([]);
  const dataSubCategory = useSelector(
    (state: any) => state.category
  )
  const currentUser = useSelector((state: any) => state.dashboard);
  const { languages, languagesText } = useSelector((state: RootState) => state.languages);
  const {
    dataCurrentUser,
  } = currentUser;
  const [visibleModalLeftMenu, setvisibleModalLeftMenu] = useState(false);
  const [dataSubCategoryState, setdataSubCategoryState] = useState([]);
  const {id} = route.params
  const [Offset, setOffset] = useState(0);

  useEffect(() => {
    dispatch(fetchCurrentUsers());
  }, [languagesText])
  const onReModalPress = useCallback(() => {
    setvisibleModalLeftMenu(false);
  }, [visibleModalLeftMenu]);

  console.log('dataCategory?.dataCategory?.ID =>> ' + id)

    //fetchGetDataCategory
    useEffect(() => {
      const limit = 20;
      const payload = { limit, Offset, id };
      dispatch(GetListSubCategory(payload));
    }, [dispatch, Offset, id]); 

    useEffect(() => {
      setdataSubCategoryState(dataSubCategory?.dataSubCategory);
    }, [dataSubCategory])
  console.log("dataSubCategory " + dataSubCategory)
    
  const onPressLeftMenu = useCallback(() => {
    // setVisible(true)
    setvisibleModalLeftMenu(true);
  }, [visibleModalLeftMenu])
return (
  <View style={{ flex: 1, backgroundColor: colors.white }}>
 <HeaderWithAvatar item={currentUser.dataCurrentUsers} title={languages.tab_category}  urlOnline={currentUser.dataCurrentUsers?.ImagePath} isCategory ={true} />
  <View style={styles.view_header}>
  <TouchableOpacity style={{marginTop: 20}} onPress={onPressLeftMenu}>
                <FastImage
                    style={styles.icon_back}
                    resizeMode='contain'
                    source={require('../../../assets/images/icon_menu_category.png')}
                />
            </TouchableOpacity>
            <Text style={styles.txtHeader}>Loại văn bản</Text>
            <View style={styles.imgUser}>
              
            <TouchableOpacity style={styles.view_right}>
            <FastImage
                    style={styles.icon_back}
                    resizeMode='contain'
                    source={require('../../../assets/images/icon_changeTypeCategory.png')}
                />
          </TouchableOpacity>
      
         
      </View>
  <View style={styles.dashed} />
  <SortableGridView
          data={dataSubCategory?.dataSubCategory}
          numPerRow={5} // let each row has four items. Default is 3
          aspectRatio={1.2} // let height = width * 1.2. Default is 1
          gapWidth={8} // let the gap between items become to 8. Default is 16
          paddingTop={8} // let container's paddingTop become to 8. Default is 16
          paddingBottom={8} // let container's paddingBottom become to 8. Default is 16
          paddingLeft={8} // let container's paddingLeft become to 8. Default is 16
          paddingRight={8} // let container's paddingRight become to 8. Default is 16
          renderItem={(item, index) => {
            return (
              <View>
                <TouchableOpacity style={[styles.item, { backgroundColor: '#E2F9FF' }]}>
                  <View style={styles.text}>
             


                  </View>


                </TouchableOpacity>
                <View style={{ marginTop: 122, justifyContent: 'center', alignContent: 'center', alignItems: 'center' }}>
                  <Text style={[{ marginTop: 66, color: item.color }]}>{item.Title}</Text>
                  <Text style={[{ height: 50, marginTop: 10, color: 'gray', width: 210 }]}>{item.Description}</Text>
                </View>
              </View>

            )
          }}
        />
  </View>

  

  <ModalLeftMenu
        onPressFilter={onPressLeftMenu}
        modalVisible={visibleModalLeftMenu}
        onReFilterModal={onReModalPress}
         ID={dataSubCategory?.dataSubCategory?.ID}
        
      />
</View>
  );
};


export default DoucumentListView;
