import { StyleSheet, Platform, Dimensions } from 'react-native';
import { dimensWidth, dimnensHeight, FontFamily, FontSize, windowHeight, windowWidth } from 'helpers/Constants';
import { Colors } from 'react-native/Libraries/NewAppScreen';
import colors from 'helpers/Colors';
const window = Dimensions.get('window');
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffff',
  },
  separator: {
    height: 40, // Adjust the height to control the spacing between items
  },
  imgUser: {
    position: 'absolute',
    right: -40,
    top: 40,
  },
  cellHeader: {
    padding: 7,
    width: windowWidth - 90,
    backgroundColor: '#f0f0f0',
    borderColor: '#ccc',
    marginLeft: -200,
    paddingHorizontal: 60,
    position: 'absolute',
    top: 80
  },
  textHeaderRight: {
    color: colors.black_121,
    fontSize: 16,
    fontWeight: '400',
    fontFamily: FontFamily.HERITAGE_REGULAR,
    width: 100,
    textAlign: 'center',
    marginBottom: 30,
    marginRight: 120,
    height: 30
  },
  textHeaderLeft: {
    color: colors.black_121,
    fontSize: 16,
    fontWeight: '400',
    fontFamily: FontFamily.HERITAGE_REGULAR,
    width: 120,
    textAlign: 'center',
    marginBottom: 30,
    marginLeft: -220,
  },



  textHeader_category: {
    color: colors.black_121,
    fontSize: 16,
    fontWeight: '400',
    fontFamily: FontFamily.HERITAGE_REGULAR,
    width: 100,
    marginBottom: 30,
    marginRight: windowWidth / 4
  },
  textHeader_category_first: {
    color: colors.black_121,
    fontSize: 16,
    fontWeight: '400',
    fontFamily: FontFamily.HERITAGE_REGULAR,
    width: 100,
    marginBottom: 30,
    marginRight: windowWidth / 7
  },

  headerContainer: {
    paddingTop: 25,
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    backgroundColor: '#F0F0F0',
    height: 70,
    marginTop: 100,
    marginLeft: 45,
    width: windowWidth - 80,
    borderRadius: 8,
    position: 'absolute'
    

  },
  flexDirectionRowTab: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'baseline',
    marginLeft: 16,
    marginTop: 75,
    backgroundColor: '#F0F0F0',//colors.tab_bg_blue,
    borderColor: 'gray',
    padding: 0,
    width: windowWidth - 40,
    height: dimensWidth(15),
  },
  itemNewDocumentsChild: {
    flexDirection: 'row',
    backgroundColor: 'white',
    borderRadius: 3,
    width: 185,
    height: 270,
    borderColor: 'lightgray',
    borderWidth: 0.5,
    position: 'absolute',
  },
  containerFlatList: {
    width: windowWidth - 40,
    marginLeft: 16,
    height: 500,
    marginTop: 120
  },
  img_content: {
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    height: dimensWidth(40),
    width: dimensWidth(40), alignContent: 'center',
    elevation: 4,
    borderRadius: 8,

  }, dashed: {
    borderWidth: 1,
    borderColor: "lightgray",
    width: windowWidth - 40,
    position: 'absolute',
    top: 70,
    left: 17
  },
  text: {
    justifyContent: 'center',
    alignContent: 'center',
    alignItems: 'center'
  },
  textDescription: {
    marginTop: 10
  },

  item: {
    flexDirection: 'row',
    backgroundColor: 'white',
    borderRadius: 3,
    width: 200,
    height: 270,
    borderColor: 'lightgray',
    borderWidth: 0.5,
    position: 'absolute',

  },


  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 16,
  },
  vnaBackgroundImage: {
    height: windowHeight,
    marginTop: 70,
    width: (windowWidth),
    position: 'absolute',
    zIndex: 0
  },
  fullName: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 100,
    textAlign: 'center',
    color: '#0b5e5c'

  },
  cellContent: {
    width: windowWidth,
    height: 70
  },
  fieldContainer: {
    flex: 1,
  },
  fieldLabel: {
    marginRight: 8,
    fontSize: 18,
    color: 'rgba(128, 128, 128, 0.5)',
  },
  fieldTitle: {
    marginStart: 10
  },
  viewScrollViewGrid: {
    flexDirection: 'row',
    width: windowWidth - 85,
    marginLeft: 40,
    padding : -20
  },

  fieldValue: {
    marginLeft: 20,
    fontSize: 18,
    color: '#0b5e5c',

  },
  icon: {
    marginRight: 10,
  },
  viewTitle1: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 116,
    backgroundColor: '#FFFF',
  },

  viewTitleInfo: {
    flexDirection: 'row',
    paddingVertical: 10,
    paddingHorizontal: 20,
    height: 50,
    backgroundColor: '#FFFF',
  },


  fieldTitle1: {
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 20,
    color: '#0b5e5c',
  },

  viewTitle2: {
    height: 220,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(128, 128, 128, 0.2)',

  },
  image: {
    width: 100,
    height: 100,
    borderRadius: 50, // Make the image round for an avatar effect
    marginBottom: -65,
  },

  grayLine: {
    width: '90%', // Set the desired width of the line
    height: 1,
    marginLeft: 10,   // Set the height of the line
    backgroundColor: 'rgba(128, 128, 128, 0.3)', // Gray color
  },


  buttunSignout: {
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 40,
    backgroundColor: '#ffff',
    borderColor: '#0b5e5c'
  },

  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  signInButton: {
    backgroundColor: '#ffff', // Blue color
    paddingVertical: 10,
    paddingHorizontal: 20,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
    width: 200,
    height: 50,
    borderColor: '#0b5e5c',
    borderWidth: 1

  },
  buttonText: {
    color: '#0b5e5c',
    fontWeight: 'bold',
    fontSize: 18,
  },
  view_header: {
    height: 80,
    flexDirection: 'row'
  },
  itemIcon: {
    height: dimensWidth(10),
    width: dimensWidth(10),
    marginLeft: dimensWidth(5),
  },
  titleHeader: {
    fontSize: 16,
    width: 200,
    color: '#7E7E7E',
    fontFamily: 'arial',
    left: 20
  },
  txtHeader: {
    fontSize: 20,
    fontWeight: '600',
    color: '#000000',
    marginLeft: 25,
    marginTop: 20
  },
  icon_back: {
    height: dimensWidth(15),
    width: dimensWidth(12),
    marginLeft: dimensWidth(7),
    marginTop: -10
  },
  view_right: {
    flex: 1, position: 'absolute', right: 80,
    top: -20
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backdrop: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.6)', // Semi-transparent black
  },
  menu: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 8,
    zIndex: 1, // Ensure menu appears above the backdrop
  },
});

export default styles;