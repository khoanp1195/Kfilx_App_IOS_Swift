const TABLE = {
    TASKFORM: 'taskform',
};

export { TABLE };
