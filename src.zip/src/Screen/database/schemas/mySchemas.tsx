import { appSchema, tableSchema } from '@nozbe/watermelondb';

import TaskFormSchema from '../TaskFormSchema';

export const mySchema = appSchema({
  version: 1,
  tables: [tableSchema(TaskFormSchema)],
});
