import { Model } from '@nozbe/watermelondb';
import { field, writer } from '@nozbe/watermelondb/decorators';
import { TABLE } from './contains';

export default class TaskFormModel extends Model {
    static table = TABLE.TASKFORM;

    @field('notificationCount') notificationCount: unknown;
    @field('documentNewList') documentNewList: unknown;
    @field('recentlyViewedDocs') recentlyViewedDocs: unknown;
    @field('documentFavoriteList') documentFavoriteList: unknown;
    @field('documentMostViewList') documentMostViewList: unknown;
    // @writer async delete() {
    //     await super.destroyPermanently();
    // }

    // @writer async updateForm(body) {
    //     await this.update(form => {
    //         form.notificationCount = body.notificationCount;
    //         form.documentNewList = body.documentNewList;
    //         form.recentlyViewedDocs = body.recentlyViewedDocs;
    //         form.documentFavoriteList = body.documentFavoriteList;
    //         form.documentMostViewList = body.documentMostViewList;
    //     });
    // }
}
