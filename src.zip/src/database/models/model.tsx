import { Model } from '@nozbe/watermelondb';

export default class Task extends Model {
    static table = 'taskform';
}
