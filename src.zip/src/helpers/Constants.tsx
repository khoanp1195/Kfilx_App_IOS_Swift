import {Dimensions} from 'react-native';
const DEV_URL = 'https://vnadmsportal.vuthao.com';
const UAT_URL = 'https://vnadmsuatportal.vuthao.com';
const LIVE_url = 'https://lib.vietnamairlines.com'; // LIVE
export const BASE_URL = UAT_URL;
export const RESONSE_STATUS_SUCCESS = 'SUCCESS';
export const RESONSE_STATUS_NONE = 'NONE';
export const RESONSE_STATUS_ERROR = 'ERR';
export const Subsite = 'psd'

export const windowWidth = Dimensions.get('window').width;
export const dimensWidth = (width: any) => (width * windowWidth) / 414;
export const windowHeight = Dimensions.get('window').height;
export const dimnensHeight = (height: any) => (height * windowHeight) / 736;
export const M_DataLimitRow = 15
export const M_DataFilterAPILimitData = 20
export const FontSize = {
  SMALL1: dimensWidth(12),
  SMALL: dimensWidth(14),
  TEXT15: dimensWidth(15),
  MEDIUM: dimensWidth(16),
  LARGE: dimensWidth(18),
  LARGE_X: dimensWidth(20),
  LARGE_XX: dimensWidth(22),
  LARGE_XXX: dimensWidth(24),
};
export const FontFamily = {
  HERITAGE_BOLD: 'heritage_bold', //fontStyle="normal",fontWeight="800"
  HERITAGE_ITALIC: 'heritage_italic', //fontStyle="italic",fontWeight="400"
  HERITAGE_REGULAR: 'heritage_regular' //fontStyle="normal",fontWeight="400"
}
export enum BarStyle {
  darkContent = 'dark-content',
  lightContent = 'light-content',
}

export const bottomTabName = {
  TrangChu: 'Trang chủ',
  Application: 'Danh mục',
  Lookup: 'Tìm kiếm',
  Favorite: 'Mục yêu thích',
};

export enum DEFAULT_LANGUAGE_TEXT  {
  ENGLISH = 'EN',
  VIETNAM ='VI',
}