import * as React from "react";
import Svg, { Path } from "react-native-svg";

function SvgComponent(props) {
  return (
    <Svg
      width={11}
      height={18}
      viewBox="0 0 11 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        d="M9.303 17.167l.859-.835a.52.52 0 00.171-.384.52.52 0 00-.171-.384L3.409 9l6.752-6.563a.52.52 0 00.172-.384.52.52 0 00-.172-.384L9.302.834a.55.55 0 00-.79 0L.505 8.616A.521.521 0 00.333 9a.52.52 0 00.172.384l8.007 7.783a.55.55 0 00.79 0z"
        fill="#006885"
      />
    </Svg>
  );
}

export default SvgComponent;
