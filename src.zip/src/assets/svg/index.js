import UserGreyIcon from "./ic_user_grey.js";
import PasswordGreyIcon from "./ic_password_grey.js";
import HideGreyIcon from "./ic_hide_grey.js";
import ClearTextRedIcon from "./ic_clear_text_red.js";
import DanhMucIcon from './ic_bottom_danhmuc.js'
import ThongBaoIcon from './ic_thongbao.js'
import BottomTabCategoryIcon from "./ic_bottomtab_category.js";
import BottomTabFavouriteIcon from "./ic_bottomtab_favourite.js";
import BottomTabHomeIcon from "./ic_bottomtab_home.js";
import BottomTabSearchIcon from "./ic_bottomtab_search.js";
import NotificationIcon from "./ic_notification.js";
import BackIcon from "./ic_back.js";
import SearchIcon from "./ic_iconSearch"
export { UserGreyIcon, HideGreyIcon, PasswordGreyIcon, ClearTextRedIcon,DanhMucIcon,ThongBaoIcon,
    BottomTabCategoryIcon,
    BottomTabHomeIcon,
    BottomTabSearchIcon,
    BottomTabFavouriteIcon, 
    NotificationIcon,
    BackIcon,
    SearchIcon};
