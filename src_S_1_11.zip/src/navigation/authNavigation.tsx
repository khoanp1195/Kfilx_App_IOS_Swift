import LoginScreen from "../screen/login/LoginScreen";
import {TabsScreen} from "../screen/tab/TabScreen";
import {AppNavigationContainer} from "./AppNavigationContainer";
import {useSelector} from "react-redux";
import {View} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
export const AuthNavigation = () => {
    const isAuth = useSelector((state: any) => state.auth.isAuth);
    return (
        <SafeAreaView style={{    flex: 1,
            backgroundColor: 'white',
            width:'100%',
            height: '100%',
            marginBottom: 0,
            marginTop: 35}}>
            <View style={{flex: 1}}>{!isAuth ? <LoginScreen /> : <AppNavigationContainer />}</View>
        </SafeAreaView>
    
);
};
