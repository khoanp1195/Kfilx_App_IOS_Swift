import DeviceInfo from 'react-native-device-info';
export async function getDeviceInfo() {
    return JSON.stringify({
        AppVersion: DeviceInfo.getReadableVersion(),
        DeviceId: DeviceInfo.getDeviceId(),
        DeviceModel: DeviceInfo.getModel(),
        DeviceName: await DeviceInfo.getDeviceName(),
        DeviceOS: 1,
        DeviceOSVersion: DeviceInfo.getSystemVersion(),
        DevicePushToken: '',
    });
}
