import * as React from "react";
import { useState } from "react";
import { SegmentedButtons } from "react-native-paper";

export const CustomSegmentedButtons = ({ buttons, style, ...props }) => {
  const [value, setValue] = useState(null);
  return (
    <SegmentedButtons
      value={value}
      onValueChange={setValue}
      buttons={buttons.map((button) => ({
        ...button,
        label: button.customLabel || button.label,
        style: {
          ...button.style,
          borderWidth: 0,
        },
      }))}
      style={[
        {
          borderWidth: 0,
        },
        style,
      ]}
      {...props}
    />
  );
};
