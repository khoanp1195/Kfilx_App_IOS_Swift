import * as React from "react";
import { View, Text } from "react-native";
import { purchaseActionButtonStyles } from "./purchase-action-button.styles";
import type { PurchaseActionButtonProps } from "./purchase-action-button.types";
import { CustomSegmentedButtons } from "../SegmentedButtons/segmented-button";
import { Icon } from "react-native-paper";

export const PurchaseActionButton: React.FC<PurchaseActionButtonProps> = ({
  price,
  onCall,
  onAddToCart,
  onBuyNow,
  callButtonText,
  addToCartButtonText,
  buyButtonText,
}) => {
  const styles = purchaseActionButtonStyles;

  const buttons = [
    {
      value: "call",
      customLabel: (
        <View
          style={{
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flex: 1,
          }}
        >
          <View style={styles.iconContainer}>
            <Icon source="phone" size={20} color="white" />
            <Text numberOfLines={1} style={styles.buttonText}>
              {callButtonText}
            </Text>
          </View>
          <View style={styles.dividerLine} />
        </View>
      ),
      style: styles.primaryButton,
      onPress: onCall,
    },
    {
      value: "",
      customLabel: (
        <View
          style={{
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flex: 1,
          }}
        >
          <View style={styles.iconContainer}>
            <Icon source="cart-outline" size={20} color="white" />
            <Text numberOfLines={1} style={styles.buttonText}>
              {addToCartButtonText}
            </Text>
          </View>
        </View>
      ),
      style: styles.primaryButton,
    },
    {
      value: "buy",
      customLabel: (
        <View style={styles.buttonContent}>
          <Text style={styles.buyButtonText}>{buyButtonText}</Text>
          <Text style={styles.priceText}>{price}</Text>
        </View>
      ),
      style: styles.buyButtonContainer,
      onPress: onBuyNow,
    },
  ];

  return (
    <View style={styles.container}>
      <View style={styles.buttonGroup}>
        <CustomSegmentedButtons
          buttons={buttons}
          style={styles.segmentedButtons}
        />
      </View>
    </View>
  );
};
