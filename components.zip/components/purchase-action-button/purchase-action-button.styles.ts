import { StyleSheet } from "react-native";

export const purchaseActionButtonStyles = StyleSheet.create({
  // Container styles
  container: {
    width: "100%",
    paddingVertical: 8,
  },
  buttonGroup: {
    height: 65,
    width: "100%",
  },

  // Button styles
  primaryButton: {
    backgroundColor: "#007BFF",
    justifyContent: "center",
    alignItems: "center",
    paddingVertical: 12,
    flex: 1,
  },
  buyButtonContainer: {
    backgroundColor: "orange",
    justifyContent: "center",
    alignItems: "center",
    paddingVertical: 12,
    flex: 1,
  },

  // Button content styles
  buttonContent: {
    justifyContent: "center",
    alignItems: "center",
    gap: 4,
  },
  buttonText: {
    color: "#FFFFFF",
    fontSize: 8,
    fontWeight: "bold",
    textAlign: "center",
    width: 80,
  },
  priceText: {
    color: "#FFFFFF",
    fontSize: 14,
    fontWeight: "bold",
    textAlign: "center",
  },
  buyButtonText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "bold",
    textAlign: "center",
  },

  // Segmented buttons styles
  segmentedButtons: {
    borderRadius: 8,
    overflow: "hidden",
    borderWidth: 0,
  },

  // Divider line styles
  dividerLine: {
    width: 1,
    height: 190,
    marginHorizontal: 8,
    backgroundColor: "white",
  },

  // Icon container styles
  iconContainer: {
    justifyContent: "center",
    alignItems: "center",
    gap: 4,
  },
});
