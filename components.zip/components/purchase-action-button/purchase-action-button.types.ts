export interface PurchaseActionButtonProps {
  price: string;
  onCall?: () => void;
  onAddToCart?: () => void;
  onBuyNow?: () => void;
  callButtonText: string;
  addToCartButtonText: string;
  buyButtonText: string;
}
