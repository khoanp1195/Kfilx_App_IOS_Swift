import {StyleSheet, StatusBar, Platform, Dimensions} from 'react-native';
import {dimensWidth} from 'helpers/Constants';
const STATUSBAR_HEIGHT = StatusBar.currentHeight;
const APPBAR_HEIGHT = Platform.OS === 'ios' ? 44 : 56;
const window = Dimensions.get('window');
export default StyleSheet.create({
  mainContainer: {
    flex: 1,
    backgroundColor: 'white',
    width:(window.width) * 1,
    height: window.height,
    marginBottom: -20,
    marginTop: -25
  },
  vnaBackgroundImage: {
    height:window.height,
    width:window.width,
  
  //  zIndex: 1,
    //marginTop: -68

  },
  viewNetworkErr: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  btnRetry: {
    width: 150,
    height: 40,
    backgroundColor: 'white',
    borderRadius: 4,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textRetry: {
    color: 'black',
    fontWeight: 'bold',
  },
  tabBarIconView: {
    height: dimensWidth(12),
    width: dimensWidth(12),
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0)',
    borderRadius: 6,
    marginRight: 90,
    marginBottom: dimensWidth(-2),
      
    
  },
  tabBarLabelActive: {
    color: '#DBA410',
    fontWeight: '700',
    fontSize: 18,
    position: 'absolute',
    right: 60,
    bottom: 2

  },
  tabBarLabelInActive: {
    color: 'rgba(255, 255, 255, 0.7)',
    fontWeight: '400',
    fontSize: 18,
    position: 'absolute',
    right: 60,
    bottom: 2
  },
  viewTabBottomBar: {
    flexDirection: 'row',
    height: dimensWidth(32),
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#006885',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ECF0F1',
  },
  buttonsContainer: {
    padding: 10,
  },
  textStyle: {
    textAlign: 'center',
    marginBottom: 8,
  },
  statusBar: {
    height: STATUSBAR_HEIGHT,
  },
  appBar: {
    backgroundColor: '#79B45D',
    height: APPBAR_HEIGHT,
  },
  content: {
    flex: 1,
    backgroundColor: '#33373B',
  },
});
