import React, { FC, useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Alert, FlatList, RefreshControl, Animated, ActivityIndicator } from 'react-native';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { useDispatch, useSelector } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaView } from 'react-native-safe-area-context';
import { GetListNotify, GetListUnreadNotify, getAutoLoginMobile } from 'stories/dashboard/reducer';
import { arrayIsEmpty } from 'helpers/Functions';
import NoDataView from 'components/NoDataView';
import { FontSize, dimensWidth, windowWidth } from 'helpers/Constants';
import colors from 'helpers/Colors';
import HTML from 'react-native-render-html';
import FastImage from 'react-native-fast-image';
import styles from './ThongBao.Style';
import { Link, useNavigation } from '@react-navigation/native';
import { RootState } from 'stories/index';

interface Props {
  modalVisible: Boolean;
  onCloseModal: () => void;
  ActionJson: any;
  navigation: any;
}
const Item = ({ item, gotoDetail, index }: any) => {
  const {
    ID,
    ActionTime,
    Content,
    Link
  } = item;

  const htmlContent = Content
  let plainText = '';
  console.log('Content day nha =>>> ' + htmlContent);
  const renderers = {
    div: (_: any, children: any) => children,
    label: (_: any, children: any) => children,
    strong: (_: any, children: any) => children,
    textAction: (_: any, children: any) => children,
  };

  const GetAttributedStringFromHtml = (html, isBold) => {
    const modifiedFont = `
      <span style="font-family: '-apple-system', 'HelveticaNeue'; 
                  font-weight: ${isBold ? 'bolder' : 'normal'}; 
                  font-size: 14; 
                  text-align: center">
        ${htmlContent}
      </span>
    `;

    return (
      <HTML
        source={{ html: modifiedFont }}
        tagsStyles={{
          span: {
            fontFamily: '-apple-system, HelveticaNeue',
            fontSize: 14,
            textAlign: 'center',
          },
        }}
      />
    );
  };
  const isOdd = index % 2 === 0;
  return (
    <TouchableOpacity onPress={() => gotoDetail(Link)} style={[styles.item, isOdd && { backgroundColor: '#F1FAFF' }]}>
      <FastImage
        style={styles.itemAvatar}
        resizeMode='contain'
        source={require('../../../../src/assets/images/icon_itemNotify.png')}
      />
      <View style={{ flex: 1, flexDirection: 'column', marginLeft: 7 }}>
        <Text style={styles.title} numberOfLines={2}>{plainText}</Text>
        <Text>
          <View>
            {GetAttributedStringFromHtml({ htmlContent }, true /* or false for non-bold */)}
          </View>

          {/* <HTML source={{ html: htmlContent }} /> */}
        </Text>
        <Text style={styles.date}>{ActionTime}</Text>
      </View>
    </TouchableOpacity>
  );
};

const ThongBaoScreen: FC<Props> = ({
  modalVisible,
  onCloseModal,
  ...props
}: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const [Offset, setOffset] = useState(0);
  const [tabName, setTabName] = useState(TABNAME.TatCa);
  const [dataNotifyState, setdataNotifyState] = useState([]);
  const [dataUnReadNotifyState, setdataUnReadNotifyState] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  let initialPayloadNotify = { limit: 100, offset: Offset }
  let initialPayloadUnReadNotify = { limit: 100, offset: Offset, isCount: 0 }
  const [payloadNotify, setpayloadNotify] = useState<any>(initialPayloadNotify);
  const [payloadUnReadNotify, setpayloadUnReadNotify] = useState<any>(initialPayloadUnReadNotify);
  const navigation = useNavigation();
  const { languages, languagesText } = useSelector((state: RootState) => state.languages);

  //Notify
  const isLoadMoreNotify = useSelector(
    (state: any) => state.dashboard
  )
  const isLoadingNotify = useSelector((state: any) => state.dashboard)
  const dataNotify = useSelector(
    (state: any) => state.dashboard
  )
  const { totalRecordNotify } = dataNotify;

  //UnReadNotify
  const isLoadMoreUnReadNotify = useSelector(
    (state: any) => state.dashboard
  )
  const isLoadingUnreadNotify = useSelector((state: any) => state.dashboard)
  const dataUnReadNotify = useSelector(
    (state: any) => state.dashboard
  )
  const dataListUnreadNotify = useSelector(
    (state: any) => state.dashboard
  )
  const { totalRecordUnreadNotify } = dataListUnreadNotify;


  //fetchGetListDataNotifyRequest
  const fetchGetListDataNotifyRequest = useCallback((payload: any) => {
    dispatch(GetListNotify(payload))
  }, [dispatch])
  useEffect(() => {
    const langId = languagesText === 'EN' ? 1033 : 1066
    fetchGetListDataNotifyRequest({ langId, limit: 20, offset: Offset })
  }, [dispatch, languagesText, Offset])


  //fetchGetListdataListUnreadNotify
  const fetchGetListDataUnReadNotifyRequest = useCallback((payload: any) => {
    dispatch(GetListUnreadNotify(payload))
  }, [dispatch])
  useEffect(() => {
    const langId = languagesText === 'EN' ? 1033 : 1066
    fetchGetListDataUnReadNotifyRequest({ langId, limit: 20, offset: Offset })
  }, [dispatch, languagesText, Offset])


  //changeTabTatCa
  const changeTabTatCa = useCallback(() => {
    setOffset(0)
    setTabName(TABNAME.TatCa)
  }, []);

  //changeTabChuaXem
  const changeTabChuaXem = useCallback(() => {
    setOffset(0)
    setTabName(TABNAME.ChuaXem);
    setpayloadUnReadNotify(initialPayloadUnReadNotify)
  }, [dataListUnreadNotify]);

  //onRefresh
  const onRefresh = useCallback(() => {
    setOffset(0);
    // setpayloadNotify(initialPayloadNotify)
    //  dispatch(GetListNotify(initialPayloadNotify));
    setRefreshing(false);
  }, [refreshing]);

  //dataNotify
  useEffect(() => {
    setdataNotifyState(dataNotify.dataListNotify);
    setRefreshing(false)
  }, [dataNotify])

  //dataUnReadNotify
  useEffect(() => {
    setdataUnReadNotifyState(dataListUnreadNotify.dataListUnreadNotify);
    setRefreshing(false)
  }, [dataListUnreadNotify])

  const handleLoadmoreUnReadNotify = async () => {
    if (dataListUnreadNotify.dataListUnreadNotify.length < totalRecordUnreadNotify) {
      setOffset(dataListUnreadNotify.dataListUnreadNotify.length);
    }
  }

  const handleLoadmoreNotify = async () => {
    if (dataNotify.dataListNotify.length < totalRecordNotify) {
      setOffset(dataNotify.dataListNotify.length);
    }
  }

  //renderFooterUnReadNotifty
  const renderFooterUnreadNotify = (isLoading: boolean, refreshing: boolean, isLoadMoreComment: boolean, Offset: any) => {
    return (
      //Footer View with Load More button
      <View style={styles.footer}>
        {isLoading && !refreshing && isLoadMoreComment && Offset !== 0 ? (
          <ActivityIndicator color="blue" style={{ marginLeft: 8 }} />
        ) : null}
      </View>
    );
  };

  const onGoBack = useCallback(() => {
    navigation.goBack();
  }, [])
  //gotoDetailPress
  const gotoDetailPress = useCallback(
    (Link: any) => {
      dispatch(getAutoLoginMobile());
      navigation.navigate({
        name: "DashboardDetailScreen",
        params: { urlThongBao: Link, isThongBao: true },
      });
      console.log("item?.Link =>>> " + Link)
    },
    [dispatch, Link, navigation],
  )


  // const gotoDetailPress = useCallback((Link: any) => {
  //   dispatch(getAutoLoginMobile());
  //   navigation.navigate('DashboardDetailScreen', { id: link });
  //   onCloseModal(); // Close the modal after navigating
  // }, [dispatch, link, closeModal, navigation]);

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <View style={styles.container}>
        <View style={{ alignItems: 'center' }}>
          <Text style={styles.title_header}>{languages.notification}</Text>
        </View>

        <TouchableOpacity
          activeOpacity={1}
          style={{ backgroundColor: 'blue' }}
          onPress={onGoBack}
        >
          {/* <Text style={styles.lbl_thoat} numberOfLines={1}>
              {"X"}
            </Text> */}
          <FastImage
            style={styles.icon_back}
            resizeMode='contain'
            source={require('../../../../src/assets/images/icon_closeForm.png')}
          />
        </TouchableOpacity>

        <View style={styles.flexDirectionRowTab}>
          <TouchableOpacity
            activeOpacity={1}
            onPress={changeTabTatCa}
            style={
              tabName === TABNAME.TatCa
                ? styles.onPressActiveTab
                : styles.onPressInActiveTab
            }
          >
            <Text
              style={
                tabName === TABNAME.TatCa
                  ? styles.titleActiveTab
                  : styles.titleInActiveTab
              }
            >   {languages.all}
              {/* {TABNAME.DangXL} */}
            </Text>
          </TouchableOpacity>


          <TouchableOpacity
            activeOpacity={1}
            onPress={changeTabChuaXem}
            style={
              tabName === TABNAME.ChuaXem
                ? styles.onPressActiveTab
                : styles.onPressInActiveTab
            }
          >
            <Text
              style={
                tabName === TABNAME.ChuaXem
                  ? styles.titleActiveTab
                  : styles.titleInActiveTab
              }
            > {languages.not_seen}
              {/* {TABNAME.DaXL} */}
            </Text>
          </TouchableOpacity>
        </View>
        {!arrayIsEmpty(dataNotifyState) && tabName === TABNAME.TatCa ?
          (
            <FlatList
              contentContainerStyle={styles.containerFlatList}
              data={dataNotifyState}
              extraData={dataNotifyState}
              refreshControl={
                <RefreshControl refreshing={isLoadingNotify} onRefresh={onRefresh} tintColor='#0b5e5c' />
              }
              renderItem={({ item, index }) => (
                <Item item={item} gotoDetail={gotoDetailPress} index={index} />// gotoDetail={gotoDetailPress}
              )
              }
              keyExtractor={(item, index) => String(index)}
              showsVerticalScrollIndicator={false}
              onEndReachedThreshold={0.5}
              onEndReached={handleLoadmoreNotify}
              ListFooterComponent={renderFooterUnreadNotify(isLoadingNotify, refreshing, isLoadMoreNotify, Offset)}
            />
          ) : !arrayIsEmpty(dataUnReadNotifyState) && tabName == TABNAME.ChuaXem ?
            (
              <FlatList
                contentContainerStyle={styles.containerFlatList}
                data={dataUnReadNotifyState}
                extraData={dataUnReadNotifyState}
                refreshControl={
                  <RefreshControl refreshing={isLoadingNotify} onRefresh={onRefresh} tintColor='#0b5e5c' />
                }
                renderItem={({ item, index }) => (
                  <Item item={item} gotoDetail={gotoDetailPress} index={index} />// gotoDetail={gotoDetailPress}
                )
                }
                keyExtractor={(item, index) => String(index)}
                showsVerticalScrollIndicator={false}
                onEndReachedThreshold={0.5}
                onEndReached={handleLoadmoreUnReadNotify}
                ListFooterComponent={renderFooterUnreadNotify(isLoadingUnreadNotify, refreshing, isLoadMoreUnReadNotify, Offset)}
              />
            ) :
            (<NoDataView onRetryPress={function () {
              throw new Error("Function not implemented.");
            }} />
            )}
      </View>

    </SafeAreaView>
  );
};

export default ThongBaoScreen;
export enum TABNAME {
  TatCa = "Tất cả",
  ChuaXem = "Chưa xem",
}



