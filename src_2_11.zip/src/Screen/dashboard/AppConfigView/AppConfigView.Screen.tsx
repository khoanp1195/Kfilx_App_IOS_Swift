import React, { FC, useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image,  TouchableOpacity, Alert, FlatList, RefreshControl, Animated, ScrollView,Switch } from 'react-native';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { useDispatch, useSelector } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaView } from 'react-native-safe-area-context';
import { GetInteractDocument, GetListCommentDocument, GetListNotify, GetListUnreadNotify } from 'stories/dashboard/reducer';
import { arrayIsEmpty } from 'helpers/Functions';
import NoDataView from 'components/NoDataView';
import { FontSize, dimensWidth, windowWidth } from 'helpers/Constants';
import colors from 'helpers/Colors';
 import HTML from 'react-native-render-html';
import FastImage from 'react-native-fast-image';
 import { Col, Row } from 'react-native-flex-grid';
import FastImageCustom from 'components/FastImageCustom';
import styles from './AppConfigView.Style';
import { RootState } from 'stories/index';
import { useFocusEffect } from '@react-navigation/native';
import { getConfigNotification } from 'stories/profile/reducer';
import TextCusTom from 'components/TextCusTom';
import Header from 'components/Header';

interface Props {
    modalVisible: Boolean;
    onCloseModal: () => void;
    ActionJson: any;
  }

  const DATA = [
    {
        id: 'bd7acbea-c1b1',
        title: 'Văn bản đã theo dõi có thay đổi',
        isEnabledNoti: false,
        isEnabledEmail: false,
    },
    {
        id: '2323-asdsa-23',
        title: 'Văn bản đã thêm vào danh sách yêu thích có thay đổi',
        isEnabledNoti: false,
        isEnabledEmail: false,
    },
    {
        id: 'bd96-145571e23s9d72',
        title: 'Văn bản được chia sẻ',
        isEnabledNoti: false,
        isEnabledEmail: false,
    },
    {
        id: '123sdsds',
        title: 'Bộ lọc được chia sẻ',
        isEnabledNoti: false,
        isEnabledEmail: false,
    },
    {
        id: '58694a0f-3da5571e29d72',
        title: 'Bình luận được phản hồi',
        isEnabledNoti: false,
        isEnabledEmail: false,
    },
    {
        id: 'Văn bản đã thêm vào danh sách yêu thích có thay đổi',
        title: 'Bình luận được phê duyệt',
        isEnabledNoti: false,
        isEnabledEmail: false,
    },
    {
        id: '58694a6-145571e29d72',
        title: 'Tag bình luận',
        isEnabledNoti: false,
        isEnabledEmail: false,
    },
];
const SettingItem = ({ item, index, toggleSwitchNoti, toggleSwitchEmail }: any) => {
  const { title, id, isEnabledEmail, isEnabledNoti } = item;
  const isOdd = index % 2
  return (
      <View style={[styles.settingItem, { backgroundColor: isOdd ? 'white' : colors.white_blue }]}>
          <TextCusTom style={styles.itemTitle} i18nKey={title} numberOfLines={2} />
          <View style={styles.  viewRight}>
              <View style={{ marginRight: 235, width: 70 }}>
                  <Switch
                      trackColor={{ false: colors.blue_switch_on, true: colors.blue_switch_on }}
                      thumbColor={colors.white}
                      onValueChange={() => toggleSwitchNoti(id)}
                      value={isEnabledNoti}
                  />
              </View>
              <View style={{ marginRight:150,width: 70 }}>
                  <Switch
                      trackColor={{ false: colors.grey_da, true: colors.blue_switch_on }}
                      thumbColor={colors.white}
                      onValueChange={() => toggleSwitchEmail(id)}
                      value={isEnabledEmail}
                  />
              </View>
          </View>
      </View>
  )
};
const HeaderSetting = () => {

  return (
      <View >
        <View style={styles.headerContainer}>
        <Text  style={styles.textHeader_category} >
         Loại
        </Text>
        <TextCusTom i18nKey={'Notifications'} style={styles.textHeader} />
          <TextCusTom i18nKey={'Email'} style={styles.textHeader} />
        </View>
      </View>
  )
};


  const AppConfigView: FC<Props> = ({
    modalVisible,
    onCloseModal,
    ...props
  }: Props) => {
    const {languages,languagesText } = useSelector((state: RootState) => state.languages);
    const [setingData, setSetingData] = useState(DATA);
    const dispatch = useDispatch<any>();


    useFocusEffect(
      React.useCallback(() => {
        const langId = languagesText === 'EN' ? 1033 :1066
        dispatch(getConfigNotification(langId));
      }, [languagesText])
    );

  const toggleSwitchNoti = useCallback((id: string) => {
      const data = setingData.map(it => {
          const newIt = it.id === id ? { ...it, isEnabledNoti: !it.isEnabledNoti } : it
          return newIt
      })
      setSetingData(data);
      console.log("data-toggleSWITH =>> " + data)
  },
      [setingData],
  )
  const toggleSwitchEmail = useCallback((id: string) => {
      const data = setingData.map(it => {
          const newIt = it.id === id ? { ...it, isEnabledEmail: !it.isEnabledEmail } : it
          return newIt
      })
      setSetingData(data);
  }, [setingData],
  )

  return (
    <SafeAreaView style={{flex: 1}}>
        <View style={styles.container}>
            <View style={{alignItems: 'center'}}>
            <Text style={styles.title_header}>{languages.setting_remind_noti}</Text>
            </View>
            <TouchableOpacity
            activeOpacity={1}
            style={{backgroundColor: 'blue'}}
            onPress={onCloseModal}
          >
            {/* <Text style={styles.lbl_thoat} numberOfLines={1}>
              {"X"}
            </Text> */}
                     <FastImage
                  style={styles.icon_back}
                  resizeMode='contain'
                source={require('../../../../src/assets/images/icon_closeForm.png')}
              />
          </TouchableOpacity>
         
            <View style={styles.view_setting}>
            <HeaderSetting/>
            <FlatList
                style={{marginTop: 0}}
                data={setingData}
                extraData={setingData}
                renderItem={({ item, index }) => (
                    <SettingItem
                        item={item} index={index}
                        toggleSwitchEmail={(id) => toggleSwitchEmail(id)}
                        toggleSwitchNoti={(id) => toggleSwitchNoti(id)} />
                )
                }

                keyExtractor={item => item.id}
            />
            </View>
       

        </View>

    </SafeAreaView>
  );
};

export default AppConfigView;
export enum TABNAME {
    TatCa = "Tất cả",
    ChuaXem = "Chưa xem",
  }