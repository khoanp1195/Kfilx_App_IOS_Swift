import colors from "helpers/Colors";
import * as React from "react";
import Svg, { Path } from "react-native-svg";

function SvgComponent(props) {
  const { focused = false } = props;
  return (
    <Svg
      width={36}
      height={34}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M17.884 14.685l5.746 5.937c.41.427.4 1.105-.025 1.517l-1.612 1.56c-.426.412-1.105.4-1.517-.026l-5.743-5.938c-.413-.425-.565-.946-.341-1.163.224-.216.071-.736-.34-1.162l-.036-.038c-3.39 2.713-8.347 2.503-11.488-.639A8.63 8.63 0 1114.734 2.528c3.088 3.088 3.338 7.931.766 11.314l.082.085c.412.426.927.596 1.151.38.223-.218.738-.048 1.15.378zm-13.46-1.848a5.956 5.956 0 008.413 0 5.955 5.955 0 000-8.413 5.955 5.955 0 00-8.413 0 5.957 5.957 0 000 8.413z"
        fill={focused ? '#DBA410': 'lightgray'}
      />
    </Svg>
  );
}

export default SvgComponent;
