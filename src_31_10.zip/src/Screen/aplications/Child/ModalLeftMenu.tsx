import React, { FC, useMemo, useCallback, useState, useEffect } from "react";
import {
  Modal,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Platform,
  FlatList,
  Image,
  Alert,
  Animated,
} from "react-native";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../../stories";
import { useNavigation } from "@react-navigation/native";
import { SafeAreaProvider, SafeAreaView } from "react-native-safe-area-context";
import { DEFAULT_LANGUAGE_TEXT, FontSize, dimensWidth, windowHeight, windowWidth } from "helpers/Constants";
import FastImage from "react-native-fast-image";
import { ScrollView } from "react-native-gesture-handler";
import { Switch } from 'react-native-switch';
import CustomSwitch from "components/CustomSwitch";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { logout, logoutAction } from "stories/login/reducer";
import { syncFormDashboardAction } from "stories/dashboard/reducer";
// import { database } from '../../../database';
import { setLanguagesAction } from "stories/languages/reducer";
import { GetListSubCategory } from "stories/category/reducer";
import { arrayIsEmpty } from "helpers/Functions";
import NoDataView from "components/NoDataView";


const Item = ({ item, gotoDetail, index }: any) => {
  const { title, imgPath } = item;

  console.log('imgPath =>>', imgPath); // Log the imgPath without single quotes

  return (
    <TouchableOpacity style={[styles.item]}>
      {/* <Image
        style={styles.itemIcon}
        source={require(imgPath)} // Pass the imgPath as the source using require without quotes
      /> */}

      <View style={{ flex: 1, flexDirection: 'column' }}>
        <Text style={styles.title} numberOfLines={2}>
          {title}
        </Text>
        {/* <Text style={styles.date}>{ActionTime}</Text> */}
        <View style={styles.dashed} />
        <View />
      </View>
    </TouchableOpacity>
  );
};


interface Props {
  modalVisible: Boolean;
  onConfirmModal: () => void;
  onReFilterModal: () => void;
  confirmText: String;
  refilterText: String;
  props: FC<Props>;
  onPressProcessedDocx: () => void;
  onPressWaitProcesseDocx: () => void;
  onPressChooseType: () => void;
  onPressFilter: () => void;
  onPressSearch: () => void;
  onPressOpenCalendarPicker: (typeModal: string) => void;
  onPressChooseLanhDao: () => void;
  tinhTrang: String;
  navigation: any;
  startDate: any;
  endDate: any;
  statusText: any,
  item: any,
  ID: String,
  title: String,
  dataCategory: [],
  filteredCategories: []
  lanhDaoNameSellectedState: any;
  menuItems: []
}
const ModalLeftMenu: FC<Props> = ({
  modalVisible,
  onConfirmModal,
  onReFilterModal,
  confirmText,
  refilterText,
  onPressFilter,
  onPressWaitProcesseDocx,
  onPressProcessedDocx,
  tinhTrang,
  onPressChooseType,
  onPressSearch,
  onPressOpenCalendarPicker,
  startDate,
  endDate,
  statusText,
  item,
  ID,
  title,
  dataCategory,
  filteredCategories,
  onPressChooseLanhDao,
  lanhDaoNameSellectedState,
  menuItems,
  ...props
}: Props) => {
  const lanhDaoNameSellectedName = useMemo(() => {
    if (!lanhDaoNameSellectedState) return "";
    const lanhDaoqName = lanhDaoNameSellectedState.find(
      (it) => it.isSellected
    )?.Title;

    return lanhDaoqName;
  }, [lanhDaoNameSellectedState]);


  const [filterText, setFilterText] = useState("");
  const onPressChooseTypePress = useCallback(() => {
    onPressChooseType();
  }, [onPressChooseType]);
  const onChangeFilterText = useCallback(
    (text: string) => {
      setFilterText(text);
    },
    [filterText]
  );
  const [visbleProfile, setvisbleProfile] = useState(false);
  const onPressFilterhide = useCallback(() => {
    setvisbleProfile(false);
  }, [visbleProfile]);
  const [scroll, setScroll] = useState(false);
  const [switchValue, setSwitchValue] = useState(false);
  const [modalVisibleAppConfig, setmodalVisibleAppConfig] = useState(false);
  const [modalVisibleVBTT, setmodalVisibleVBTT] = useState(false);
  const [modalVisibleDSBinhLuan, setmodalVisibleDSBinhLuan] = useState(false);
  const [modalVisibleDSOffline, setmodalVisibleDSOffline] = useState(false);
  const [modalVisibleProfile, setmodalVisibleProfile] = useState(false);
  const { languages, languagesText } = useSelector((state: RootState) => state.languages);
  const dispatch = useDispatch<any>();

  const [showModal, setShowModal] = React.useState(modalVisible);
  const scaleValue = React.useRef(new Animated.Value(0)).current;
  const translateXValue = React.useRef(new Animated.Value(0)).current;
  React.useEffect(() => {
    toggleModal();
  }, [modalVisible]);
  const toggleModal = () => {
    if (modalVisible) {
      setShowModal(true);
      Animated.parallel([
        Animated.timing(scaleValue, {
          toValue: 1,
          duration: 200,
          useNativeDriver: true,
        }),
        Animated.timing(translateXValue, {
          toValue: 0, // Start from 0 to slide in from left to right
          duration: 200,
          useNativeDriver: true,
        }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(scaleValue, {
          toValue: 0,
          duration: 200,
          useNativeDriver: true,
        }),
        Animated.timing(translateXValue, {
          toValue: -200, // Slide out to the left
          duration: 200,
          useNativeDriver: true,
        }),
      ]).start(() => setShowModal(false));
    }
  };

  const toggleSwitch = (value) => {
    setSwitchValue(value);
  };

  const onSelectSwitch = useCallback(
    (languages: string) => {
      dispatch(setLanguagesAction(languages))
    },
    [languagesText],
  )
  const navigation = useNavigation();

  //handle and close Modal VBTT
  const handleOpenVBTTView = () => {
    //  setmodalVisibleVBTT(true);
    onReFilterModal()
    navigation.navigate('VBTuongTac', { title: 'Your Title' });
  };
  const handleCloseNotifyView = () => {
    setmodalVisibleVBTT(false);
  };

  //handle and close Danh Sách Bình Luận
  const handleOpenListComment = () => {
    // setmodalVisibleDSBinhLuan(true);
    navigation.navigate('DSBinhLuan', { title: 'Your Title' });
    onReFilterModal()
  };
  const handleCloseCommentView = () => {
    setmodalVisibleDSBinhLuan(false);
  };

  //handle and close Danh Sách Bình Luận
  const handleOpenProfileView = () => {
    setmodalVisibleProfile(true);
  };
  const handleClosenProfileView = () => {
    setmodalVisibleProfile(false);
  };

  //handle and close AppConfig
  const handleOpenAppConfig = () => {
    setmodalVisibleAppConfig(true)
  };
  const handleCloseAppConfig = () => {
    setmodalVisibleAppConfig(false)
  }

  //handle and close OfflineDocumentList
  const handleOpenOfflineDocumentList = () => {
    setmodalVisibleDSOffline(true)
  };
  const handleCloseOfflineDocumentList = () => {
    setmodalVisibleDSOffline(false)
  }

  //onPressUserProfile
  const onPressUserProfile = useCallback(() => {
    setvisbleProfile(true);
  }, [visbleProfile]);

  //fetchGetListSubCategoryRequest
  const fetchGetListSubCategoryRequest = useCallback((payload: any) => {
    dispatch(GetListSubCategory(payload))
  }, [dispatch])
  useEffect(() => {
    fetchGetListSubCategoryRequest({ limit: 100, Offset: 0, categoryID: ID })
  }, [fetchGetListSubCategoryRequest])

  const isLangueEn = useMemo(() => languagesText === DEFAULT_LANGUAGE_TEXT.ENGLISH, [languagesText])
  const isLangueVi = useMemo(() => languagesText === DEFAULT_LANGUAGE_TEXT.VIETNAM, [languagesText])


  console.log("categoryID =>>> " + ID)

  const renderItem = ({ item } : any) => (
    <TouchableOpacity  onPress={() => gotoDetailPress(item)} style={{ flexDirection: 'row', padding: 10, borderBottomWidth: 1, borderBottomColor: '#ccc',marginLeft: 30 }}>
      <FastImage style={{
        height: dimensWidth(15),
        width: dimensWidth(15),
        marginLeft: dimensWidth(2),
      }}
        source={{ uri: item.Thumbnail }}
        defaultSource={require('../../../../src/assets/images/icon_categoryDefault.png')}
      />
      <Text style={{ width: 280, fontSize: 17, marginTop: 15, marginLeft: 20 }}>{item.Title}</Text>
      <Image
        style={styles.icon_arrow}
        resizeMode='contain'
        source={require('../../../../src/assets/images/icon_next.png')} // Pass the imgPath as the source using require without quotes
      />
    </TouchableOpacity>
  );

  const gotoDetailPress = useCallback(
    (item: any) => {
     onReFilterModal()
      navigation.navigate({
        name: "DoucumentListView",
        params: { id: item?.ID, 
          titleChild: item?.Title,
          parenttitle: title,item,
          filteredCategories,
          titleChild: item?.Title,
          isClickLeftMenu: true,
          dataCategory:dataCategory },
      });
    },
    [],
  )

  return (
    <Modal
      transparent={true}
      visible={showModal}
      {...props}
      style={styles.centeredView}
    >
      <View style={styles.centeredView}>
        <Animated.View
          style={[{
            transform: [
              {
                translateX: scaleValue.interpolate({
                  inputRange: [0, 1],
                  outputRange: [-400, 10], // Adjust the distance for your desired slide length
                }),
              },
            ],
          }]}>
          <SafeAreaProvider style={styles.centeredView}>
            <SafeAreaView>
              <View style={styles.modalView}>
                <View>
                  <View style={styles.headerView}>
                    <Text style={styles.title_header}>{title}</Text>
                    <TouchableOpacity style={styles.filterIcon} onPress={onReFilterModal}>
                      <FastImage
                        style={styles.icon_back}
                        resizeMode='contain'
                        source={require('../../../../src/assets/images/icon_closeForm.png')}
                      />
                    </TouchableOpacity>

                  </View>

                </View>
                {!arrayIsEmpty(menuItems) ? (
                  <FlatList
                    contentContainerStyle={{ marginTop: -5, marginLeft: 20 }}
                    data={menuItems}
                    renderItem={renderItem}
                  />
                ) : (
                  <NoDataView onRetryPress={() => { /* Implement your retry logic here */ }} />
                )}

              </View>
            </SafeAreaView>
          </SafeAreaProvider>
        </Animated.View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    height: 260,
    backgroundColor: "rgba(0,0,0,0.2)",
    marginLeft: '-12%'
  },
  containerFlatList: {
    marginTop: 0,
  },
  icon_back: {
    height: dimensWidth(6),
    width: dimensWidth(6),
    position: 'absolute',
    right: 40,
    top: 10
  },
  item: {
    flexDirection: 'row',
    backgroundColor: 'white',
    height: 70,
    justifyContent: 'center',

  },

  itemSignout: {
    flexDirection: 'row',
    backgroundColor: 'white',
    height: 50,
    position: 'absolute',
    left: 10,
  },
  icon_arrow: {
    height: dimensWidth(5),
    width: dimensWidth(5),

  },
  modalView: {
    width: '30%',
    backgroundColor: '#F1FAFF',
    height: windowHeight - 100,
    marginLeft: '17%',
    shadowColor: "#19191E",
    shadowOffset: {
      width: 0,
      height: 22,
    },
    paddingBottom: 40,
    marginTop: 95,

  },
  title_header: {
    fontSize: 20,
    fontWeight: 'bold',
    left: '-90%',
    width:'60%'
  },
  filterIcon: {
    width: 20,
    height: 20,
    position: 'absolute',
    top: 20,
    right: -20,
  },

  button: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  typeChild: {
    borderWidth: 1.5,
    borderColor: '#00688540',
    borderRadius: 10,
    position: 'absolute',
    flexDirection: 'row',
    top: 140,
    left: 25,
    width: windowWidth / 2 - 30,
    height: 50,
    justifyContent: 'center'
  },
  dateView: {
    flex: 1,
    margin: -1,
  },
  dashed: {
    borderWidth: 1,
    borderColor: "lightgray",
    width: windowWidth / 2 - 20,
    position: 'absolute',
    top: 57,
    left: 17
  },
  position: {
    fontSize: 18,
    width: 420,
    color: 'gray',
    fontFamily: 'arial',
    marginTop: 20,
    left: 5

  },
  chooseTypeView: {
    flexDirection: "row",
    marginTop: dimensWidth(10),
    paddingVertical: dimensWidth(25),
    backgroundColor: 'white',
    width: "100%",
    alignItems: "center",
  },

  searchView: {
    flexDirection: "row",
    marginTop: 10,
    backgroundColor: 'white',
    justifyContent: "center",
    width: windowWidth / 2 + 20,
    paddingVertical: 20,
    alignItems: "center",
    height: 220,
    alignContent: 'center',
    marginLeft: 40,
    borderRadius: 10,
    borderWidth: 0.5,
    borderColor: 'black'
  },


  view_user_header_under: {
    flexDirection: "colmun",
    marginBottom: -120,
    backgroundColor: 'white',
    width: windowWidth / 2 + 20,
    alignItems: "center",
    height: 196,
    alignContent: 'center',
    marginLeft: 40,
    borderRadius: 10,
    borderWidth: 0.5,
    borderColor: 'black'
  },


  view_user_header: {
    flexDirection: "column",
    marginTop: 10,
    backgroundColor: 'white',
    justifyContent: "center",
    width: windowWidth / 2 + 20,
    paddingVertical: 20,
    alignItems: "center",
    height: 220,
    alignContent: 'center',
    marginLeft: 40,
    borderRadius: 10,
    borderWidth: 0.5,
    borderColor: 'black'
  },




  type2: {
    flexDirection: "column",
    marginTop: 35,
    backgroundColor: 'white',
    width: windowWidth / 2 + 20,
    height: 198,
    marginLeft: 40,
    borderRadius: 10,
    borderWidth: 0.5,
    borderColor: 'black'
  },

  typeSignOut: {
    flexDirection: "row",
    marginTop: 35,
    backgroundColor: 'white',
    justifyContent: "center",
    width: windowWidth / 2 + 20,
    paddingVertical: 20,
    alignItems: "center",
    height: 65,
    alignContent: 'center',
    marginLeft: 40,
    borderRadius: 10,
    borderWidth: 0.5,
    borderColor: 'black'
  },
  typeChild2: {
    flexDirection: "row",
    backgroundColor: 'white',
    width: windowWidth / 2 + 10,
    alignItems: "center",
    height: 65,
    borderRadius: 10,
    borderColor: 'black',

  },
  typeChildProfile: {
    flexDirection: "row",
    backgroundColor: 'white',
    width: windowWidth / 2 + 10,
    alignItems: "center",
    height: 65,
    borderRadius: 10,
    borderColor: 'black',

  },

  headerView: {
    flexDirection: "row",
    marginTop: dimensWidth(3),
    justifyContent: "center",
    width: "100%",
    paddingVertical: '6%',
    alignItems: "center",
    textAlign: 'center',
  },

  titleDateSentTo: {
    flexDirection: "row",
    marginTop: dimensWidth(10),
    backgroundColor: 'white',
    justifyContent: "space-between",
    width: "100%",
    paddingVertical: dimensWidth(25),
    alignItems: "center",
  },

  filterDateView: {
    flexDirection: "row",
    backgroundColor: 'white',
  },
  flexDirection: {
    height: dimensWidth(50),
    flexDirection: "row",
    marginTop: dimensWidth(10),
  },
  modalConfirmText: {
    fontSize: FontSize.MEDIUM,
    color: 'white',
    fontWeight: "400",
    fontFamily: "arial",
  },
  modalReFilterText: {
    fontSize: FontSize.SMALL,
    color: "#00524E",
    fontWeight: "400",
    fontFamily: "arial",
  },
  stroke: {
    borderWidth: 1,
    borderColor: "#E5E5E5",
    marginVertical: dimensWidth(7.5),
    borderStyle: "dashed",
  },
  buttonReFilter: {
    height: dimensWidth(34),
    paddingHorizontal: dimensWidth(12),
    borderRadius: dimensWidth(4),
    alignItems: "center",
    justifyContent: "center",
  },
  buttonConfirm: {
    backgroundColor: "#00524E",
    height: dimensWidth(34),
    paddingHorizontal: dimensWidth(25),
    borderRadius: dimensWidth(4),
    alignItems: "center",
    justifyContent: "center",
  },
  textDate: {
    fontSize: FontSize.MEDIUM,
    color: 'black',
    fontWeight: "400",
    fontFamily: "arial",
    marginVertical: dimensWidth(14),
  },
  textTitleDate: {
    fontSize: FontSize.SMALL,
    color: 'lightblack',
    fontWeight: "400",
    fontFamily: "arial",
    marginTop: dimensWidth(14),
  },
  textType: {
    fontSize: 18,
    color: 'lightblack',
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 300,
    marginTop: 13
  },
  textFiltedType: {
    fontSize: 16,
    color: '#0b5e5c',
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 210,
  },
  itemAvatar: {
    height: dimensWidth(27),
    width: dimensWidth(27),
    marginLeft: dimensWidth(5),
    borderRadius: dimensWidth(20),
    marginBottom: 90
  },
  itemAvatar_viewAvatar: {
    height: dimensWidth(57),
    width: dimensWidth(57),
    marginLeft: dimensWidth(5),
    borderRadius: dimensWidth(27),
    marginBottom: 90
  },

  icon_arrow: {
    height: dimensWidth(5),
    width: dimensWidth(5),
    marginRight: dimensWidth(5),
  },
  icon_arrow_header: {
    height: dimensWidth(5),
    width: dimensWidth(5),
    marginLeft: dimensWidth(20),
    marginTop: 15
  },

  title: {
    fontSize: 16,
    width: 300,
    color: 'black',
    fontFamily: 'arial',
    left: 20
  }, itemIcon: {
    height: dimensWidth(10),
    width: dimensWidth(10),
    marginLeft: dimensWidth(5),
  },
  titleHeader: {
    fontSize: 16,
    width: 200,
    color: '#7E7E7E',
    fontFamily: 'arial',
    left: 20
  },
  titleChild: {
    fontSize: 16,
    width: 400,
    color: 'black',
    fontFamily: 'arial',
    left: 20,
    marginTop: 5
  },


  title_version: {
    fontSize: 18,
    width: 200,
    color: '#2376E0',
    fontFamily: 'arial',
    left: 146
  },
  title_accountName: {
    fontSize: 22,
    width: 420,
    color: 'black',
    fontFamily: 'arial',
    left: 5
  },
  title_signOut: {
    fontSize: 16,
    width: 200,
    color: 'red',
    fontFamily: 'arial',
    left: 20,

  },
  modalBackGround: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    width: '100%',
    flex: 1,
    height: 250,
  },
});

export default ModalLeftMenu;
function alert(arg0: string) {
  throw new Error("Function not implemented.");
}

function dispatch(arg0: any) {
  throw new Error("Function not implemented.");
}

export enum IsProfile {
  IsProfile = 1,
  DaXL = "Đã xử lý",
}
