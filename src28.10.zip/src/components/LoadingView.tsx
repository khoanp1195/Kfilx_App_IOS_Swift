import React from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import colors from '../helpers/Colors';
import FastImage from 'react-native-fast-image';
import { windowHeight, windowWidth } from 'helpers/Constants';
const LoadingView = (props: any) => {
  const {
    isLoading = false,
    viewLoadingStyle,
    color = 'blue',
    bgColor,
    isLarge = false,
  } = props;
  if (!isLoading) {
    return null;
  }
  return (
    <View
      style={[
        styles.viewLoading,
        bgColor && { backgroundColor: bgColor },
        viewLoadingStyle && viewLoadingStyle,
      ]}>
      <View style={styles.bg_login}>
        <FastImage
          style={styles.vnaBackgroundImage}
          source={require('../assets/images/img_vnaPlane.png')}
        />
        <FastImage
          style={styles.vnaImage}

          source={require('../assets/images/vietname_airline.png')}
        />
        <View style={{
          flexDirection: 'row', height: 35, position: 'absolute',
          zIndex: 1, marginTop: "58%", justifyContent: 'center', alignContent: 'center', alignItems: 'center', backgroundColor: '#0068851A', width: windowWidth
        }}>
          <ActivityIndicator color={color} size={isLarge ? 'large' : 'small'} />
          <Text style={{ paddingLeft: 20 }}>Loading data...</Text>
        </View>
      </View>
    </View>
  );
};
const styles = StyleSheet.create({
  viewLoading: {
    zIndex: 1,
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.1333333)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  bg_login: {
    flexDirection: 'column',
    alignItems: 'center',
    width: windowWidth,
    height: windowHeight,
    backgroundColor: 'transparent',
    // justifyContent:  'center'
  },
  vnaImage: {
    height: 35,
    width: 310,
    position: 'absolute',
    right: 50,
    bottom: 60,
    zIndex: 1,
  },
  vnaBackgroundImage: {
    height: windowHeight,
    width: windowWidth,
  }
});

export default React.memo(LoadingView);
