import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import DrawerView from './DrawerView.Screen';
import { BottomTabCategoryIcon, BottomTabFavouriteIcon, BottomTabHomeIcon, BottomTabSearchIcon, DanhMucIcon, UserGreyIcon } from '../assets/svg/index';
import styles from './RootContainer.Style';
import DashboardScreen from '../Screen/dashboard/Dashboard.Screen';
import { bottomTabName } from 'helpers/Constants';
import FavoriteScreen from '../Screen/favorites/favorite.Screen';
import ApplicationScreen from '../Screen/aplications/Application.Screen';
import LookupScreen from '../Screen/lookup/lookup.Screen';
import ThongBaoScreen from '../Screen/dashboard/thongbao/ThongBao.Screen';
import DashboardDetailScreen from '../Screen/dashboard/DashboardDetailScreen';
import HeaderWithAvatar from 'components/HeaderWithAvatar';
import { useSelector } from 'react-redux';
import { RootState } from 'stories/index';
import DSBinhLuan from '../Screen/dashboard/DSBinhLuan/DSBinhLuan.Screen';
import VBTuongTac from '../Screen/dashboard/VBTuongTac/VBTuongTac.Screen';
import DoucumentListView from '../Screen/aplications/Child/DoucumentListView.Screen';
import DoucumentFavoriteListView from '../Screen/favorites/Child/DoucumentFavoriteListView.Screen';
import LookupDetail from '../Screen/lookup/child/LookupDetail.Screen';


const Stack = createStackNavigator();
const DrawerStack = createDrawerNavigator();
const BottomStack = createBottomTabNavigator();

function AppDrawerStack() {
  return (
    <DrawerStack.Navigator drawerContent={props => <DrawerView {...props} />}>
      <DrawerStack.Screen
        options={{ headerShown: false }}
        name="AppBottomStack"
        component={AppBottomStack}
      />
    </DrawerStack.Navigator>
  );
}

const renderTabIcon = (isFocused: Boolean, label: String, languages: any) => {
  switch (label) {
    case languages.tab_home:
      return <BottomTabHomeIcon focused={isFocused} />;
    case languages.bottomtab_category:
      return <BottomTabCategoryIcon focused={isFocused} />;
    case languages.bottomtab_search:
      return <BottomTabSearchIcon focused={isFocused} />;
    default:
      return <BottomTabFavouriteIcon focused={isFocused} />;
  }
};
function MyTabBar({ state, descriptors, navigation, languages }: any) {
  return (
    <View style={styles.viewTabBottomBar}>
      {state.routes.map((route: any, index: number) => {
        const { options } = descriptors[route.key];
        const label =
          options.tabBarLabel !== undefined
            ? options.tabBarLabel
            : options.title !== undefined
              ? options.title
              : route.name;

        const isFocused = state.index === index;

        const onPress = () => {
          const event = navigation.emit({
            type: 'tabPress',
            target: route.key,
            canPreventDefault: true,
          });

          if (!isFocused && !event.defaultPrevented) {
            // The `merge: true` option makes sure that the params inside the tab screen are preserved
            navigation.navigate({ name: route.name, merge: true });
          }
        };

        const onLongPress = () => {
          navigation.emit({
            type: 'tabLongPress',
            target: route.key,
          });
        };

        return (
          <TouchableOpacity
            key={label}
            activeOpacity={1}
            accessibilityRole="button"
            accessibilityState={
              isFocused ? { selected: true } : { selected: false }
            }
            accessibilityLabel={options.tabBarAccessibilityLabel}
            testID={options.tabBarTestID}
            onPress={onPress}
            onLongPress={onLongPress}
            style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <View style={styles.tabBarIconView}>
              {renderTabIcon(isFocused, label, languages)}
            </View>

            <Text
              style={
                isFocused
                  ? styles.tabBarLabelActive
                  : styles.tabBarLabelInActive
              }>
              {label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}
function AppBottomStack() {
  const { languages, } = useSelector((state: RootState) => state.languages);
  return (
    <BottomStack.Navigator
      options={{
        headerShown: false,
      }}
      tabBar={props => {
        return <MyTabBar {...props} languages={languages} />;
      }}>
      <BottomStack.Screen
        options={{
          headerShown: false,
          tabBarActiveBackgroundColor: '#DBA410',
          tabBarInactiveBackgroundColor: '#006885',
          tabBarLabelStyle: styles.tabBarLabelActive,
          tabBarStyle: { display: 'flex' },
        }}
        name={languages.tab_home}
        component={HomeStack}
      />
      <BottomStack.Screen
        name={languages.bottomtab_category}
        component={ApplicationScreen}
        options={{
          headerShown: false,
          tabBarActiveBackgroundColor: '#025ED8',
          tabBarInactiveBackgroundColor: '#025ED8',
          tabBarLabelStyle: styles.tabBarLabelActive,
          tabBarIcon: ({ focused }) => (
            <View
              style={[
                styles.tabBarIconView,
                focused && { backgroundColor: '#fff' },
              ]}>
              <BottomTabCategoryIcon color={focused ? 'clear' : '#fff'} />
            </View>
          ),
        }}
        component={ApplicationStack}
      />
      <BottomStack.Screen
        name={languages.bottomtab_search}
        component={LookupStack}
        options={{
          headerShown: false,
          tabBarActiveBackgroundColor: '#025ED8',
          tabBarInactiveBackgroundColor: '#025ED8',
          tabBarLabelStyle: styles.tabBarLabelActive,
          tabBarIcon: ({ focused }) => (
            <View
              style={[
                styles.tabBarIconView,
                focused && { backgroundColor: 'black' },
              ]}>
              <BottomTabSearchIcon color={focused ? '#025ED8' : 'black'} />
            </View>
          ),
        }}
      />
      <BottomStack.Screen
        name={languages.bottomtab_favourite}
        component={FavoriteStack}
        options={{
          headerShown: false,
          tabBarActiveBackgroundColor: '#025ED8',
          tabBarInactiveBackgroundColor: '#025ED8',
          tabBarLabelStyle: styles.tabBarLabelActive,
          tabBarIcon: ({ focused }) => (
            <View
              style={[

                styles.tabBarIconView,

                focused && { backgroundColor: '#fff' },
              ]}>
              <BottomTabFavouriteIcon color={focused ? '#FFFFFF' : '#fff'} />
            </View>
          ),
        }}
      />
    </BottomStack.Navigator>
  );
}

function HomeStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        options={{ headerShown: false }}
        name="DashboardScreen"
        component={DashboardScreen}
      />

      {/* <Stack.Screen
        options={{headerShown: false}}
        name="ThongBaoScreen"
        component={ThongBaoScreen}
      /> */}
    </Stack.Navigator>


  );
}


function ApplicationStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        options={{ headerShown: false }}
        name="ApplicationScreen"
        component={ApplicationScreen}
      />

      <Stack.Screen
        options={{ headerShown: false }}
        name="DoucumentListView"
        component={DoucumentListView}
      />


    </Stack.Navigator>


  );
}

function FavoriteStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        options={{ headerShown: false }}
        name="FavoriteScreen"
        component={FavoriteScreen}
        initialParams={{ type: 'Tab' }}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name="DoucumentFavoriteListView"
        component={DoucumentFavoriteListView}
      />
    </Stack.Navigator>
  );
}
function LookupStack() {
  return (
    <Stack.Navigator>

      <Stack.Screen
        options={{ headerShown: false }}
        name="LookupScreen"
        component={LookupScreen}
        initialParams={{ type: 'Tab' }}
      />
           <Stack.Screen
        options={{ headerShown: false }}
        name="LookupDetail"
        component={LookupDetail}
      />
    </Stack.Navigator>
  );
}

export default function DrawerNavigatorStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        options={{ headerShown: false }}
        name="AppDrawerStack"
        component={AppDrawerStack}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name="DashboardDetailScreen"
        component={DashboardDetailScreen}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name="ThongBaoScreen"
        component={ThongBaoScreen}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name="DSBinhLuan"
        component={DSBinhLuan}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name="VBTuongTac"
        component={VBTuongTac}
      />
    </Stack.Navigator>
  );
}
