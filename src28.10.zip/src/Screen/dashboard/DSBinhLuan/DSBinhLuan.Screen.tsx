import React, { FC, useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Alert, FlatList, RefreshControl, Animated, ScrollView, ActivityIndicator } from 'react-native';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { useDispatch, useSelector } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaView } from 'react-native-safe-area-context';
import { GetInteractDocument, GetListCommentDocument, GetListNotify, GetListUnreadNotify, getAutoLoginMobile } from 'stories/dashboard/reducer';
import { arrayIsEmpty } from 'helpers/Functions';
import NoDataView from 'components/NoDataView';
import { FontSize, M_DataLimitRow, dimensWidth, windowWidth } from 'helpers/Constants';
import colors from 'helpers/Colors';
import HTML from 'react-native-render-html';
import FastImage from 'react-native-fast-image';
import { Col, Row } from 'react-native-flex-grid';
import FastImageCustom from 'components/FastImageCustom';
import styles from './DSBinhLuan.Style';
import { useNavigation } from '@react-navigation/native';
import { Console } from 'console';
import LoadingDots from "react-native-loading-dots";
import { RootState } from 'stories/index';

interface Props {
  modalVisible: Boolean;
  onCloseModal: () => void;
  ActionJson: any;
}

  //renderFooter
  const renderFooter = (isLoading: boolean, refreshing: boolean, isLoadMoreComment: boolean, Offset: any) => {
    return (
      //Footer View with Load More button
      <View style={styles.footer}>
        {isLoading && !refreshing && isLoadMoreComment && Offset !== 0 ? (
          <ActivityIndicator color="blue" style={{ marginLeft: 8 }} />
        ) : null}
      </View>
    );
  };

const DSBinhLuan: FC<Props> = ({
  modalVisible,
  onCloseModal,
  ...props
}: Props) => {
  let initialPayloadComment = {}
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const [Offset, setOffset] = useState(0);
  const [dataCommentState, setdataCommentState] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  let initialPayloadNotify = { limit: 100, offset: Offset }
  let initialPayloadUnReadNotify = { limit: 100, offset: Offset, isCount: 0 }
  const [payloadNotify, setpayloadNotify] = useState<any>(initialPayloadNotify);
  const [payloadUnReadNotify, setpayloadUnReadNotify] = useState<any>(initialPayloadUnReadNotify);
  const [payloadComment, setPayloadComment] = useState<any>(initialPayloadComment);
  const [flatListReady, setFlatListReady] = useState(false)
  const navigation = useNavigation()
  const fadeAnim = new Animated.Value(1);
  const {languages,languagesText } = useSelector((state: RootState) => state.languages);
  const dataComment = useSelector(
    (state: any) => state.dashboard
  )
  const {totalRecord} = dataComment;
  const isLoadMoreComment = useSelector(
    (state: any) => state.dashboard
  )
  const isLoadingComment = useSelector((state: any) => state.dashboard)

  //fetchGetListDataCommentRequest
  const fetchGetListDataCommentRequest = useCallback((payload: any) => {
    dispatch(GetListCommentDocument(payload))
  }, [dispatch])
  useEffect(() => {
    const langId = languagesText === 'EN' ? 1033 :1066
    fetchGetListDataCommentRequest({ ...payloadComment, langId,limit: 20, offset: Offset })
  }, [payloadComment,dispatch,languagesText,Offset])

  //onRefresh
  const onRefresh = useCallback(() => {
    setRefreshing(true);
    setOffset(0);
    setpayloadNotify(initialPayloadNotify)
    setPayloadComment(initialPayloadComment)
    dispatch(GetListNotify(initialPayloadNotify));
    dispatch(GetListCommentDocument(initialPayloadComment))
  }, [refreshing]);

  useEffect(() => {
    setdataCommentState(dataComment.dataListComment);
    if(refreshing) setRefreshing(false)
  }, [dataComment])

  const handleLoadmore = async() => {
    if (dataComment.dataListComment.length < totalRecord) {
        setOffset(dataComment.dataListComment.length);
    }
   }

  const onGoBack = useCallback(() => {
    navigation.goBack();
  }, [navigation]);

  const gotoDetailPress = useCallback(
    (ResourceUrl: any) => {
      dispatch(getAutoLoginMobile());
      navigation.navigate({
        name: "DashboardDetailScreen",
        params: { urlThongBao: ResourceUrl },
      });
      console.log("item?.b =>>> " + ResourceUrl)
    },
    [dispatch, navigation],
  )

  const _scrolled = () =>{
    setFlatListReady(true)
    }
  //ResourceUrl
  const ItemGrid = ({ item, gotoDetail,index }: any) => {
    const {
      Title,
      StorageCode,
      Created,
      Type,
      Thumbnail,
      IsApproved,
      Status,
      Content,
      ResourceUrl
    } = item;

    const htmlContent = Content
    const idOdd = index % 2 === 0;
    const formatDate = (dateString: any) => {
      const parsedDate = new Date(dateString);
      const formattedDate =
        parsedDate.toLocaleTimeString().slice(0, 5) + " " +
        parsedDate.toLocaleDateString('en-GB', {
          day: '2-digit',
          month: '2-digit',
          year: 'numeric'
        });
      return formattedDate;
    };

    //FormatTextStatusToString
    const FormatTextStatusToString = (itemp: any) => {
      if (item.Status == -1) {
        return 'Đã xóa'
      }
      if (item.IsApproved === null || item.IsApproved === 0) {
        return "Chờ phê duyệt";
      }
      if (item.IsApproved === 1) {
        return "Đã phê duyệt";
      }

      if ((item.IsApproved === 0)) {
        return "Bị từ chối";
      }
      else
        return "Nodata"
    }

    //ColorStatusToString
    const ColorStatusToString = (itemp: any) => {
      if (item.Status == -1) {
        return '#FFCDCD'
      }
      if (item.IsApproved === null || item.IsApproved === 0) {
        return "#D1E9FF";
      }
      if (item.IsApproved === 1) {
        return "#D1FECE";
      }

      if ((item.IsApproved === 0)) {
        return "#FFCDCD";
      }
      else
        return "white"
    }
    return (
      <ScrollView horizontal style={[styles.viewScrollViewGrid, idOdd && { backgroundColor: '#F1FAFF' }]} >
        <View>
          <View key={index} >
            <TouchableOpacity onPress={() => gotoDetail(ResourceUrl)}>
            <Row style={styles.cellContent}>
              <Col style={{ padding: 10, width: 210, flexDirection: 'row' }}>
                <FastImage style={{
                  height: dimensWidth(15),
                  width: dimensWidth(15),
                  marginLeft: dimensWidth(2),
                }}
                  source={{ uri: item.Thumbnail }}
                  defaultSource={require('../../../../src/assets/images/icon_thumbDefault.png')}
                />
                <Text style={{ width: 320, marginLeft: 10, marginTop: 10, color: 'rgb(0, 104, 133)' }}>{item.Title}</Text>
              </Col>
              <Col style={{ padding: 10, width: 210 }}>
                <Text style={{ width: 270, marginLeft: 80, flexDirection: 'row' }}> <HTML source={{ html: htmlContent }} /></Text>
              </Col>
              <Col style={{ marginLeft: -350, padding: 10 }}>
                {/* <Text style={{textAlign: 'center'}}>{item.Title}</Text> */}
              </Col>
              <Col style={{ padding: 10 }}>
                <Text style={{ marginLeft: 120 }}>{formatDate(item.Created)}</Text>
              </Col>
              <Col style={{ padding: 10 }}>
                <Text style={{ marginLeft: 55, width: 170, height: 20, borderRadius: 10, textAlign: 'center', backgroundColor: ColorStatusToString(item.IsApproved) }}>{FormatTextStatusToString(item.IsApproved)}</Text>
              </Col>
            </Row>
            </TouchableOpacity>
    
          </View>
          <View>
          </View>
        </View>
      </ScrollView>
    );


  }
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <View style={styles.container}>
        <View style={{ alignItems: 'center' }}>
          <Text style={styles.title_header}>{languages.list_comments}</Text>
        </View>

        <TouchableOpacity
          activeOpacity={1}
          style={{ backgroundColor: 'blue' }}
          onPress={onGoBack}
        >
          {/* <Text style={styles.lbl_thoat} numberOfLines={1}>
              {"X"}
            </Text> */}
          <FastImage
            style={styles.icon_back}
            resizeMode='contain'
            source={require('../../../../src/assets/images/icon_closeForm.png')}
          />
        </TouchableOpacity>

        <View style={styles.flexDirectionRowTab}>
          <View>
            <Row style={styles.cellHeader}>
              <Col style={[{
                padding: 7,
                marginLeft: 10,
                backgroundColor: '#f0f0f0',
                borderColor: '#ccc',
              }]}>
                <Text style={{ fontWeight: 'bold',width:200 }}>{languages.t_n_v_n_b_n}</Text></Col>
              <Col style={[{
                padding: 7,
                marginLeft: 100,
                backgroundColor: '#f0f0f0',
                borderColor: '#ccc',
              }]}><Text style={{ fontWeight: 'bold', width: 300 }}>{languages.n_i_dung_v_n_b_n}</Text></Col>
              <Col style={[{
                padding: 7,
                marginLeft: 220,
                backgroundColor: '#f0f0f0',
                borderColor: '#ccc',
              }]}><Text style={{ fontWeight: 'bold', width: 200, marginLeft: -10 }}>{languages.date_comment}</Text></Col>
              <Col style={styles.cellHeader}><Text style={{ fontWeight: 'bold' }}>{languages.tr_ng_th_i}</Text></Col>
            </Row>
          </View>

        </View>
        {arrayIsEmpty(dataCommentState)  ? (
        <View style={styles.dotsWrapper}>
          <LoadingDots />
        </View>
      ) : !arrayIsEmpty(dataCommentState) ? (
        <FlatList
          contentContainerStyle={styles.containerFlatList}
          data={dataCommentState}
          extraData={dataCommentState}
          onScroll={_scrolled}
          refreshControl={
            <RefreshControl refreshing={isLoadingComment} onRefresh={onRefresh} tintColor='#0b5e5c' />
          }
          renderItem={({ item, index }) => (
            <ItemGrid item={item} gotoDetail={gotoDetailPress} index={index} />
          )}
          keyExtractor={(item, index) => String(index)}
          showsVerticalScrollIndicator={false}
          onEndReached={handleLoadmore}
          ListFooterComponent={renderFooter(isLoadingComment, refreshing, isLoadMoreComment, Offset)}
          onEndReachedThreshold={0.5}
        />
      ) : (
        <NoDataView onRetryPress={() => { /* Implement your retry logic here */ }} />
      )}
      </View>

    </SafeAreaView>
  );
};

export default DSBinhLuan;


