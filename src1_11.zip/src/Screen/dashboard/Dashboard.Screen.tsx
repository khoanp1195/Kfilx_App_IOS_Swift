import { FlatList, Image, RefreshControl, SectionList, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import React, { useCallback, useEffect, useState } from 'react';
import stylesD from './Dashboard.Style';
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from 'redux-thunk';
import { GetListDoucumentFavorite, fetchCurrentUsers, getAutoLoginMobile, getDocumentMostView, getUnReadNotify, getViewDocumentNew, setRecentlyViewedDocsAction } from 'stories/dashboard/reducer';
import { arrayIsEmpty, getCurrentTimeFormatted } from 'helpers/Functions';
import FastImage from 'react-native-fast-image';
import { ThongBaoIcon, UserGreyIcon } from 'assets/svg';
import { ScrollView } from 'react-native-gesture-handler';
import { FontSize, windowHeight, windowWidth } from 'helpers/Constants';
import HeaderWithAvatar from 'components/HeaderWithAvatar';
import TextCusTom from 'components/TextCusTom';
import NoDataView from 'components/NoDataView';
import colors from 'helpers/Colors';
import { RootState } from 'stories/index';
import DocumentViewItem from './components/DocumentViewItem';
import ModalProfile from './components/ModalProfile';
import { useFocusEffect } from '@react-navigation/native';
import uuid from 'react-native-uuid';
import Animated from 'react-native-reanimated';
import { Document } from '../../database//models/Document';
import { any } from 'prop-types';
import { getRecentlyDoc, setLoadOneTimeRecentlyViewedDocument, setLoadingRecentlyViewedDocument, setRecentlyViewedDocument } from 'stories/dashboard/recentlyReducer';
import DocumentRecently from '../../database/models/DocumentRecently';

type Props = {
  navigation: any;
  route: any;
};

const DashboardScreen = ({ navigation }: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const [Offset, setOffset] = useState(0);
  const { languages, languagesText } = useSelector((state: RootState) => state.languages);
  const dashboardData = useSelector((state: any) => state.dashboard);
  const [refreshing, setRefreshing] = useState(false);
  const {
    dataNewDocument,
    dataDocumentMostView,
    dataDocumentFavorite,
    notificationCount,
    dataCurrentUser,
  } = dashboardData;
  const {recentlyViewedDocumentData, isLoadingRecentlyViewed,isLoadOneTimeRecentlyViewed} = useSelector((state: RootState) => state.recentlyViewedDocument);
  
  const onRefresh = useCallback(() => {
    const langId = languagesText === 'EN' ? 1033 : 1066
    dispatch(getViewDocumentNew(langId))
    // dispatch(GetListDoucumentFavorite(langId))
    dispatch(getDocumentMostView(langId))
    dispatch(getUnReadNotify())
    getData();
  }, [languagesText]);


  const [dataHome, setDataHome] = useState<any>([
    {
      data: [
        {
          title: languages.newest_docs, data: []
        },
        { title: languages.recently_viewed_docs, data: [] },
        { title: languages.most_favourite_docs, data: [] },
        { title: languages.most_view_docs, data: [] },
      ]
    }
  ]);

  useFocusEffect(
    React.useCallback(() => {
      const langId = languagesText === 'EN' ? 1033 : 1066
      dispatch(getViewDocumentNew(langId))
      dispatch(GetListDoucumentFavorite(langId))
      dispatch(getDocumentMostView(langId))
      dispatch(getUnReadNotify())
      dispatch(fetchCurrentUsers());
    }, [languagesText])
  );


  const getDataNew = () => {
    const langId = languagesText === 'EN' ? 1033 : 1066
    Document.getNewDocument(false, false).then((values: any) => {
        dispatch(getViewDocumentNew(langId))
    })
}

const getDataFavorite = () => {
  const langId = languagesText === 'EN' ? 1033 : 1066
  Document.getNewDocument(false, true).then((values: any) => {
    dispatch(GetListDoucumentFavorite(langId))
  })
}

const getMostView = () => {
  const langId = languagesText === 'EN' ? 1033 : 1066
  Document.getNewDocument(true, false).then((values: any) => {
    dispatch(getDocumentMostView(langId))
  })

}

const getRecently=()=>{
  Document.getDucmentRecently().then((values: any) => {
      dispatch(setLoadOneTimeRecentlyViewedDocument(true))
      if (values != null && values.length > 0) {
          dispatch(setRecentlyViewedDocument(values));
      } else {
          dispatch(setLoadingRecentlyViewedDocument(false));
      }
      dispatch(getRecentlyDoc())
  })
}

const getData = async () => {
  getRecently();
  getDataNew();
  getDataFavorite();
  getMostView();
  dispatch(getUnReadNotify());

}

const saveItemClick = async (item: Document) => {
  DocumentRecently.insertOrUpdateAll([
      {
          documentID: item.DocumentId,
          modified: getCurrentTimeFormatted()
      }
  ]);
  Document.insertOrUpdateAll([item])
  // @ts-ignore
  getRecently();
}


  useEffect(() => {
    setDataHome([
      {
        data: [
          {
            title: languages.newest_docs, data: dataNewDocument
          },
          { title: languages.recently_viewed_docs, data: recentlyViewedDocumentData },
          { title: languages.most_favourite_docs, data: dataDocumentFavorite },
          { title: languages.most_view_docs, data: dataDocumentMostView },
        ]
      }
    ])

  }, [dashboardData,recentlyViewedDocumentData])
  useEffect(() => {

  }, [recentlyViewedDocumentData]);

  //gotoDetailPress
  const gotoDetailPress = useCallback(
    (item: any) => {
      // let newData: any = recentlyViewedDocs
      // const checkIsnotExistOrEmpty = (data: any) => {
      //   if (arrayIsEmpty(data)) return true
      //   if (data.find((it: any) => it?.ID === item?.ID)) {
      //     return false
      //   }
      //   return true
      // }
      // if (checkIsnotExistOrEmpty(newData)) {
      //   newData = [item, ...newData];
      //   if (newData?.length > 5) newData = newData.slice(0, 5);
      //   dispatch(setRecentlyViewedDocsAction(newData));
      // }
      // console.log('itemmmm', item);


      dispatch(getAutoLoginMobile());
      navigation.navigate({
        name: "DashboardDetailScreen",
        params: { id: item?.MainDocumentId, urlRecentltDoc: item.Url ,isMain: true },
      });
      saveItemClick(item)
     setTimeout(() => saveItemClick(item), 1000);
    },
    [],
  )


  return (
    <View style={styles.container}>
      <FastImage
        style={styles.vnaBackgroundImage}
        resizeMode='contain'
        source={require('../../../src/assets/images/img_background_home.png')}
      />
        <HeaderWithAvatar item={dashboardData.dataCurrentUsers} title={languages.tab_home} notificationCount={notificationCount?.dashboardCountData} urlOnline={dashboardData.dataCurrentUsers?.ImagePath} />

      <SectionList sections={dataHome}
        extraData={dataHome}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor='#0054AE' />
        }
        renderItem={({ item }) => (
          <View>
            <TextCusTom i18nKey={item.title} style={styles.textTitle} />
            {!arrayIsEmpty(item.data) ? (
              <FlatList
                contentContainerStyle={styles.containerFlatList}
                data={item.data}
                extraData={item.data}
                horizontal={true}
                renderItem={({ item }) => (
                  <DocumentViewItem item={item} gotoDetail={gotoDetailPress} />
                )}
                showsHorizontalScrollIndicator={false}
                keyExtractor={(item: any, index) => uuid.v4().toString()}
              />
            ) : (
              <NoDataView />
            )}
            <View style={styles.line} />
          </View>
        )}
        keyExtractor={(item, index) => uuid.v4().toString()}>
      </SectionList>
    </View>
  );
};
const styles = StyleSheet.create({
  container: { 
    flex: 1,
    justifyContent:'center'
     
  
  },
 
 
  containerFlatList: {
    marginLeft: '4%',
    width: 500,
  },
  textTitle: {
    color: '#DBA410',
    fontSize: 20,
    fontFamily: 'Heritage Sans',
    fontWeight: '700',
    margin: 20
  },

  line: {
    marginLeft: 20,
    height: 1,
    width: windowWidth - 40,
    backgroundColor: 'lightgray',
    marginTop: 20
  },
  sectionHeader: {
    paddingTop: 2,
    paddingLeft: 10,
    paddingRight: 10,
    paddingBottom: 2,
    fontSize: 22,
    fontWeight: 'bold',
    color: "#fff",
    backgroundColor: '#8fb1aa',
  },
  item: {
    padding: 10,
    fontSize: 18,
    height: 44,
  },
  vnaBackgroundImage: {
    height: '150%',
    marginTop: '-10%',
    width: '100%',
    position: 'absolute',
    zIndex: 0
  }
});
export default React.memo(DashboardScreen);