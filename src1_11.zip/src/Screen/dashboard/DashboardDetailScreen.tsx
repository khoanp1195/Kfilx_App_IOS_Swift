
import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
 import { WebView } from 'react-native-webview';
import Header from '../../components/HeaderDetail'
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from 'redux-thunk';
import { getAutoLoginMobile } from 'stories/dashboard/reducer';
import { RootState } from 'stories/index';
import colors from 'helpers/Colors';
import { checkIsEmpty } from 'helpers/Functions';
import axios from 'axios';
import { BASE_URL, Subsite, subsiteStore, windowHeight, windowWidth } from 'helpers/Constants';
import LoadingDots from "react-native-loading-dots";
type Props = {
    navigation: any
    route: any
}
// ...
const DashboardDetail = ({route, navigation}: Props) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const {languages,languagesText } = useSelector((state: RootState) => state.languages);
    const autoId  = useSelector((state: RootState) => state.dashboard);
    const [autoIdState, setAutoIdState] = useState(null)
    const {id} = route.params
    const{urlThongBao} = route.params
    const {isThongBao} = route.params
    const {isMain} = route.params
    const [isLoading, setIsLoading] = useState(true);
    const [data, setData] = useState(null);
    const {urlRecentltDoc} = route.params
    const item = route.params.item;
  useEffect(() => {
    fetchData();
  }, []);





  console.log('isThongBao =>>> ' + urlThongBao)
  function GetUrlInfo(_url: string) {
    let rID = '';
    let cID = '';
  
    if (_url && _url.includes('/') && _url.includes('.') && _url.includes('-')) {
      if (_url.includes('VNADetailVB.aspx') && _url.includes('?') && _url.includes('&') && _url.includes('=')) {
        const queryParameters = _url.split('?').pop().split('&');
        const idParam = queryParameters[0].split('=').pop(); // id van ban
        cID = queryParameters[2].split('=').pop();
        rID = idParam;
      } else {
        const urlParts = _url.split('/');
        const lastPart = urlParts[urlParts.length - 1];
        const firstPart = lastPart.split('.').shift();
        rID = firstPart.split('-').pop();
        cID = urlParts[urlParts.length - 2].split('-').pop();
      }
    }
  
    return { rID, cID };
  }
  
  // Usage example:
  const { rID, cID } = GetUrlInfo(urlThongBao);
  console.log('rID:', rID);
  console.log('cID:', cID);
  



  const fetchData = async () => {
    try {
      const response = await axios.get('https://vnadmsuatportal.vuthao.com/psd/API/User.ashx?func=mobileAutoLoginWeb');
      const responseData = response.data;
      const dataValue = responseData.data;
      setData(dataValue);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };
   // Function to handle WebView load finish
   const handleWebViewLoadFinish = () => {
    // Set isLoading to false when the WebView finishes loading
    setIsLoading(false);
  };

  
  const uRL_notify = `${BASE_URL}/${
    Subsite
  }${urlThongBao?.includes('MailContent.aspx')
    ? urlThongBao
    : `/frontend/pages/VNADetailVB.aspx?rid=${rID}&gid=1&cid=${cID}`}&Mobile=1&autoid=$${data}&lang=${languagesText.toLowerCase()}`;


  const uRL_main = `${BASE_URL}/psd/frontend/pages/VNADetailVB.aspx?rid=${id}&gid=1&cid=3&Mobile=1&autoid=${data}&lang=${languagesText.toLowerCase()}`;
  let url
  if (isThongBao)
  {
     url = uRL_notify
  }
  else if (isMain)
  {
    // if(rID === "" && cID === "")
    // {
    //   const parts = urlRecentltDoc.split('/');
    //   const path = parts[parts.length - 1];
    //  url =  BASE_URL + '/psd/' + path ;
   
    // }
    // else{
    //   url = uRL_main
    // }
    url = uRL_main
    console.log('url - WebViewwww =>>> ' +  url)
  }
  else
  {  
   url = uRL_notify
  }



  if (item.Url == null) {
    if(!item.IsStandard)
        url = `${BASE_URL}/${subsiteStore.getSubsite()}/frontend/pages/VNADetailVB.aspx?rid=${item.ResourceId}&gid=1&cid=3&Mobile=1&autoid=${id}&lang=vi`
    else
        url = `${BASE_URL}/${subsiteStore.getSubsite()}/frontend/pages/VNAVbbnDetail.aspx?rid=${item.ResourceId}&gid=3&cid=${item.CategoryId}&Mobile=1&autoid=${id}&lang=vi`
} else {
    url = item.Url;
}


  return (
    <View style={{ flex: 1, backgroundColor: colors.white }}>
      <Header isThongBao={isThongBao}/>

      {/* Show the ActivityIndicator while loading */}
      {isLoading && (
         <View style={styles.dotsWrapper}>
         <LoadingDots />
       </View>
      )}
      {/* Render WebView */}
      <WebView
        source={{
          uri: `${url}`
        }}
        sharedCookiesEnabled
        thirdPartyCookiesEnabled
        allowFileAccess
        cacheEnabled
        onLoad={() => handleWebViewLoadFinish()} // Call the function when WebView finishes loading
      />
    </View>
  );
}

export default DashboardDetail

const styles = StyleSheet.create({
  dotsWrapper: {
    height: 100,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    top: windowHeight/2,
    left: windowWidth/2,
    zIndex: 1
  },
})



