import {appSchema, tableSchema} from "@nozbe/watermelondb";
import {Document} from "./models/Document";
import DocumentRecently from "./models/DocumentRecently";
import {ConfigNotification} from "./models/ConfigNotification";
import {DocumentInteractive} from "./models/DocumentInteractive";
import {Comment} from "./models/Comment";
import {DocumentAreaCategory} from "./models/DocumentAreaCategory";
import {FavoriteFolder} from "./models/FavoriteFolder";
import {DocumentType} from "./models/DocumentType";
import {DocumentCategory} from "./models/DocumentCategory";
import DocumentOffline from "./models/DocumentOffline";
import {SearchHistory} from "./models/SearchHistory";
import {DocumentFavorite} from "./models/DocumentFavorite";
import {Notify} from "./models/Notify";
// import {SubSite} from "./models/SubSite";
import {StandardDoc} from "./models/StandardDoc";

const schema = appSchema({
    version: 1,
    tables: [
        DocumentRecently.getSchema(),
        Document.getSchema(),
        ConfigNotification.getSchema(),
        DocumentInteractive.getSchema(),
        Comment.getSchema(),
        DocumentAreaCategory.getSchema(),
        FavoriteFolder.getSchema(),
        DocumentType.getSchema(),
        DocumentCategory.getSchema(),
        DocumentOffline.getSchema(),
        SearchHistory.getSchema(),
        DocumentFavorite.getSchema(),
        Notify.getSchema(),
        // SubSite.getSchema(),
        StandardDoc.getSchema()
    ],
});
export default schema;
