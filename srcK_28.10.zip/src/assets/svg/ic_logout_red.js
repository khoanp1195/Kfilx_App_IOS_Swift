import * as React from "react";
import Svg, { Path } from "react-native-svg";

function SvgComponent(props) {
  return (
    <Svg
      width={20}
      height={20}
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M0 9.565c0 5.274 4.291 9.565 9.565 9.565a9.576 9.576 0 009.019-6.377.435.435 0 00-.82-.29 8.705 8.705 0 01-8.199 5.798C4.77 18.26.87 14.36.87 9.565S4.77.87 9.565.87c3.68 0 6.975 2.33 8.2 5.796a.435.435 0 00.82-.29A9.578 9.578 0 009.564 0C4.291 0 0 4.291 0 9.565zm10 3.913a.437.437 0 01-.308-.127L6.214 9.873a.435.435 0 010-.615L9.692 5.78a.435.435 0 01.615.615L7.571 9.13h11.994a.435.435 0 010 .87H7.571l2.736 2.736a.435.435 0 01-.307.742z"
        fill="red"
      />
    </Svg>
  );
}

export default SvgComponent;
