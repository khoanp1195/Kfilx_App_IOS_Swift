import * as React from "react";
import Svg, { Path } from "react-native-svg";

function SvgComponent(props) {
  return (
    <Svg
      width={19}
      height={20}
      viewBox="0 0 19 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M.4 0h4.8c.22 0 .4.18.4.4v4.8a.4.4 0 01-.4.4H.4a.4.4 0 01-.4-.4V.4C0 .18.18 0 .4 0zm.4 4.8h4v-4h-4v4zM6.9 0h4.8c.22 0 .4.18.4.4v4.8a.4.4 0 01-.4.4H6.9a.4.4 0 01-.4-.4V.4c0-.22.18-.4.4-.4zm.4 4.8h4v-4h-4v4zM18.2 0h-4.8a.4.4 0 00-.4.4v4.8c0 .22.18.4.4.4h4.8a.4.4 0 00.4-.4V.4a.4.4 0 00-.4-.4zm-.4 4.8h-4v-4h4v4zM.4 7.2h4.8c.22 0 .4.18.4.4v4.8a.4.4 0 01-.4.4H.4a.4.4 0 01-.4-.4V7.6c0-.22.18-.4.4-.4zM.8 12h4V8h-4v4zm10.9-4.8H6.9a.4.4 0 00-.4.4v4.8c0 .22.18.4.4.4h4.8a.4.4 0 00.4-.4V7.6a.4.4 0 00-.4-.4zm-.4 4.8h-4V8h4v4zm2.1-4.8h4.8c.22 0 .4.18.4.4v4.8a.4.4 0 01-.4.4h-4.8a.4.4 0 01-.4-.4V7.6c0-.22.18-.4.4-.4zm.4 4.8h4V8h-4v4zm-8.6 2.4H.4a.4.4 0 00-.4.4v4.8c0 .22.18.4.4.4h4.8a.4.4 0 00.4-.4v-4.8a.4.4 0 00-.4-.4zm-.4 4.8h-4v-4h4v4zm2.1-4.8h4.8c.22 0 .4.18.4.4v4.8a.4.4 0 01-.4.4H6.9a.4.4 0 01-.4-.4v-4.8c0-.22.18-.4.4-.4zm.4 4.8h4v-4h-4v4zm10.9-4.8h-4.8a.4.4 0 00-.4.4v4.8c0 .22.18.4.4.4h4.8a.4.4 0 00.4-.4v-4.8a.4.4 0 00-.4-.4zm-.4 4.8h-4v-4h4v4z"
        fill="#49FBFF"
      />
    </Svg>
  );
}

export default SvgComponent;
