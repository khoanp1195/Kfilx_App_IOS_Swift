import * as React from "react";
import Svg, { Path } from "react-native-svg";

function SvgComponent(props) {
  return (
    <Svg
      width={20}
      height={20}
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M0 10.009C-.005 4.486 4.469.005 9.991 0 15.511.01 19.986 4.48 20 10c0 5.52-4.472 9.995-9.991 10C4.486 20.005.005 15.531 0 10.009zm9.991 9.138v-.008A9.156 9.156 0 0019.14 10a9.139 9.139 0 10-9.148 9.147zm.44-5.607V8.803H8.656v.861h.913v3.876h-.913v.861h2.679v-.861h-.904zM9.233 6.348a.74.74 0 11.758.74.75.75 0 01-.758-.74z"
        fill="#000"
      />
    </Svg>
  );
}

export default SvgComponent;
