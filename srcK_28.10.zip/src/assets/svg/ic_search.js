import * as React from "react";
import Svg, { Path } from "react-native-svg";

function SvgComponent(props) {
  const { color = "#585858" } = props;
  return (
    <Svg
      width={18}
      height={18}
      viewBox="0 0 18 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M12.455 11.857l5.415 5.415a.41.41 0 010 .598.41.41 0 01-.598 0l-5.415-5.415a7.126 7.126 0 11.598-.598zM7.143.89A6.253 6.253 0 00.89 7.143a6.262 6.262 0 006.253 6.253 6.253 6.253 0 100-12.506z"
        fill={color}
      />
    </Svg>
  );
}

export default SvgComponent;
