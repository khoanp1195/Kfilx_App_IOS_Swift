import * as React from "react";
import Svg, { Path } from "react-native-svg";

function SvgComponent(props) {
  return (
    <Svg
      width={18}
      height={18}
      viewBox="0 0 18 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M9 0a9 9 0 109 9 9.01 9.01 0 00-9-9zm0 16.875A7.875 7.875 0 1116.875 9 7.884 7.884 0 019 16.875zm2.696-6.469a.562.562 0 100-1.125H9.214V5.812a.562.562 0 10-1.125 0v4.032c0 .31.252.562.562.562h3.045z"
        fill="#989898"
      />
    </Svg>
  );
}

export default SvgComponent;
