import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { RESONSE_STATUS_SUCCESS } from 'helpers/Constants';
import { isNullOrUndefined } from 'helpers/Functions';
import { get } from '../../services/ApiServices';

export const getinteractiveDocs = createAsyncThunk(
    'profilemenu/getinteractiveDocs',
    async ({ langId, Offset }: any) => {
        const res = await get(
            `/psd/API/ApiMobile.ashx?func=GetInteractiveDocument&LangId=${langId}&Params=LangId%2COffset%2CLimit&Offset=${Offset}&Limit=20`,
        );

        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return {
                    data: res.data.data.Data,
                    totalRecord: res.data.data.MoreInfo[0].totalRecord,
                    Offset
                };
            }
        } else {
            return {
                data: [],
                totalRecord: 0,
                Offset
            };
        }
    },
);
const profilemenuSlice = createSlice({
    name: 'profilemenu',
    initialState: {
        interactiveDocs: {
            data: [],
            isLoading: false,
            totalRecord: 0
        }
    },
    reducers: {
        resetProfilemenuAction(state, action) {
            return {
                ...state,
                interactiveDocs: {
                    data: [],
                    isLoading: false,
                    totalRecord: 0
                }
            };
        },
    },
    extraReducers: builder => {
        builder.
            addCase(getinteractiveDocs.pending, (state: any, action: any) => {
                state.interactiveDocs.isLoading = true
            }).
            addCase(getinteractiveDocs.fulfilled, (state: any, action: any) => {
                const { Offset } = action.payload
                state.interactiveDocs = {
                    data: Offset === 0 ? action.payload.data : state.interactiveDocs.data.concat(action.payload.data),
                    totalRecord: action.payload.totalRecord,
                    isLoading: false,
                }
            }).
            addCase(getinteractiveDocs.rejected, (state: any, action: any) => {
                state.interactiveDocs.isLoading = false
            })
    }
});
export const { resetProfilemenuAction } = profilemenuSlice.actions;
const { reducer } = profilemenuSlice;
export default reducer;
