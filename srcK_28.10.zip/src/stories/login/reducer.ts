import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { get, post } from '../../services/ApiServices';
import { BASE_URL, RESONSE_STATUS_SUCCESS } from 'helpers/Constants';
import { isNullOrUndefined } from 'helpers/Functions';
import AsyncStorage from '@react-native-async-storage/async-storage';
interface PayloadAction {
    userName: String;
    password: String;
}

export const loginRequestApi = createAsyncThunk(
    'login/loginRequest',
    async (payload: PayloadAction) => {
        let data = new FormData();
        console.log('payloadpayload', payload);

        // const jsonData = { UserName: "vnadmsuat.adminsite", Password: "vnadmsuat@123$%" }
        const jsonData = { UserName: payload.userName, Password: payload.password }
        data.append("data", JSON.stringify(jsonData));
        let config = {
            method: 'post',
            url: 'https://vnadmsuatportal.vuthao.com/psd/api/ApiMobile.ashx?func=AdfsLogin',
            data: data,
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'multipart/form-data',
            },
        };
        const a = await axios(config);
        const response = await axios(config);
        console.log('responseresponse222', response.headers["set-cookie"]);
        if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
            return {
                username: payload.userName,
                password: payload.password
            }
        }
        return;
    }
);

export const fetchCurrentUser = createAsyncThunk(
    'home/currentUser',
    async () => {
        const res = await get(`/psd/api/ApiMobile.ashx?func=CurrentUser&enc=RSA`);
        if (!isNullOrUndefined(res)) {
            if (res.data.status.toString() === RESONSE_STATUS_SUCCESS) {
                return res.data.data;
            }
        }

        return null;
    },
);
export const fetchRealSite = createAsyncThunk(
    'fetchRealSite',
    async (accountName: any) => {
        const url =
            '/pa/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetRealSite';
        const data = { AccountName: accountName };
        const response = await post(url, data);
        if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
            return response.data.data;
        }
    },
);
const defaultState = {
    isAuth: false,
    dataCurrentUsers: [],
    isLogging: false,
    isLoading: false,
    isShowWarning: false
}
const loginSlice = createSlice({
    name: 'login',
    initialState: defaultState,
    reducers: {
        logoutAction(state, action) {
            return {
                ...state,
                isAuth: defaultState.isAuth,
                isLogging: defaultState.isLogging,
                isShowWarning: defaultState.isShowWarning
            }
        },
        setIsLogging(state, action) {
            return { ...state, isError: action.payload };
        },
        setHideWarning(state, action) {
            return { ...state, isShowWarning: false };
        },
    },
    extraReducers: builder => {
        builder
            .addCase(loginRequestApi.pending, (state: any) => {
                state.isLoading = true;
                state.isLogging = false;
                state.isShowWarning = false;
            })
            .addCase(loginRequestApi.fulfilled, (state: any, action: any) => {
                state.isLoading = false;
                if (!isNullOrUndefined(action.payload?.username)) {
                    const { username, password } = action.payload
                    const saveUserInfo = async () => {
                        await AsyncStorage.setItem('userName', username)
                        await AsyncStorage.setItem('password', password)
                    };
                    saveUserInfo()
                    state.isAuth = true;
                    state.isLogging = true;
                } else {
                    state.isAuth = false;
                    state.isLogging = false;
                    state.isShowWarning = true;
                }
            })
            .addCase(loginRequestApi.rejected, (state: any) => {
                state.isLoading = false;
                state.isLogging = false;
                state.isShowWarning = true;
            })
            .addCase(fetchCurrentUser.fulfilled, (state: any, action) => {
                if (!isNullOrUndefined(action.payload)) {
                    state.dataCurrentUsers = action.payload;
                }
            });
    },
});
export const { logoutAction, setIsLogging, setHideWarning } = loginSlice.actions;
const { reducer } = loginSlice;
export default reducer;
