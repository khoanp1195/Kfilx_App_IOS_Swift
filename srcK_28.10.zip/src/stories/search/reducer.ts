import { createAsyncThunk, createSlice, } from '@reduxjs/toolkit';

const searchSlice = createSlice({
    name: 'search',
    initialState: {
        SearchList: [],
        searchText: ""
    },
    reducers: {
        addNewSearchText(state, action) {
            const newData = state.SearchList.length > 1000 ? action.payload.slice(0, 1000) : action.payload
            return {
                ...state,
                SearchList: newData
            };
        },
        setSearchText(state, action) {
            return {
                ...state,
                searchText: action.payload
            };
        },

    },
    extraReducers: builder => {
    }
});
export const { addNewSearchText, setSearchText } = searchSlice.actions;
const { reducer } = searchSlice;
export default reducer;
