import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { RESONSE_STATUS_SUCCESS } from 'helpers/Constants';
import { isNullOrUndefined } from 'helpers/Functions';
import { get, post } from '../../services/ApiServices';
import { Alert } from 'react-native';

export const getlistFavouriteDocs = createAsyncThunk(
    'favourite/getlistFavouriteDocs',
    async () => {
        const res = await get(
            `/psd/api/ApiMobile.ashx?func=Get&BeanName=FavoriteFolder&`
        );

        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return res.data.data.FavoriteFolder;
            }
        }
    },
);
export const getListDocumentFavourite = createAsyncThunk(
    'favourite/getListDocumentFavourite',
    async ({ Offset, FolderId = '807bf770-4f71-4771-bbd4-ebc4bcb777cb' }: any) => {

        const res = await get(
            `/psd/api/ApiMobile.ashx?func=GetDocumentFavoriteById&FolderId=${FolderId}&Params=FolderId,Offset,Limit&Offset=${Offset}&Limit=20&`);
        console.log('ressssss GetDocumentAreaFavourite', res);

        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return {
                    data: res.data.data.Data,
                    Offset,
                    totalRecord: res.data.data.MoreInfo[0].totalRecord
                }
            }
        }
    },
);
const listFavouriteSlice = createSlice({
    name: 'favourite',
    initialState: {
        listFavouriteDocs: [],
        listDocumentFavourite: {
            data: [],
            isLoading: false,
            totalRecord: 0
        },
        isLoading: false,
        positionStayFavourite: []
    },
    reducers: {
        resetListFavouriteAction(state, action) {
            return {
                ...state,
                listFavouriteDocs: [],
                isLoading: false
            };
        },
        addPositionStayFavourite: (state, action) => {
            // @ts-ignore
            state.positionStayFavourite.push(action.payload);
        },
        removeLastPositionStayFavourite: (state) => {
            state.positionStayFavourite.pop();
        },
        removeAllPositionStayFavourite: (state) => {
            state.positionStayFavourite = []
        }
    },
    extraReducers: builder => {
        builder.
            addCase(getlistFavouriteDocs.pending, (state: any, action: any) => {
                state.isLoading = true
            }).
            addCase(getlistFavouriteDocs.fulfilled, (state: any, action: any) => {
                state.listFavouriteDocs = action.payload
                state.isLoading = false
            }).
            addCase(getlistFavouriteDocs.rejected, (state: any, action: any) => {
                state.isLoading = false
            }).
            addCase(getListDocumentFavourite.pending, (state: any, action: any) => {
                state.listDocumentFavourite.isLoading = true
            }).
            addCase(getListDocumentFavourite.fulfilled, (state: any, action: any) => {
                const { Offset } = action.payload
                state.listDocumentFavourite = {
                    data: Offset === 0 ? action.payload.data : state.listDocumentFavourite.data.concat(action.payload.data),
                    totalRecord: action.payload.totalRecord,
                    isLoading: false,
                }
            }).
            addCase(getListDocumentFavourite.rejected, (state: any, action: any) => {
                state.listDocumentFavourite.isLoading = false
            })
    }
});
export const { resetListFavouriteAction, addPositionStayFavourite, removeAllPositionStayFavourite, removeLastPositionStayFavourite } = listFavouriteSlice.actions;
const { reducer } = listFavouriteSlice;
export default reducer;
