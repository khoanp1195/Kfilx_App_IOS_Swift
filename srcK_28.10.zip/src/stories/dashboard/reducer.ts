import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { get, post } from '../../services/ApiServices';
import { BASE_URL, RESONSE_STATUS_SUCCESS } from 'helpers/Constants';
import { isNullOrUndefined } from 'helpers/Functions';

export const getUnReadNotify = createAsyncThunk(
  'dashboard/getUnReadNotify',
  async () => {
    const res = await get(
      `/psd/API/ApiMobile.ashx?func=GetUnReadNotify&Params=Offset,Limit,isCount&Offset=0&Limit=0&isCount=1`,
    );
    console.log('resgetUnReadNotify', res);

    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data;
      }
    }

    return null;
  },
);
export const getViewDocumentNew = createAsyncThunk(
  'dashboard/getViewDocumentNew',
  async (LangId: number) => {
    const res = await get(
      `/psd/API/ApiMobile.ashx?func=GetViewDocumentNew&LangId=${LangId}&Params=LangId%2COffset%2CLimit&Offset=0&Limit=5`,
    );

    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data;
      }
    }

    return null;
  },
);
export const getDocumentMostView = createAsyncThunk(
  'dashboard/getDocumentMostView',
  async (LangId: number) => {
    const res = await get(
      `/psd/API/ApiMobile.ashx?func=GetDocumentMostView&LangId=${LangId}&Params=LangId%2CCategoryId%2COffset%2CLimit&CategoryId=5&Offset=0&Limit=5`,
    );

    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data;
      }
    }

    return null;
  },
);
export const getDocumentFavorite = createAsyncThunk(
  'dashboard/getDocumentFavorite',
  async (LangId: number) => {
    const res = await get(
      `/psd/API/ApiMobile.ashx?func=GetDocumentFavorite&LangId=${LangId}&Params=Offset%2CLimit&Offset=0&Limit=5`,
    );

    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data.Data;
      }
    }

    return null;
  },
);

export const getAutoLoginMobile = createAsyncThunk(
  'dashboard/getAutoLoginMobile',
  async () => {
    const res = await get('/psd/API/User.ashx?func=mobileAutoLoginWeb',
    );
    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data;
      }
    }
    return null;
  },
);
export const downloadFilesAction = createAsyncThunk(
  'dashboard/downloadFilesAction',
  async (payload) => {
    const data = JSON.stringify({ payload });
    const res = await get(`/psd/api/download.ashx?func=download&tbl=documentattachfiles&data=%5B%7B%22Title%22:%22VNA_ASP_06_39192fdba1_1679_44fb_8879_628dd573f330%22,%22Url%22:%22/record23/psd/Doc10/A144/VNA-ASP-06-39192fdba1-1679-44fb-8879-628dd573f330daa3ef9c-6516-423f-8251-5a9722627e07.pdf%22,%22ID%22:190%7D%5D&code=VNA_ASP_06_39192fdba1_1679_44fb_8879_628dd573f330&isarchive=&byurl=1&MetaObj=%7B%22Title%22:%22VB%20test%2004_10%22,%22ResourceCategoryId%22:%221%22,%22ResourceSubCategoryId%22:%222%22,%22ResourceUrl%22:%22/vi/van-ban-chat-luong/chinh-sach-2/vb-test-0410-844.html%22,%22PostTime%22:%222023-10-04%2000:00:00%22,%22ResourceId%22:%22844%22,%22IP%22:%22%22,%22DeviceName%22:%22Mobile%22,%22AppName%22:%22Chrome%22,%22Platform%22:%22iPhone%22,%22CodeName%22:%22Mozilla%22,%22UserAgent%22:%22Mozilla/5.0%20(iPhone;%20CPU%20iPhone%20OS%2016_4%20like%20Mac%20OS%20X)%20AppleWebKit/605.1.15%20(KHTML,%20like%20Gecko)%20Mobile/15E148%22,%22FlgUpdateData%22:1%7D&ispilot=0`);

    if (!isNullOrUndefined(res)) {
      if (res.status === 200) {
        console.log('resresresdownloadFilesAction', res);
        return res.data;
      }
    }
    return null;
  },
);
export const getHtmlString = createAsyncThunk(
  'dashboard/getHtmlString',
  async () => {
    const data = {};
    const res = await get('/psd/en/van-ban-chat-luong/mang-nghiep-vu-2048/hop-dong-mua-sam-64.html');
    console.log('htmlStringhtmlString', res);

    if (!isNullOrUndefined(res)) {
      if (res.status === 200) {
        return res.data;
      }
    }
    return "";
  },
);

const dashBoardSlice = createSlice({
  name: 'dashboard',
  initialState: {
    notificationCount: 0,
    documentNewList: [],
    documentMostViewList: [],
    documentFavoriteList: [],
    recentlyViewedDocs: [],
    documentDownloadedList: [],
    isLoading: false,
    autoId: null,
    isShowBottomSheet: false,
    isShowBottomSheetAccount: false,
    htmlString: ''
  },
  reducers: {
    syncFormDashboardAction(state, action) {

      return {
        ...state,
        documentNewList: action.payload.documentNewList ? action.payload.documentNewList : state.documentNewList,
        notificationCount: action.payload.notificationCount ? action.payload.notificationCount : state.notificationCount,
        recentlyViewedDocs: action.payload.recentlyViewedDocs ? action.payload.recentlyViewedDocs : state.recentlyViewedDocs,
        documentMostViewList: action.payload.documentMostViewList ? action.payload.documentMostViewList : state.documentMostViewList,
        documentFavoriteList: action.payload.documentFavoriteList,
        documentDownloadedList: action.payload.documentDownloadedList ? action.payload.documentDownloadedList : state.documentDownloadedList,
      };
    },
    setRecentlyViewedDocsAction(state, action) {
      return {
        ...state,
        recentlyViewedDocs: action.payload
      }
    },
    setDocumentsDownloadedListAction(state, action) {
      return {
        ...state,
        documentDownloadedList: action.payload
      }
    },
    setIsShowBottomSheetAction(state, action) {
      return {
        ...state,
        isShowBottomSheet: action.payload
      }
    },
    setIsShowBottomSheetAccountAction(state, action) {
      return {
        ...state,
        isShowBottomSheetAccount: action.payload
      }
    },
  },
  extraReducers: builder => {
    builder.
      addCase(getUnReadNotify.fulfilled, (state: any, action) => {
        state.notificationCount = action.payload;
      })
      .addCase(getViewDocumentNew.fulfilled, (state: any, action) => {
        state.documentNewList = action.payload;
      })
      .addCase(getDocumentFavorite.fulfilled, (state: any, action) => {
        state.documentFavoriteList = action.payload;
      })
      .addCase(getDocumentMostView.fulfilled, (state: any, action) => {
        state.documentMostViewList = action.payload;
      })
      .addCase(getAutoLoginMobile.fulfilled, (state: any, action) => {
        state.autoId = action.payload;
      })
      .addCase(getHtmlString.fulfilled, (state: any, action) => {
        state.htmlString = action.payload;
      })
      .addCase(downloadFilesAction.fulfilled, (state: any, action) => {
        state.htmlString = action.payload;
      });
  }
});
export const { setDocumentsDownloadedListAction, syncFormDashboardAction, setRecentlyViewedDocsAction, setIsShowBottomSheetAccountAction, setIsShowBottomSheetAction } = dashBoardSlice.actions;

const { reducer } = dashBoardSlice;
export default reducer;
