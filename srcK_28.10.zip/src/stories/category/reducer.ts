import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { RESONSE_STATUS_SUCCESS } from 'helpers/Constants';
import { isNullOrUndefined } from 'helpers/Functions';
import { get, post } from '../../services/ApiServices';

export const getlistCategoryDocs = createAsyncThunk(
    'category/getlistCategoryDocs',
    async ({ langId, Offset }: any) => {
        const res = await get(
            `/psd/API/ApiMobile.ashx?func=GetDocumentAreaCategory&LangId=${langId}&Params=LangId%2COffset%2CLimit&Offset=${Offset}&Limit=20`,
        );
        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return {
                    data: res.data.data,
                    Offset
                };
            }
        }
    },
);

export const getListDocumentCategory = createAsyncThunk(
    'category/getListDocumentCategory',
    async ({ LangId, Offset, data }: any) => {
        const body = {
            "Parameters": data
        }
        const res = await post(
            `/psd/api/ApiMobile.ashx?func=SelectByArea&Params=LangId,Offset,Limit&LangId=${LangId}&Limit=20&Offset=${Offset}`, body);
        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return {
                    data: res.data.data.Data,
                    Offset
                }
            }
        }
    },
);
const listCategorySlice = createSlice({
    name: 'category',
    initialState: {
        listCategoryDocs: {
            data: [],
            isLoading: false,
            totalRecord: 0
        },
        listDocumentCategory: {
            data: [],
            isLoading: false,
            totalRecord: 0
        },
        positionStayCategory: []
    },
    reducers: {
        resetListCategoryAction(state, action) {
            return {
                ...state,
                listCategoryDocs: {
                    data: [],
                    isLoading: false,
                    totalRecord: 0
                }
            };
        },
        resetDocumentCategoryAction(state, action) {
            return {
                ...state,
                listDocumentCategory: {
                    data: [],
                    isLoading: false,
                    totalRecord: 0
                }
            };
        },
        addPositionStayCategory: (state, action) => {
            // @ts-ignore
            state.positionStayCategory.push(action.payload);
        },
        removeLastPositionStayCategory: (state) => {
            state.positionStayCategory.pop();
        },
        removeAllPositionStayCategory: (state) => {
            state.positionStayCategory = []
        }
    },
    extraReducers: builder => {
        builder.
            addCase(getlistCategoryDocs.pending, (state: any, action: any) => {
                state.listCategoryDocs.isLoading = true
            }).
            addCase(getlistCategoryDocs.fulfilled, (state: any, action: any) => {
                const { Offset } = action.payload
                state.listCategoryDocs = {
                    data: Offset === 0 ? action.payload.data : state.listCategoryDocs.data.concat(action.payload.data),
                    totalRecord: action.payload.totalRecord,
                    isLoading: false,
                }
            }).
            addCase(getlistCategoryDocs.rejected, (state: any, action: any) => {
                state.listCategoryDocs.isLoading = false
            }).
            addCase(getListDocumentCategory.pending, (state: any, action: any) => {
                state.listDocumentCategory.isLoading = true
            }).
            addCase(getListDocumentCategory.fulfilled, (state: any, action: any) => {
                const { Offset } = action.payload
                state.listDocumentCategory = {
                    data: Offset === 0 ? action.payload.data : state.listDocumentCategory.data.concat(action.payload.data),
                    totalRecord: action.payload.totalRecord,
                    isLoading: false,
                }
            }).
            addCase(getListDocumentCategory.rejected, (state: any, action: any) => {
                state.listDocumentCategory.isLoading = false
            })
    }
});
export const { resetListCategoryAction, resetDocumentCategoryAction, addPositionStayCategory, removeLastPositionStayCategory, removeAllPositionStayCategory } = listCategorySlice.actions;
const { reducer } = listCategorySlice;
export default reducer;
