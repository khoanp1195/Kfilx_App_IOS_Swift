import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { RESONSE_STATUS_SUCCESS } from 'helpers/Constants';
import { isNullOrUndefined } from 'helpers/Functions';
import { get } from '../../services/ApiServices';

export const getnotificationList = createAsyncThunk(
    'notifications/getnotificationList',
    async (Offset) => {
        const res = await get(
            `/psd/API/ApiMobile.ashx?func=GetTopNotify&Params=Offset,Limit&Offset=${Offset}&Limit=20`,
        );

        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return {
                    data: res.data.data.Data,
                    totalRecord: res.data.data.MoreInfo[0].totalRecord,
                    Offset
                };
            }
        } else {
            return {
                data: [],
                totalRecord: 0,
                Offset
            };
        }
    },
);
export const getUnreadNotificationList = createAsyncThunk(
    'notifications/getUnreadNotificationList',
    async (Offset) => {
        const res = await get(
            `/psd/API/ApiMobile.ashx?func=GetUnReadNotify&Params=Offset,Limit,isCount&Offset=${Offset}&Limit=20&isCount=0`,
        );
        console.log('getUnreadNotificationList', res);

        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return {
                    data: res.data.data.Data,
                    totalRecord: res.data.data.MoreInfo[0].totalRecord,
                    Offset
                };
            }
        } else {
            return {
                data: [],
                totalRecord: 0,
                Offset
            };
        }
    },
);
const notificationsSlice = createSlice({
    name: 'notifications',
    initialState: {
        notificationList: {
            data: [],
            isLoading: false,
            totalRecord: 0
        },
        unreadNotificationList: {
            data: [],
            isLoading: false,
            totalRecord: 0
        }
    },
    reducers: {
        resetnotificationsAction(state, action) {
            return {
                ...state,
                notificationList: {
                    data: [],
                    isLoading: false,
                    totalRecord: 0
                },
                unreadNotificationList: {
                    data: [],
                    isLoading: false,
                    totalRecord: 0
                }
            };
        },
    },
    extraReducers: builder => {
        builder.
            addCase(getnotificationList.pending, (state: any, action: any) => {
                state.notificationList.isLoading = true
            }).
            addCase(getnotificationList.fulfilled, (state: any, action: any) => {
                const { Offset } = action.payload
                state.notificationList = {
                    data: Offset === 0 ? action.payload.data : state.notificationList.data.concat(action.payload.data),
                    totalRecord: action.payload.totalRecord,
                    isLoading: false,
                }
            }).
            addCase(getnotificationList.rejected, (state: any, action: any) => {
                state.notificationList.isLoading = false
            }).
            addCase(getUnreadNotificationList.pending, (state: any, action: any) => {
                state.unreadNotificationList.isLoading = true
            }).
            addCase(getUnreadNotificationList.fulfilled, (state: any, action: any) => {
                const { Offset } = action.payload
                state.unreadNotificationList = {
                    data: Offset === 0 ? action.payload.data : state.unreadNotificationList.data.concat(action.payload.data),
                    totalRecord: action.payload.totalRecord,
                    isLoading: false,
                }
            }).
            addCase(getUnreadNotificationList.rejected, (state: any, action: any) => {
                state.unreadNotificationList.isLoading = false
            })
    }
});
export const { resetnotificationsAction } = notificationsSlice.actions;
const { reducer } = notificationsSlice;
export default reducer;
