import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { RESONSE_STATUS_SUCCESS } from 'helpers/Constants';
import { isNullOrUndefined } from 'helpers/Functions';
import { get } from '../../services/ApiServices';

export const getlistcommentDocs = createAsyncThunk(
    'listcomment/getlistcommentDocs',
    async ({ langId, Offset }: any) => {
        const res = await get(
            `/psd/API/ApiMobile.ashx?func=GetCommentByUser&LangId=${langId}&Params=LangId%2COffset%2CLimit&Offset=${Offset}&Limit=20`,
        );
        console.log('ressssss', res.data);

        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return {
                    data: res.data.data.Data,
                    totalRecord: res.data.data.MoreInfo[0].totalRecord,
                    Offset
                };
            }
        } else {
            return {
                data: [],
                totalRecord: 0,
                Offset
            };
        }
    },
);
const listcommentSlice = createSlice({
    name: 'listcomment',
    initialState: {
        listcommentDocs: {
            data: [],
            isLoading: false,
            totalRecord: 0
        }
    },
    reducers: {
        resetlistcommentAction(state, action) {
            return {
                ...state,
                listcommentDocs: {
                    data: [],
                    isLoading: false,
                    totalRecord: 0
                }
            };
        },
    },
    extraReducers: builder => {
        builder.
            addCase(getlistcommentDocs.pending, (state: any, action: any) => {
                state.listcommentDocs.isLoading = true
            }).
            addCase(getlistcommentDocs.fulfilled, (state: any, action: any) => {
                const { Offset } = action.payload
                state.listcommentDocs = {
                    data: Offset === 0 ? action.payload.data : state.listcommentDocs.data.concat(action.payload.data),
                    totalRecord: action.payload.totalRecord,
                    isLoading: false,
                }
            }).
            addCase(getlistcommentDocs.rejected, (state: any, action: any) => {
                state.listcommentDocs.isLoading = false
            })
    }
});
export const { resetlistcommentAction } = listcommentSlice.actions;
const { reducer } = listcommentSlice;
export default reducer;
