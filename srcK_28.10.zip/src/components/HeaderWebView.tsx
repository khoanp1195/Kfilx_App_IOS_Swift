import { DrawViewIcon, NineBoxIcon, NotificationIcon, SnareIcon } from 'assets/svg';
import React from 'react';
import { StyleSheet, View, TouchableOpacity } from 'react-native';
import { FontSize, dimensWidth, } from 'helpers/Constants';
import TextCusTom from './TextCusTom';
import colors from 'helpers/Colors';
import { useSelector } from 'react-redux';
import { RootState } from 'stories/index';
import { checkIsEmpty } from 'helpers/Functions';

const HeaderWebView: any = ({ children,onPressAvatar = () =>{}, urlOnline,isLeft = true, notificationCount = '0', title,isSnare,onNnareChange, isRight = true,...props }: any) => {
    const {languages,languagesText } = useSelector((state: RootState) => state.languages);

    return (
        <View style={styles.container}>
            {
                isLeft &&  <TouchableOpacity onPress={onPressAvatar}>
                <DrawViewIcon />
                </TouchableOpacity>
            }
           
            <TextCusTom allowFontScaling={false} {...props} i18nKey={!checkIsEmpty(title) ? title : languages.document_type} style={styles.textTitle} numberOfLines={2}/>
           {isRight &&  
           <>
           <TouchableOpacity style={styles.viewRight} onPress={onNnareChange}>
                {isSnare ? <SnareIcon /> : <NineBoxIcon />}
            </TouchableOpacity>
           </>
            }
        </View>
    );
};
const styles = StyleSheet.create({
    container: { flexDirection: 'row', alignItems: 'center', height: 55, backgroundColor: colors.DarkCyan, paddingHorizontal: 15 },
    textTitle: { fontSize: FontSize.LARGE_X, fontWeight: '700', color: colors.white, marginLeft: 15, lineHeight: dimensWidth(22) },
    viewRight: { flex: 1, alignItems: 'flex-end' },
    viewNotification: { backgroundColor: colors.red, height: 20, width: 20, borderRadius: 10, position: 'absolute', right: -7, top: -5, justifyContent: 'center', alignItems: 'center' },
    textNotification: { color: colors.white, fontSize: 12, }
});
export default React.memo(HeaderWebView);
