import { NotificationIcon } from 'assets/svg';
import React, { useCallback } from 'react';
import { StyleSheet, View, TouchableOpacity } from 'react-native';
import FastImageCustom from './FastImageCustom';
import { FontSize, dimensWidth, } from 'helpers/Constants';
import TextCusTom from './TextCusTom';
import colors from 'helpers/Colors';
import { useNavigation } from '@react-navigation/native';

const HeaderWithAvatar: any = ({dataCurrentUsers, children,onPressAvatar = () =>{}, urlOnline, notificationCount = '0', title, ...props }: any) => {
   const isDisplayNotification = notificationCount !== '0';
    const navigation : any = useNavigation();
   const gotoNotificaitonsScreen = useCallback(
    () => {
        navigation.navigate({
            name: "NotificationsScreen",
          });
    },
    [],
  )
  
   return (
        <View style={styles.container}>
            <TouchableOpacity onPress={onPressAvatar}>
            <FastImageCustom urlOnline={dataCurrentUsers[0]?.ImagePath} />
            </TouchableOpacity>
            <TextCusTom allowFontScaling={false} {...props} i18nKey={title} style={styles.textTitle} />
            <View style={styles.viewRight}>

                <TouchableOpacity onPress={gotoNotificaitonsScreen}>
                    <NotificationIcon />
                   { isDisplayNotification &&
                     <View style={styles.viewNotification}>
                     <TextCusTom i18nKey={notificationCount} style={styles.textNotification} />
                 </View>
                   }
                </TouchableOpacity>
            </View>
        </View>
    );
};
const styles = StyleSheet.create({
    container: { flexDirection: 'row', alignItems: 'center', padding: 20, backgroundColor: colors.white },
    textTitle: { fontSize: FontSize.LARGE_X, fontWeight: '700', color: colors.DarkCyan, lineHeight: dimensWidth(22) },
    viewRight: { flex: 1, alignItems: 'flex-end' },
    viewNotification: { backgroundColor: colors.red, height: 20, width: 20, borderRadius: 10, position: 'absolute', right: -7, top: -5, justifyContent: 'center', alignItems: 'center' },
    textNotification: { color: colors.white, fontSize: 12, }
});
export default React.memo(HeaderWithAvatar);
