import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { setConnectionStatus } from 'stories/netinfo/reducer';
import NetInfo from "@react-native-community/netinfo";

const NetInfoListener = () => {
    const dispatch = useDispatch();

    useEffect(() => {
        const unsubscribe = NetInfo.addEventListener((state) => {
            dispatch(setConnectionStatus(state.isConnected));
        });

        return () => {
            unsubscribe();
        };
    }, [dispatch]);

    return null;
}

export default NetInfoListener;
