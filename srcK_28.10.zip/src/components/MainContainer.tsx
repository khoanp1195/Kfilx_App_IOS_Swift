import { BackIcon, NotificationIcon } from 'assets/svg';
import React, { FC } from 'react';
import { ImageBackground, StyleSheet, Text, View } from 'react-native';
import FastImageCustom from './FastImageCustom';
import { FontSize, dimensWidth, dimnensHeight } from 'helpers/Constants';
import TextCusTom from './TextCusTom';
import colors from 'helpers/Colors';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { useNavigation } from '@react-navigation/native';

const MainContainer: any = ({ children,isShowLeftButton = true,BackPressCustom, urlOnline, notificationCount = '0', title, ...props }: any) => {
    const navigation = useNavigation()
    const backPress = () =>{
        if(BackPressCustom){
            BackPressCustom()
        }else{
            navigation.goBack()
        }
    }
    return (
   <View style={{flex: 1}}>
      {isShowLeftButton && 
         <View style={styles.container}>
          <TouchableOpacity style={styles.backButton} onPress={backPress}>
        <BackIcon />
            </TouchableOpacity>
      
            <TextCusTom allowFontScaling={false} {...props} i18nKey={title} style={styles.textTitle} />
            <View style={styles.viewRight} />
        </View>
              }
            <ImageBackground source={require('../assets/images/background.png')} style={styles.bg_login}>
            {children}
            </ImageBackground>
   </View>
    );
};
const styles = StyleSheet.create({
    container: {flexDirection: 'row', alignItems: 'center', padding: 20, backgroundColor: colors.white },
    bg_login: {
        flex: 1,
        backgroundColor: '#fff',
      },
    backButton:{
    height: 30,
    width: 30,
    borderRadius:15,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.bg_app_color,    
    },
    textTitle: { fontSize: FontSize.LARGE_X, fontWeight: '700', color: colors.DarkCyan, marginLeft: 15, lineHeight: dimnensHeight(22) },
    viewRight: { flex: 1, alignItems: 'flex-end' },
});
export default React.memo(MainContainer);
