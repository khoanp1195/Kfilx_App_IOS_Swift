import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { View, StyleSheet } from 'react-native';
import BottomSheet, { TouchableOpacity } from '@gorhom/bottom-sheet';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from 'stories/index';
import {setIsShowBottomSheetAccountAction, syncFormDashboardAction } from 'stories/dashboard/reducer';
import TextCusTom from './TextCusTom';
import { DEFAULT_LANGUAGE_TEXT, FontFamily, FontSize } from 'helpers/Constants';
import colors from 'helpers/Colors';
import { BackIcon, CommentIcon, InteractiveIcon, LanguageIcon, LogoutRedIcon, OfflineIcon, RightIcon, SettingIcon, VersionIcon } from 'assets/svg';
import { setLanguagesAction } from 'stories/languages/reducer';
import FastImageCustom from './FastImageCustom';
import { logoutAction } from 'stories/login/reducer';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { database } from '../../App';
import { TABLE } from 'database/contains';
import { useNavigation } from '@react-navigation/native';
import DeviceInfo from 'react-native-device-info';
import { isNullOrUndefined } from 'helpers/Functions';

const BottomSheetCustom = ({navigation}: any) => {
    const {isShowBottomSheetAccount} = useSelector((state: RootState) => state.dashboard);
    const {languages,languagesText } = useSelector((state: RootState) => state.languages);
    const {dataCurrentUsers} = useSelector((state: RootState) => state.login);

    const [versionApp, setVersionApp] = useState('1.0')
    const dispatch = useDispatch<any>();
  // ref
  const bottomSheetRef = useRef<BottomSheet>(null);
  // variables
  const snapPoints = useMemo(() => ['1%', '98%'], []);
useEffect(() => {
  let version = DeviceInfo.getVersion();
  if(!isNullOrUndefined(version)) setVersionApp(version);
}, [])

  // callbacks
  const handleSheetChanges = useCallback((index: number) => {
    if(index === 0) dispatch(setIsShowBottomSheetAccountAction(false));
  }, []);
  const onCloseBottomSheet = useCallback(
    () => {
        dispatch(setIsShowBottomSheetAccountAction(false))
    },
    [],
  )
  const isLangueEn = useMemo(() => languagesText === DEFAULT_LANGUAGE_TEXT.ENGLISH, [languagesText])
  const isLangueVi = useMemo(() => languagesText === DEFAULT_LANGUAGE_TEXT.VIETNAM, [languagesText])

    const onNavigateInteractiveScreen = useCallback(
      () => {
        navigation.navigate("InteractiveDocsScreen", {});
      },
      [],
    )
    
    const onNavigateListcommentScreen = useCallback(
      () => {
        navigation.navigate("ListcommentScreen", {});
      },
      [],
    )
 
  const CardMargin = ()  =>{
    return <View style={styles.cardMargin}/>
  }
  const ItemComponent = ({title = '',content,onPress = () =>{},IconView = null, isLastItem = false,textRight}: any)  => {
    return   (
        <TouchableOpacity  style={[styles.itemChildContainer,isLastItem && {borderBottomWidth: 0}]} onPress={()=>{
          dispatch(setIsShowBottomSheetAccountAction(false));
          onPress();
        }} >
    <TextCusTom i18nKey={title} style={styles.itemTitle}/>
    <TextCusTom i18nKey={content} style={styles.textRight}/>
    </TouchableOpacity>
    )
    
  }
  // renders
  if(!isShowBottomSheetAccount) return null
  return (
      <View style={styles.container}>
      <BottomSheet
        ref={bottomSheetRef}
        index={1}
        snapPoints={snapPoints}
        onChange={handleSheetChanges}
      >
        {/* card */}
      <View style={styles.contentContainer}>
      <View style={styles.flexDirectionRowBetween}>

            <TouchableOpacity style={{flexDirection: 'row'}} onPress={onCloseBottomSheet}>
            <BackIcon />
            <TextCusTom i18nKey={languages.account} style={styles.textBack}/>
            </TouchableOpacity>
           <TouchableOpacity onPress={onCloseBottomSheet}>
           <TextCusTom i18nKey={languages.close} style={styles.textClose}/>
           </TouchableOpacity>
        </View>
        <TextCusTom i18nKey={languages.profile} style={styles.textTitle}/>
        <View>
          <View style={styles.line}/>
        <CardMargin />

      <View style={styles.itemContainer}>
      <View  style={{flexDirection: 'row', padding: 10, }}>
        
      <TouchableOpacity onPress={() =>{}}>
            <FastImageCustom styleImg={{marginLeft: 10}}urlOnline={dataCurrentUsers[0]?.ImagePath} />
            </TouchableOpacity>
           <View>
           <TextCusTom allowFontScaling={false} i18nKey={dataCurrentUsers[0]?.FullName} style={styles.textUserName} />   
           <TextCusTom allowFontScaling={false} i18nKey={dataCurrentUsers[0]?.Email} style={styles.textEmail} />   
           </View>
      </View>
   
      </View>

      <CardMargin />
      <View  style={styles.itemContainer} >
      <ItemComponent title={languages.email}  content={'vananhtn@vietnamairlines.com'} onPress={onNavigateInteractiveScreen} />
      <ItemComponent title={languages.phone} content={'090 6708 696'} onPress={onNavigateListcommentScreen} />
      <ItemComponent title={languages.position} content={'Nhân viên kinh doanh'} isLastItem={true}/>
      </View>
        </View>
      </View>
      </BottomSheet> 
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
    marginBottom: -20,
    zIndex: 99,
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  cardMargin: {height:30, backgroundColor: colors.light_grayish,  },
  line: {height:1,width:'100%', backgroundColor: colors.grey_co,marginTop: 20  },
  contentContainer: {
    flex: 1,
    backgroundColor: colors.light_grayish,
    paddingHorizontal: 15
  },
  flexDirectionRow: {
    flexDirection: 'row',
    justifyContent: 'center'
  },
  itemChildContainer: {
    paddingLeft: 10,
    paddingTop: 10,
    height: 80,
    borderBottomColor: colors.grey_co,
    borderBottomWidth: 1,
     marginLeft: 10,
     paddingRight: 10,
     paddingBottom: 10
  },
  itemContainer:{
    borderRadius:5,
    backgroundColor: colors.white
  },
  flexDirectionRowBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 10,
    paddingTop: 10,
  },
  flexDirectionRowChildeBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    flex: 1,
    borderBottomColor: colors.grey_co,
    borderBottomWidth: 1,
     marginLeft: 10,
     paddingRight: 10,
     paddingBottom: 10
  },
  textTitle:{
    fontSize: FontSize.LARGE,
    color: colors.black,
    fontWeight: '700',
    fontFamily: FontFamily.HERITAGE_BOLD,
    paddingLeft: 10
  },
  textClose:{
    fontSize: FontSize.SMALL,
    color: colors.black,
    fontWeight: '400',
    fontFamily: FontFamily.HERITAGE_REGULAR,
  },
  textBack:{
    fontSize: FontSize.SMALL,
    color: colors.black,
    fontWeight: '400',
    fontFamily: FontFamily.HERITAGE_REGULAR,
    marginLeft: 10,
    marginTop: 10
  },
  itemTitle:{
    fontSize: FontSize.SMALL,
    color: colors.text_grey26,
    fontWeight: '400',
    fontFamily: FontFamily.HERITAGE_REGULAR,
  },
  textRight:{
    fontSize: FontSize.SMALL,
    color: colors.text_grey26,
    fontWeight: '400',
    fontFamily: FontFamily.HERITAGE_REGULAR,
  },

  itemContainerServiceClient:{
    backgroundColor: colors.white,
    borderRadius: 5,
    borderWidth:1,
    borderColor: colors.DarkCyan,
    marginHorizontal: 10,
    marginVertical: 5,  
    overflow: 'hidden'
  },
  viewLanguege: {
    flexDirection: 'row',
    justifyContent: 'center',
    borderRadius:1,
    borderWidth: 0.5,
    borderColor: colors.DarkCyan,
    height: 22,
    width: 80,
    alignItems: 'center',
    padding: 2,
  },
  textInactiveLanguege:{
    fontSize: FontSize.SMALL,
    color: colors.text_grey9E,
    fontWeight: '400',
    fontFamily: FontFamily.HERITAGE_REGULAR,
  },
  textActiveLanguege:{
    fontSize: FontSize.SMALL,
    color: colors.white,
    fontWeight: '400',
    fontFamily: FontFamily.HERITAGE_REGULAR,
  },
  viewInactiveLanguege:{
   width: 36,
   backgroundColor:colors.white,
   borderRadius: 1,
   justifyContent: 'center',
   alignItems: 'center',
  },
  viewActiveLanguege:{
    width: 36,
   backgroundColor:colors.orange,
   borderRadius: 1,
   justifyContent: 'center',
   alignItems: 'center',
  },
  textLogOut:{
    fontSize: FontSize.SMALL,
    color: colors.red,
    fontWeight: '400',
    fontFamily: FontFamily.HERITAGE_REGULAR,
  },
  textUserName:{
    flex: 1,
    marginLeft: 10,
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: '400',
    fontFamily: FontFamily.HERITAGE_BOLD,
  },
  textEmail:{
    flex: 1,
    marginLeft: 10,
    fontSize: FontSize.SMALL,
    color: colors.text_grey_7e,
    fontWeight: '400',
    fontFamily: FontFamily.HERITAGE_BOLD,
  },
});

export default BottomSheetCustom;