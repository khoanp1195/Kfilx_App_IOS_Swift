import colors from 'helpers/Colors';
import { FontFamily, FontSize, dimensWidth } from 'helpers/Constants';
import React, {FC} from 'react';
import {StyleSheet, Text} from 'react-native';
const TextCustom: any = ({children,i18nKey,style,...props}: any) => {

  return (
    <Text allowFontScaling={false} style={[styles.textStyles,style]} {...props} >
      {i18nKey}
      {children}
    </Text>
  );
};
const styles = StyleSheet.create({
  textStyles:{
    fontSize: FontSize.SMALL,
    color: colors.black,
    fontWeight: '400',
    fontFamily: FontFamily.HERITAGE_REGULAR,
    lineHeight: dimensWidth(16)
  }
})
export default React.memo(TextCustom);
