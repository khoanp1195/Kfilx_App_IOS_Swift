const colors = {
  white: '#ffffff',
  black: '#000000',
  orange: '#DBA410',
  red: '#FF0000',
  DarkCyan: '#006885',
  text_grey26: '#262626',
  text_grey9E: '#9E9E9E',
  text_grey_bc: '#BCBCBC',
  text_grey_7e: '#7E7E7E',
  text_grey_7b: '#7B7B7B',
  bottomtab_inactive_grey: '#C7D2DD',
  grey_co: '#C0C0C0',
  bg_app_color: 'rgba(0, 104, 133, 0.1)',
  light_grayish: '#F2F3F7',
  black_121: '#0C121D',
  black_7b: '#7B7B7B',
  white_blue: '#F1FAFF',
  blue: '#2376E0',
  green: '#D1FDCE',
  pink: '#FFCDCD',
  light_blue: '#D1E9FF',
  grey_da: '#DADADA',
  blue_switch_on: '#2190FF',
  light_cyan: '#E2F9FF',
  grey_4f: '#4F4F4F'
};

export default colors;
