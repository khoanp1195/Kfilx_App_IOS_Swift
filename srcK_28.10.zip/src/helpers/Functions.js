import moment from "moment";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { PermissionsAndroid, Platform } from "react-native";

export const removeSpecialCharacters = (str) => {
  if (!str) {
    return "";
  }
  if (str.includes(";#")) {
    const separator = ";#";
    return str.split(separator)[1];
  } else {
    return str;
  }
};

export const removeNumbersAndHashes = (str) => {
  if (!str) {
    return "";
  }
  // Remove numbers
  str = str.replace(/\d+/g, "");

  // Remove '#'
  str = str.replace(/#/g, "");

  // Remove extra semicolons
  str = str.replace(/;;/g, ";");

  // Remove leading and trailing semicolons
  str = str.replace(/(^;)|(;$)/g, "");

  return str;
};

export const format_dd_mm_yyyy_hh_mm = (date) => {
  if (isNullOrUndefined(date)) {
    return "";
  }
  return moment(date).format("DD/MM/YYYY HH:mm");
};
export const format_dd_mm_yy = (date) => {
  return date ? moment(date).format("DD/MM/YYYY") : "";
};
export const format_mm_dd_yy = (date) => {
  return moment(date).format("MM/DD/YYYY");
};
export const format_mm_dd_hh_yy_mm_ss = (date) => {
  return moment(date).format("MM/DD/YYYY HH:mm:ss");
};
export const format_yy_mm_mm_dd_hh = (date) => {
  return moment(date).format("HH:mm DD/MM/YYYY");
};
export const formatDate = (date, format) => {
  return moment(date).format(format);
};

export const format_yy_mm_dd = "YYYY-MM-DD";
export const arrayIsEmpty = (array) => {
  if (!Array.isArray(array)) {
    return true;
  }
  if (array.length === 0) {
    return true;
  }
  return false;
};
export const checkIsEmpty = (text) => {
  if (text?.length === 0 || text === undefined || text === null) {
    return true;
  }
  return false;
};
export function checkIsBefore(date1, date2) {
  return moment(date1).isBefore(date2);
}
export function checkIsAfter(date1, date2) {
  return moment(date1).isAfter(date2);
}

export function getExtension(filename) {
  var parts = filename.split(".");
  return parts[parts.length - 1];
}

export const splitID = (text) => {
  return text?.split(";")[0];
};

export const isNullOrUndefined = (data) => {
  return data === null || data === "" || data === undefined;
};

export const isNullOrEmpty = (text) => {
  return text === null || text === "";
};

export const checkNotNullAndEmpty = (text) => {
  if (text?.length !== 0 && text !== null) {
    return true;
  }
  return false;
};

export function byteConverter(bytes, decimals, only) {
  const K_UNIT = 1024;
  const SIZES = ["Bytes", "KB", "MB", "GB", "TB", "PB"];

  if (bytes == 0) {
    return "0 Byte";
  }

  if (only === "MB") {
    return (bytes / (K_UNIT * K_UNIT)).toFixed(decimals) + " MB";
  }

  let i = Math.floor(Math.log(bytes) / Math.log(K_UNIT));
  let resp =
    parseFloat((bytes / Math.pow(K_UNIT, i)).toFixed(decimals)) +
    " " +
    SIZES[i];

  return resp;
}

export const VersionCompare = (version1, version2) => {
  var regExStrip0 = /(\.0+)+$/;
  var segmentsA = version1.replace(regExStrip0, "").split(".");
  var segmentsB = version2.replace(regExStrip0, "").split(".");

  if (segmentsA > segmentsB) {
    return 1;
  } else if (segmentsA < segmentsB) {
    return -1;
  } else {
    return 0;
  }
};
export const setTimeSyncForm = async (date: any) => {
  return AsyncStorage.setItem("timeSyncForm", JSON.stringify(date));
};

export const getTimeSyncForm = async () => {
  try {
    const result = await AsyncStorage.getItem("timeSyncForm");
    return JSON.parse(result);
  } catch (err) {
    return null;
  }
};
export const checkMimeTypeFiles = (filename) => {
  var ext = getExtension(filename);
  switch (ext.toLowerCase()) {
    case "doc":
      return "application/msword";
    case "dot":
      return "application/msword";
    case "docx":
      return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
    case "dotx":
      return "application/vnd.openxmlformats-officedocument.wordprocessingml.template";
    case "docm":
      return "application/vnd.ms-word.document.macroEnabled.12";
    case "dotm":
      return "application/vnd.ms-word.template.macroEnabled.12";
    case "xls":
      return "application/vnd.ms-excel";
    case "xlt":
      return "application/vnd.ms-excel";
    case "xla":
      return "application/vnd.ms-excel";
    case "xlsx":
      return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    case "xltx":
      return "application/vnd.openxmlformats-officedocument.spreadsheetml.template";
    case "xlsm":
      return "application/vnd.ms-excel.sheet.macroEnabled.12";
    case "xltm":
      return "application/vnd.ms-excel.template.macroEnabled.12";
    case "xlam":
      return "application/vnd.ms-excel.addin.macroEnabled.12";
    case "xlsb":
      return "application/vnd.ms-excel.sheet.binary.macroEnabled.12";
    case "ppt":
      return "application/vnd.ms-powerpoint";
    case "pot":
      return "application/vnd.ms-powerpoint";
    case "pps":
      return "application/vnd.ms-powerpoint";
    case "ppa":
      return "application/vnd.ms-powerpoint";
    case "pptx":
      return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
    case "potx":
      return "application/vnd.openxmlformats-officedocument.presentationml.template";
    case "ppsx":
      return "application/vnd.openxmlformats-officedocument.presentationml.slideshow";
    case "ppam":
      return "application/vnd.ms-powerpoint.addin.macroEnabled.12";
    case "pptm":
      return "application/vnd.ms-powerpoint.presentation.macroEnabled.12";
    case "potm":
      return "application/vnd.ms-powerpoint.template.macroEnabled.12";
    case "ppsm":
      return "application/vnd.ms-powerpoint.slideshow.macroEnabled.12";
    case "mdb":
      return "application/vnd.ms-access";
  }
  return null;
};
export const formatTimeAgo = (specificTime, langId) => {
  const currentTime = moment();
  const specifiedTime = moment(specificTime);
  const diffInHours = currentTime.diff(specifiedTime, "hours");
  const diffInDays = currentTime.diff(specifiedTime, "days");

  const is1Hours = diffInHours === 1 ? "hour ago" : "hours ago";
  const diffHoursText = langId === "EN" ? is1Hours : "giờ trước";
  const diffDaysText = langId === "EN" ? "1 day ago" : "1 ngày trước";

  if (diffInDays < 1) {
    return `${diffInHours} ${diffHoursText}`;
  } else if (diffInDays < 2) {
    return `${diffDaysText}`;
  } else {
    return specifiedTime.format("HH:mm DD/MM/YYYY");
  }
};
export const getCurrentTimeFormatted = () => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0"); // Add 1 to month since it's 0-based
  const day = String(now.getDate()).padStart(2, "0");
  const hours = String(now.getHours()).padStart(2, "0");
  const minutes = String(now.getMinutes()).padStart(2, "0");
  const seconds = String(now.getSeconds()).padStart(2, "0");

  return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
};
export const splitDocumentIdFromUrl = (url) => {
  var regex = /\d{3}(?=\D*$)/;
  let DocumentId = "";
  DocumentId = url.match(regex);
  if (DocumentId) {
    var value = DocumentId[0];
    console.log(value); // Kết quả: "708"
  } else {
    console.log("Không tìm thấy 3 số cuối cùng.");
  }
  return DocumentId;
};
export const checkAndRequestStoragePermissions = async () => {
  if (Platform.OS == "ios") {
    // Gọi hàm để kiểm tra và yêu cầu quyền trước khi thực hiện tác vụ liên quan đến lưu trữ
    return true;
  }
  // Kiểm tra xem quyền READ_EXTERNAL_STORAGE đã được cấp chưa
  const readStorageGranted = await PermissionsAndroid.check(
    PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE
  );

  // Kiểm tra xem quyền WRITE_EXTERNAL_STORAGE đã được cấp chưa
  const writeStorageGranted = await PermissionsAndroid.check(
    PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE
  );

  if (!readStorageGranted || !writeStorageGranted) {
    // Nếu một hoặc cả hai quyền chưa được cấp, thì yêu cầu chúng từ người dùng
    try {
      const granted = await PermissionsAndroid.requestMultiple([
        PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE,
        PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
      ]);

      if (
        granted[PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE] ===
          PermissionsAndroid.RESULTS.GRANTED &&
        granted[PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE] ===
          PermissionsAndroid.RESULTS.GRANTED
      ) {
        console.log("Quyền truy cập lưu trữ đã được cấp.");
        return true;
        // Gọi hàm để thực hiện tác vụ liên quan đến lưu trữ ở đây
      } else {
        console.log("Không cấp quyền truy cập lưu trữ.");
        return false;
      }
    } catch (err) {
      console.warn(err);
      return false;
    }
  } else {
    console.log("Ứng dụng đã có quyền truy cập lưu trữ.");
    return true;
    // Gọi hàm để thực hiện tác vụ liên quan đến lưu trữ ở đây
  }
};
