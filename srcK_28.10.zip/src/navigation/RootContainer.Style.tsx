import {StyleSheet, StatusBar, Platform} from 'react-native';
import {dimensWidth} from 'helpers/Constants';
import colors from 'helpers/Colors';
const STATUSBAR_HEIGHT = StatusBar.currentHeight;
const APPBAR_HEIGHT = Platform.OS === 'ios' ? 44 : 56;

export default StyleSheet.create({
  mainContainer: {
    flex: 1,
    backgroundColor: colors.white
  },
  viewNetworkErr: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  btnRetry: {
    width: 150,
    height: 40,
    backgroundColor: 'white',
    borderRadius: 4,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textRetry: {
    color: 'black',
    fontWeight: 'bold',
  },
  tabBarIconView: {
    height: dimensWidth(32),
    width: dimensWidth(32),
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 6,
    marginBottom: dimensWidth(2),
  },
  tabBarLabelActive: {
    color: colors.orange,
    fontWeight: '700',
    fontSize: 12,
  },
  tabBarLabelInActive: {
    color: colors.white,
    fontWeight: '400',
    fontSize: 12,
  },
  viewTabBottomBar: {
    flexDirection: 'row',
    height: dimensWidth(72),
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.DarkCyan,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ECF0F1',
  },
  buttonsContainer: {
    padding: 10,
  },
  textStyle: {
    textAlign: 'center',
    marginBottom: 8,
  },
  statusBar: {
    height: STATUSBAR_HEIGHT,
  },
  appBar: {
    backgroundColor: '#79B45D',
    height: APPBAR_HEIGHT,
  },
  content: {
    flex: 1,
    backgroundColor: '#33373B',
  },
});
