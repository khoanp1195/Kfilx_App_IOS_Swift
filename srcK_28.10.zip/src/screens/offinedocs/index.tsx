import { WINDOW_WIDTH } from '@gorhom/bottom-sheet';
import { useFocusEffect } from '@react-navigation/native';
import Header from 'components/Header';
import TextCusTom from 'components/TextCusTom';
import colors from 'helpers/Colors';
import { FontFamily, FontSize } from 'helpers/Constants';
import React, { useCallback, useState } from 'react';
import { View, Switch, StyleSheet, FlatList } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from 'stories/index';
import { getConfigNotification } from 'stories/settings/reducer';

const SettingItem = ({ item, index, toggleSwitchNoti, toggleSwitchEmail }: any) => {
    const { title, id, isEnabledEmail, isEnabledNoti } = item;
    const isOdd = index % 2
    return (
        <View style={[styles.settingItem, { backgroundColor: isOdd ? colors.light_grayish : colors.white_blue }]}>
            <TextCusTom style={styles.itemTitle} i18nKey={title + title} numberOfLines={2} />
            <View style={styles.viewRight}>
                <View style={{ marginRight: 5, width: 70 }}>
                    <Switch
                        trackColor={{ false: colors.blue_switch_on, true: colors.blue_switch_on }}
                        thumbColor={colors.white}
                        onValueChange={() => toggleSwitchNoti(id)}
                        value={isEnabledNoti}
                    />
                </View>
                <View style={{ width: 70 }}>
                    <Switch
                        trackColor={{ false: colors.grey_da, true: colors.blue_switch_on }}
                        thumbColor={colors.white}
                        onValueChange={() => toggleSwitchEmail(id)}
                        value={isEnabledEmail}
                    />
                </View>
            </View>
        </View>
    )
};
const TopTab = ({activeTab,onChangeActiveStatus}: any) => {

    return (
        <View style={styles.headerContainer}>
            <TouchableOpacity style={[styles.tabView,activeTab === 1 && {backgroundColor:colors.white}]} onPress={() => onChangeActiveStatus(1)} >
            <TextCusTom i18nKey={'Notifications'} style={[styles.textHeader,activeTab === 1 && {color: colors.DarkCyan}]} />
            </TouchableOpacity>
            <TouchableOpacity style={[styles.tabView,activeTab === 2 && {backgroundColor:colors.white}]}onPress={() => onChangeActiveStatus(2)} >
            <TextCusTom i18nKey={'Email'} style={[styles.textHeader,activeTab === 2 && {color: colors.DarkCyan}]} />
            </TouchableOpacity>
        </View>
    )
};
const App = () => {
    const {languages,languagesText } = useSelector((state: RootState) => state.languages);
    const [setingData, setSetingData] = useState([]);
    const [activeStatus, setactiveStatus] = useState(1)
    const dispatch = useDispatch<any>();

    useFocusEffect(
        React.useCallback(() => {
          const langId = languagesText === 'EN' ? 1033 :1066
          dispatch(getConfigNotification(langId));
        }, [languagesText])
      );

    const toggleSwitchNoti = useCallback((id: string) => {
        const data = setingData.map(it => {
            const newIt = it.id === id ? { ...it, isEnabledNoti: !it.isEnabledNoti } : it
            return newIt
        })
        setSetingData(data);
    },
        [setingData],
    )
    const toggleSwitchEmail = useCallback((id: string) => {
        const data = setingData.map(it => {
            const newIt = it.id === id ? { ...it, isEnabledEmail: !it.isEnabledEmail } : it
            return newIt
        })
        setSetingData(data);
    }, [setingData],
    )
    const onChangeActiveStatus = useCallback(
      (status) => {
        setactiveStatus(status)
      },
      [activeStatus],
    )
    
    return (
        <View style={styles.container}>
            <Header title={languages.text_offline} />
            <TopTab activeTab={activeStatus} onChangeActiveStatus={onChangeActiveStatus}/>
            <FlatList
                data={[]}
                extraData={setingData}
                renderItem={({ item, index }) => (
                    <SettingItem
                        item={item} index={index}
                        toggleSwitchEmail={(id) => toggleSwitchEmail(id)}
                        toggleSwitchNoti={(id) => toggleSwitchNoti(id)} />
                )
                }

                keyExtractor={item => item.id}
            />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor: colors.white
    },
    settingItem: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        height: 70,
        paddingHorizontal: 15
    },
    viewLeft: {
    },
    viewRight: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    itemTitle: {
        flex: 1,
        color: colors.black_121,
        fontSize: FontSize.SMALL,
        fontWeight: '400',
        fontFamily: FontFamily.HERITAGE_REGULAR,
    },
    textHeader: {
        color: colors.black_121,
        fontSize: FontSize.SMALL,
        fontWeight: '400',
        fontFamily: FontFamily.HERITAGE_REGULAR,
        paddingTop: 5
    },
    headerContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent:'center',
        height: 40,
        backgroundColor: colors.light_grayish,
        marginVertical: 10,
        marginHorizontal: 15,
        borderRadius: 30,
    },
    tabView: {
        width: WINDOW_WIDTH /2 -20,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 30,
        margin: 2
    }
});

export default App;