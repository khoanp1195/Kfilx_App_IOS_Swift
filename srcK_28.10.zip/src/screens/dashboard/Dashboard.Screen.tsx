import {ImageBackground, SectionList, StyleSheet, Text, View} from 'react-native';
import React, { useCallback, useEffect, useState } from 'react';
import HeaderWithAvatar from 'components/HeaderWithAvatar';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from 'stories/index';
import TextCusTom from 'components/TextCusTom';
import colors from 'helpers/Colors';
import { FontSize, dimensWidth } from 'helpers/Constants';
import { getAutoLoginMobile, getDocumentFavorite, getDocumentMostView, getUnReadNotify, getViewDocumentNew, setIsShowBottomSheetAction, setRecentlyViewedDocsAction } from 'stories/dashboard/reducer';
import { ThunkDispatch } from 'redux-thunk';
import NoDataView from 'components/NoDataView';
import { arrayIsEmpty } from 'helpers/Functions';
import { FlatList, RefreshControl, ScrollView } from 'react-native-gesture-handler';
import DocumentViewItem from './components/DocumentViewItem';
import uuid from 'react-native-uuid';
import { useFocusEffect, useIsFocused } from '@react-navigation/native';
import { fetchCurrentUser } from 'stories/login/reducer';

type Props = {
  navigation: any;
  route: any;
};

const DashboardScreen = ({navigation}: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const isFocused = useIsFocused();
  const {languages,languagesText } = useSelector((state: RootState) => state.languages);
  const {dataCurrentUsers} = useSelector((state: RootState) => state.login);
  const {notificationCount, documentNewList,recentlyViewedDocs,documentMostViewList, documentFavoriteList, isShowBottomSheet } = useSelector((state: RootState) => state.dashboard);
  const [dataHome, setDataHome] = useState<any>([
    {data: [
      {title:languages.newest_docs, data: []
},
    {title:languages.recently_viewed_docs, data: []},
    {title:languages.most_favourite_docs, data: []},
    {title:languages.most_view_docs, data: []},
    ]}
  ]);
  const [refreshing, setRefreshing] = useState(false);
  
  useFocusEffect(
    React.useCallback(() => {
      // alert(1)
     const langId = languagesText === 'EN' ? 1033 :1066
     dispatch(fetchCurrentUser());
     dispatch(getViewDocumentNew(langId))
     dispatch(getDocumentFavorite(langId))
     dispatch(getDocumentMostView(langId))
     dispatch(getUnReadNotify())
    }, [languagesText])
  );
    // useEffect(() => {
    //      const langId = languagesText === 'EN' ? 1033 :1066
    //      dispatch(fetchCurrentUser());
    //      dispatch(getViewDocumentNew(langId))
    //      dispatch(getDocumentFavorite(langId))
    //      dispatch(getDocumentMostView(langId))
    //      dispatch(getUnReadNotify())
    // }, [languagesText])
    
  useEffect(() => {
    setDataHome([
      {data: [
        {title:languages.newest_docs, data: documentNewList
  },
      {title:languages.recently_viewed_docs, data: recentlyViewedDocs},
      {title:languages.most_favourite_docs, data: documentFavoriteList},
      {title:languages.most_view_docs, data: documentMostViewList},
      ]}
    ])

  }, [documentNewList,documentMostViewList,recentlyViewedDocs, documentFavoriteList])

  const onRefresh = useCallback(() => {
    const langId = languagesText === 'EN' ? 1033 :1066
    dispatch(fetchCurrentUser());
    dispatch(getViewDocumentNew(langId))
    dispatch(getDocumentFavorite(langId))
    dispatch(getDocumentMostView(langId))
    dispatch(getUnReadNotify())
  }, [languagesText]);
const gotoDetailPress = useCallback(
  (item: any) => {
    let newData: any = recentlyViewedDocs;
    const checkIsNotExistOrEmpty = (data: any) =>{
      if(arrayIsEmpty(data)) return true
      if(data.find((it: any) => it?.ID === item?.ID)){
        return false
      }
      return true
    }
    if(checkIsNotExistOrEmpty(newData)){
      newData = [item, ...newData];
      if(newData?.length > 5) newData = newData.slice( 0, 5);
      dispatch(setRecentlyViewedDocsAction(newData));
    }
    dispatch(getAutoLoginMobile());
    navigation.navigate({
      name: "DetailScreen",
      params: {item},
    });
  },
[recentlyViewedDocs],
)
  
  return (
    <View style={styles.container}>
      <HeaderWithAvatar dataCurrentUsers={dataCurrentUsers} onPressAvatar={() => dispatch(setIsShowBottomSheetAction(true))} title={languages.tab_home} notificationCount={notificationCount} urlOnline={undefined}/>
      <ImageBackground source={require('assets/images/background.png')} style={styles.bg_login}>
     <SectionList sections={dataHome}
     extraData={dataHome}
  refreshControl={
    <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor='#0054AE' />
  }
  renderItem={({item})=>(
    <View>
<TextCusTom i18nKey={item.title} style={styles.textTitle}/>
{!arrayIsEmpty(item.data) ? (
<FlatList
contentContainerStyle={styles.containerFlatList}
data={item.data}
extraData={item.data}
horizontal={true}
renderItem={({ item }) => (
  <DocumentViewItem item={item} gotoDetail={gotoDetailPress} />
)}
showsHorizontalScrollIndicator={false}
keyExtractor={(item: any, index) => uuid.v4().toString() }
/>
) : (
<NoDataView />
)}
<View style={styles.line}/>
</View>
  )}
      keyExtractor={(item, index) => uuid.v4().toString()}>
     </SectionList>
     </ImageBackground>
    </View>
  );
};
const styles = StyleSheet.create({
  container: {flex: 1, backgroundColor: colors.bg_app_color},
  bg_login: {
    flex: 1,
    backgroundColor: '#fff',
  },
  containerFlatList:{
  },
  textTitle: { color: colors.black, fontSize: FontSize.LARGE,fontWeight: '700', margin: 20 },
  line:{
    marginLeft: 20,
    height:1,
    backgroundColor:colors.grey_co,
    marginTop: 20
  }
});
export default React.memo(DashboardScreen);
