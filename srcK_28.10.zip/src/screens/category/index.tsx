import React, { useEffect } from 'react';
import { useDispatch, useSelector} from "react-redux";
import CategoryScreen from "./CategoryScreen";
import CategoryDetail from "./CategoryDetail";
import { getlistCategoryDocs, removeAllPositionStayCategory } from 'stories/category/reducer';
import { RootState } from 'stories/index';
import { ThunkDispatch } from 'redux-thunk';
import { useFocusEffect } from '@react-navigation/native';

const RootCategoryScreen= ({navigation, route}: any) =>{
    const {positionStayCategory} = useSelector((state: any) => state.category);
    const {languages,languagesText } = useSelector((state: RootState) => state.languages);
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();

  useFocusEffect(
    React.useCallback(() => {
     dispatch(removeAllPositionStayCategory())
    }, [])
  );
  return(
    <>
    {
      positionStayCategory.length === 0 ?
      <CategoryScreen  navigation={navigation} route={route}/>
      :
      <CategoryDetail navigation={navigation} route={route}/>
    }
  </>
  )
}
export default RootCategoryScreen
