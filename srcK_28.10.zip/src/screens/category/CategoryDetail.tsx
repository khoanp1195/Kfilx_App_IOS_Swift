
import React, { useCallback, useEffect, useState } from 'react';
import { Dimensions, FlatList, StyleSheet, Animated, TouchableOpacity, View,TouchableWithoutFeedback, RefreshControl, ActivityIndicator } from 'react-native';
import { WebView } from 'react-native-webview';
import Header from 'components/Header'
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from 'redux-thunk';
import { getAutoLoginMobile } from 'stories/dashboard/reducer';
import { RootState } from 'stories/index';
import colors from 'helpers/Colors';
import { arrayIsEmpty, checkIsEmpty, format_dd_mm_yy, isNullOrUndefined } from 'helpers/Functions';
import { BASE_URL, FontSize, RESONSE_STATUS_SUCCESS, dimensWidth } from 'helpers/Constants';
import HeaderWebView from 'components/HeaderWebView';
import { addPositionStayCategory, getListDocumentCategory, removeAllPositionStayCategory, removeLastPositionStayCategory, resetDocumentCategoryAction } from 'stories/category/reducer';
import NoDataView from 'components/NoDataView';
import uuid from 'react-native-uuid';
import TextCusTom from 'components/TextCusTom';
import FastImageCustom from 'components/FastImageCustom';
import FastImage from 'react-native-fast-image';
import { WINDOW_WIDTH } from '@gorhom/bottom-sheet';
import { RightIcon } from 'assets/svg';
import MainContainer from 'components/MainContainer';
import { get } from 'services/ApiServices';
// import Animated from 'react-native-reanimated';

type Props = {
    navigation: any
    route: any
}
const renderFooter = (loading: boolean,Offset: number) => {
  if(Offset < 20 || !loading  ) return null
  return (
      <View style={{
          padding: 10,
          justifyContent: 'center',
          alignItems: 'center',
          flexDirection: 'row',
      }}>
              <ActivityIndicator color="blue" style={{ marginLeft: 8 }} />
      </View>
  );
};
const LeftMenuItem = ({gotoDetail, item, index}: any) => {
 
  return (
    <TouchableOpacity onPress={() =>gotoDetail(item)}>

        <View style={styles.itemLeftMenu}>
        <FastImageCustom urlOnline={item?.Thumbnail} styleImg={styles.imgThumbnailLeftMenu}/>
        <View style={[styles.leftMenu]}>
        <TextCusTom i18nKey={item?.Title} style={[styles.textLeftMenu]} numberOfLines={1}/>
        <RightIcon />
        </View>
        </View>
    </TouchableOpacity>

  )
}
const CategorySnareItem = ({gotoDetail, item, index}: any) => {
    const formatDate = format_dd_mm_yy(item?.PublishDate)
    const isOdd = index % 2
  return (
    <TouchableOpacity onPress={() =>gotoDetail(item)}>
    <View style={[styles.itemContainer,!isOdd && {marginRight: dimensWidth(0)}]}>
        <View style={styles.itemChildContainer}>
        <FastImageCustom urlOnline={item?.Thumbnail} styleImg={styles.imgThumbnail} resizeMode={FastImage.resizeMode.contain}/>
        </View>
      <TextCusTom i18nKey={item?.Title} style={[styles.cap1,{width: dimensWidth(120)}]} numberOfLines={1}/>
      <TextCusTom i18nKey={item?.Description} style={[styles.cap2,{width: dimensWidth(120)}]} numberOfLines={2}/>
    </View>
    </TouchableOpacity>

  )
}
const CategoryNotSnareItem = ({gotoDetail, item, index}: any) => {
    const formatDate = format_dd_mm_yy(item?.IssueDate)
    const isOdd = index % 2
  return (
    <View style={[styles.itemNotSnareContainer,!isOdd && {backgroundColor:colors.light_cyan}]}>
        <TouchableOpacity onPress={() =>gotoDetail(item)}>
        <FastImageCustom urlOnline={item?.Thumbnail} styleImg={styles.imgThumbnailNotSnare}/>
        </TouchableOpacity>
     <View style={{flex: 1,}}>
     <View style={styles.rowBetween}>
     <TextCusTom i18nKey={item?.Title} style={styles.cap1} numberOfLines={1}/>
     </View>
     <View style={styles.rowBetween}>
     <TextCusTom i18nKey={item?.StorageCode} style={styles.contentNotSnare} numberOfLines={2}/>
     <TextCusTom i18nKey={formatDate} style={styles.cap2} numberOfLines={2}/>
     </View>
     </View>
    </View>
  )
}

const CategoryDetailScreen = ({route, navigation}: Props) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const {languages,languagesText } = useSelector((state: RootState) => state.languages);
    const {listDocumentCategory,positionStayCategory,listCategoryDocs} = useSelector((state: RootState) => state.category);
    const [listDocumentCategoryState, setlistDocumentCategoryState] = useState([])
    const [isShowDrawview, setIsShowDrawview] = useState(false);
    const [isSnare, setIsSNare] = useState(true);
    const current = new Animated.Value(0);
    const [progress, setProgress] = useState(new Animated.Value(0));
    const [listLeftMenu, setlistLeftMenu] = useState([])
    const [titleHeader, setTitleHeader] = useState("") 
    const [Offset, setOffset] = useState(0)
    const [isRefresh, setIsRefresh] = useState(false)
    const [primaryKeyState, setPrimaryKeyState] = useState(0)
    const {isLoading, totalRecord} = listDocumentCategory;

    const fetchData = useCallback(
      (lang: string, Offset: any,primarykeyId: number) => {
        const LangId = lang === 'EN' ? 1033 :1066
        const body = {
          "AreaCategoryId":primarykeyId,
          "DocumentGroupId": "1",
          "Title": "",
          "Code": "",
          "StorageCode": "",
          "Int2": ""
      }
        dispatch(getListDocumentCategory({LangId, Offset,data: body}))
      },
    [],
    )

    useEffect(() => {
        if(positionStayCategory.length > 0 &&  !isNullOrUndefined(listCategoryDocs.data)) {
          const primarykeyId = positionStayCategory[positionStayCategory.length-1].ID
          setPrimaryKeyState(primarykeyId)
          setTitleHeader(positionStayCategory[positionStayCategory.length-1].Title)
          setlistLeftMenu(listCategoryDocs.data.filter(it => it.ParentId === primarykeyId))
          fetchData(languagesText, Offset, primarykeyId)
        }
    }, [languagesText, positionStayCategory,listCategoryDocs])
    
    const handleClickLeftMenu = useCallback(
        (item: any) => {
          dispatch(addPositionStayCategory(item))
          setIsShowDrawview(false)
        },
      [],
      )
    const backPress = useCallback(
        () => {
          dispatch(removeLastPositionStayCategory())
          setIsShowDrawview(false)
        },
      [positionStayCategory],
      )
    const gotoDetailPress = useCallback(
        (item: any) => {
          dispatch(resetDocumentCategoryAction(null))
          get('/psd/API/User.ashx?func=mobileAutoLoginWeb',
    ).then(res =>{
      if (!isNullOrUndefined(res)) {
        if (res.data.status === RESONSE_STATUS_SUCCESS) {   
          navigation.navigate({
            name: "DetailScreen",
            params: {item},
          });
        }
      }
    })
        },
      [],
      )

      useEffect(() => {
        if(!arrayIsEmpty(listDocumentCategory.data)){
          setlistDocumentCategoryState(listDocumentCategory.data)
        }
      }, [listDocumentCategory])

    
      const handlePressDrawView = useCallback(
        () => {
          if(isShowDrawview){
            setIsShowDrawview(false)
          }else{
            setIsShowDrawview(true)
          }
          Animated.parallel([
            Animated.timing(current, {
                toValue:  0,
                duration:300,
                useNativeDriver:false,
            }),
        Animated.timing(progress, {
            toValue:1,
            duration:300,
            useNativeDriver:false
        })
        ]).start(()=>{
          isShowDrawview ? progress.setValue(0) : progress.setValue(1) 
        })

        },
        [isShowDrawview],
      )
      const handleCloseDrawView = useCallback(
        () => {
          setIsShowDrawview(false)
        },
        [],
      )
      const handleLoadmore = async() => {
        if (listCategoryDocs.data.length < totalRecord && !isLoading) {
            setOffset(listCategoryDocs.data.length);
        }
       }
      const onRefresh = useCallback(() => {
        if (!isLoading) {
            setIsRefresh(true)
            setOffset(0);
            fetchData(languagesText,0,primaryKeyState)
        }
    }, [languagesText])

      const progressAnim=progress.interpolate({
        inputRange:[0, 1],
        outputRange:["0%", "80%"],
    });

    const drawWidth={
        width:progressAnim
    }
  return (
      <MainContainer BackPressCustom={backPress}>
        <HeaderWebView title={titleHeader} onPressAvatar={handlePressDrawView} isSnare={isSnare} onNnareChange ={() => setIsSNare(!isSnare)}/>
       <View style={styles.container}>

{ isShowDrawview&&
   <View  style={styles.drawView}>
   <Animated.View style={[styles.aniamtedView, drawWidth]}>
    {listLeftMenu.length> 0 ?
    <FlatList
    contentContainerStyle={{flexGrow: 1}}
   data={listLeftMenu}
   extraData={listLeftMenu}
   showsVerticalScrollIndicator={false}
   renderItem={({ item ,index}) => (
   <LeftMenuItem item={item} gotoDetail={handleClickLeftMenu} index={index}/>
   )}
   showsHorizontalScrollIndicator={false}
   keyExtractor={(item: any, index) => uuid.v4().toString() }
   />
   :
      <NoDataView />}
    </Animated.View>
    <TouchableWithoutFeedback style={styles.closeDrawView}  onPress={handleCloseDrawView}>
      <View style={styles.closeDrawView}/>
    </TouchableWithoutFeedback>
    </View>
}
<View>

{isSnare ?
  <FlatList
  key={'snare'}
contentContainerStyle={styles.containerFlatList}
data={listDocumentCategoryState}
showsVerticalScrollIndicator={false}
extraData={listDocumentCategoryState}
numColumns={2}
renderItem={({ item,index }) => (
<CategorySnareItem item={item} gotoDetail={gotoDetailPress} index={index}/>
)}
showsHorizontalScrollIndicator={false}
keyExtractor={(item: any, index) => uuid.v4().toString() }
/>
:
<FlatList
contentContainerStyle={{flexGrow: 1}}
 key={'not_snare'}
data={listDocumentCategoryState}
extraData={listDocumentCategoryState}
showsVerticalScrollIndicator={false}
renderItem={({ item ,index}) => (
<CategoryNotSnareItem item={item} gotoDetail={gotoDetailPress} index={index}/>
)}
keyExtractor={(item: any, index) => uuid.v4().toString() }
refreshControl={
  <RefreshControl refreshing={isRefresh} onRefresh={onRefresh} tintColor='#0054AE' />
}
onEndReached={handleLoadmore}
ListFooterComponent={renderFooter(isLoading, Offset)}
onEndReachedThreshold={0.5} />
}
</View>
       </View>
  </MainContainer>
  );
}

export default CategoryDetailScreen

const styles = StyleSheet.create({
  container:{
    flex: 1,
  },
    containerFlatList:{
      flexGrow: 1,
    marginTop: 20,
    },
    itemLeftMenu:{
      flexDirection:'row',
        justifyContent: 'center',
        alignItems: 'center',
        paddingLeft: 20,
        paddingTop: 10
    },
    imgThumbnailLeftMenu:{
      height:20,
      width: 20,
      borderRadius: 3,
  },
  textLeftMenu:{
    fontSize: FontSize.SMALL,
    color: colors.text_grey_7b,
    fontWeight: '400',
    marginTop: 7,
    flex: 1,
    marginBottom: 10
},
leftMenu:{
  flexDirection:'row',
    flex: 1,
    borderBottomWidth:0.5,
    borderBottomColor: colors.grey_co,
    paddingRight: 20
},
    itemContainer:{
        width: WINDOW_WIDTH / 2,
        marginBottom: 20,
        justifyContent: 'center',
        alignItems: 'center',
    },
    itemChildContainer:{
        width: dimensWidth(160),
        height:dimensWidth(200),
        justifyContent: 'center',
        alignItems: 'center',
    },
    itemNotSnareContainer:{
        paddingStart: 20,
        paddingBottom: 10,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection:'row',
        backgroundColor: colors.white
    },
    rowBetween:{
      justifyContent: 'space-between',
      alignItems: 'center',
      flexDirection:'row'
    },
    imgThumbnail:{
      width: dimensWidth(160),
      height:dimensWidth(200),
    },
    imgThumbnailNotSnare:{
      height: 42,
      width: 32,
        borderRadius: 3,
    },
    cap1:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey26,
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'left',
        paddingLeft:10,
        flex: 1,
    },
    cap2:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey_7b,
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'right',
        flex: 1,
        paddingRight: 10
    },

    contentNotSnare:{
        fontSize: FontSize.SMALL,
        color: colors.blue,
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'left',
        paddingLeft:10,
        flex: 1,
    },
    drawView: {
      flex: 1,
      zIndex: 999,
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.333333)',
      justifyContent: 'center',
      flexDirection:'row'
    },
    aniamtedView:{
      flex:4,
      backgroundColor: colors.white,
      zIndex: 9999,
    },
    closeDrawView:{
      flex: 1,
      zIndex: 99,
      backgroundColor:'transparent'
    }
})