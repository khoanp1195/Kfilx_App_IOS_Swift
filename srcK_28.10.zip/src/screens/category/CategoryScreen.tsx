
import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, RefreshControl, StyleSheet, TouchableOpacity, View } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from 'redux-thunk';
import { RootState } from 'stories/index';
import colors from 'helpers/Colors';
import { arrayIsEmpty, format_dd_mm_yy, isNullOrUndefined } from 'helpers/Functions';
import { FontSize } from 'helpers/Constants';
import { addPositionStayCategory, getlistCategoryDocs, resetDocumentCategoryAction, } from 'stories/category/reducer';
import NoDataView from 'components/NoDataView';
import uuid from 'react-native-uuid';
import TextCusTom from 'components/TextCusTom';
import FastImageCustom from 'components/FastImageCustom';
import MainContainer from 'components/MainContainer';
import { useFocusEffect } from '@react-navigation/native';

type Props = {
    navigation: any
    route: any
}
const renderFooter = (loading: boolean,Offset: number) => {
  if(Offset < 20 || !loading  ) return null
  return (
      <View style={{
          padding: 10,
          justifyContent: 'center',
          alignItems: 'center',
          flexDirection: 'row',
      }}>
              <ActivityIndicator color="blue" style={{ marginLeft: 8 }} />
      </View>
  );
};
const DocumentViewItem = ({gotoDetail, item}: any) => {
    const formatDate = format_dd_mm_yy(item?.PublishDate)
    let imageObj = JSON.parse(item?.Image);
    
  return (
    <View style={styles.itemContainer}>
        <TouchableOpacity onPress={() =>gotoDetail(item)}>
        <FastImageCustom urlOnline={imageObj?.Path} styleImg={styles.imgThumbnail}/>
        </TouchableOpacity>
      <TextCusTom i18nKey={item?.Title} style={styles.cap1} numberOfLines={1}/>
      <TextCusTom i18nKey={item?.Description} style={styles.cap2} numberOfLines={2}/>
    </View>
  )
}

const CategoryScreen = ({route, navigation}: Props) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const {languages,languagesText } = useSelector((state: RootState) => state.languages);
    const {listCategoryDocs} = useSelector((state: RootState) => state.category);
    const [listCategoryDocsState, setlistCategoryDocsState] = useState([])
    const [Offset, setOffset] = useState(0)
    const [isRefresh, setIsRefresh] = useState(false)
    const {isLoading, totalRecord} = listCategoryDocs
    const gotoDetailPress = useCallback(
      (item: any) => {
        dispatch(addPositionStayCategory(item))
      },
    [listCategoryDocs],
    )
    const fetchData = useCallback(
      (lang: string, Offset: any) => {
        const langId = lang === 'EN' ? 1033 :1066
        dispatch(getlistCategoryDocs({langId, Offset}))
      },
    [listCategoryDocs],
    )
  useFocusEffect(
    React.useCallback(() => {
      fetchData(languagesText, Offset)
    }, [languagesText,Offset])
  );
    useEffect(() => {
      
      if(!isNullOrUndefined(listCategoryDocs.data)){
        setlistCategoryDocsState(listCategoryDocs.data.filter(it => it.ParentId === null));
        // alert(listCategoryDocs.data.length)
      }
    }, [listCategoryDocs])
    const handleLoadmore = async() => {
      if (listCategoryDocs.data.length < totalRecord && !isLoading) {
          setOffset(listCategoryDocs.data.length);
      }
     }
    const onRefresh = useCallback(() => {
      if (!isLoading) {
          setIsRefresh(true)
          setOffset(0);
          fetchData(languagesText,0)
      }
  }, [languagesText])
  return (
    <MainContainer title={languages.tab_category}>
       <View style={styles.container}>
       {!arrayIsEmpty(listCategoryDocsState) ? (
<FlatList
contentContainerStyle={styles.containerFlatList}
data={listCategoryDocsState}
extraData={listCategoryDocsState}
numColumns={2}
renderItem={({ item }) => (
  <DocumentViewItem item={item} gotoDetail={gotoDetailPress} />
)}
showsHorizontalScrollIndicator={false}
keyExtractor={(item: any, index) => uuid.v4().toString() }
refreshControl={
  <RefreshControl refreshing={isRefresh} onRefresh={onRefresh} tintColor='#0054AE' />
}
onEndReached={handleLoadmore}
ListFooterComponent={renderFooter(isLoading, Offset)}
onEndReachedThreshold={0.5} />

) : (
<NoDataView />
)}
       </View>
      </MainContainer>
  );
}

export default CategoryScreen

const styles = StyleSheet.create({
  container:{
    flex: 1,
  },
    containerFlatList:{
    marginTop: 20,
    justifyContent: 'center',
    alignItems: 'center'
    },
    itemContainer:{
        width: 160,
        marginLeft: 20,
        marginBottom: 20,
        justifyContent: 'center',
        alignItems: 'center'
    },
    imgThumbnail:{
        height: 120,
        width: 120,
        borderRadius: 3,
        backgroundColor: '#E2F9FF'
    },
    cap1:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey26,
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'center',
        paddingHorizontal: 10
    },
    cap2:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey_7b,
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'center',
        paddingHorizontal: 10
    }
})