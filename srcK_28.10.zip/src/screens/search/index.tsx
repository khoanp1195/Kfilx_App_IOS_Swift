
import React, { useCallback, useEffect, useState } from 'react';
import { FlatList, StyleSheet, Text, TouchableOpacity, View, Keyboard, AppState, Alert } from 'react-native';
import { WebView } from 'react-native-webview';
import Header from 'components/Header'
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from 'redux-thunk';
import { getAutoLoginMobile } from 'stories/dashboard/reducer';
import { RootState } from 'stories/index';
import colors from 'helpers/Colors';
import { arrayIsEmpty, checkIsEmpty, format_dd_mm_yy, isNullOrUndefined } from 'helpers/Functions';
import { BASE_URL, FontSize, dimensWidth } from 'helpers/Constants';
import { getlistCategoryDocs } from 'stories/category/reducer';
import NoDataView from 'components/NoDataView';
import uuid from 'react-native-uuid';
import TextCusTom from 'components/TextCusTom';
import FastImageCustom from 'components/FastImageCustom';
import FastImage from 'react-native-fast-image';
import TextInputCustom from 'components/TextInputCustom';
import { SearchIcon } from 'assets/svg';
import { setSearchText } from 'stories/search/reducer';
import MainContainer from 'components/MainContainer';

type Props = {
    navigation: any
    route: any
}

const DocumentViewItem = ({gotoDetail, item}: any) => {
    const formatDate = format_dd_mm_yy(item?.PublishDate)
    let imageObj = JSON.parse(item?.Image);
    
  return (
    <View style={styles.itemContainer}>
        <TouchableOpacity onPress={() =>gotoDetail(item)}>
        <FastImageCustom urlOnline={imageObj?.Path} styleImg={styles.imgThumbnail}/>
        </TouchableOpacity>
      <TextCusTom i18nKey={item?.Title} style={styles.cap1} numberOfLines={1}/>
      <TextCusTom i18nKey={item?.Description} style={styles.cap2} numberOfLines={2}/>
    </View>
  )
}

const CategoryScreen = ({route, navigation}: Props) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const {languages,languagesText } = useSelector((state: RootState) => state.languages);
    const {SearchList,searchText } = useSelector((state: RootState) => state.search);
    const [dataSearch, setDataSearch] = useState<any>([])
    useEffect(() => {
      
     if(!arrayIsEmpty(SearchList)){
      function sortBySearchCount(a: any, b: any) {
          if (a.seachCount < b.seachCount) {
              return 1;
          }
          if (a.seachCount > b.seachCount) {
              return -1;
          }
          return 0;
      }
      const data = SearchList.slice(0,5).sort(sortBySearchCount);
      setDataSearch(data);
     }
   }, [SearchList])
 const gotoSearchView = useCallback(
   (isHistorySearch: boolean) => {
    navigation.navigate({name: 'SearchingViewScreen',params:{isHistorySearch}})
   },[])
 
    const onChangeSearch = useCallback(
      (text: any) => {
        dispatch(setSearchText(text))
      },
      [searchText],
    )
    const onPressSearch = useCallback(
      () => {
     if(searchText.length > 3){
      const isExistText = dataSearch.find(it => it === searchText)
      if(!isExistText){
        let data = []
        if(arrayIsEmpty(dataSearch)){
          data = [searchText];
        }else{
          data = dataSearch.concat(searchText);
        }
        setDataSearch(data)
      }
      dispatch(setSearchText(""))
      Keyboard.dismiss();
     }else{
      Alert.alert(languages.notification, languages.require_search, [
        {text: languages.ok, onPress: () => console.log('OK Pressed')},
      ]);
     }
      },
      [searchText,dataSearch],
    )
    const onPressHistoryItem = useCallback(
      (text: any) => {
        dispatch(setSearchText(text))
        gotoSearchView(true)
      },
      [],
    )

  return (
   <MainContainer title={languages.tab_search}r>
<View style={styles.container}>
<TouchableOpacity style={styles.searchInput} onPress={() =>gotoSearchView(false)} activeOpacity={1}>
   <TouchableOpacity onPress={onPressSearch}>
   <SearchIcon />
   </TouchableOpacity>
   <TextInputCustom value={searchText} onChangeText={onChangeSearch} placeholder={languages.search_hint} style={{flex:1, marginLeft: 10}} editable={false}/>
 </TouchableOpacity>

 <TextCusTom i18nKey={languages.trend} style={styles.trend} numberOfLines={1}/>

{!arrayIsEmpty(dataSearch) ? (
<FlatList
contentContainerStyle={styles.containerFlatList}
data={dataSearch}
extraData={dataSearch}
renderItem={({ item }) => (
<View style={styles.searchHistoryItem}>
   <TouchableOpacity onPress={onPressSearch}>
   <SearchIcon color={colors.orange}/>
   </TouchableOpacity>
 <TouchableOpacity onPress={() =>onPressHistoryItem(item.title)}>
 <TextCusTom i18nKey={item.title } style={styles.historyText}/>
 </TouchableOpacity>
 </View>
)}
showsHorizontalScrollIndicator={false}
keyExtractor={(item: any, index) => uuid.v4().toString() }
/>
) : (
<NoDataView />
)}
</View>
   </MainContainer>
  );
}

export default CategoryScreen

const styles = StyleSheet.create({
  container:{
    flex: 1,backgroundColor: colors.bg_app_color 
  },
    containerFlatList:{
    marginTop: 20,
    alignItems: 'center'
    },
    itemContainer:{
        width: 160,
        marginLeft: 20,
        marginBottom: 20,
        justifyContent: 'center',
        alignItems: 'center'
    },
    imgThumbnail:{
        height: 120,
        width: 120,
        borderRadius: 3,
        backgroundColor: '#E2F9FF'
    },

    trend:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey26,
        fontWeight: '400',
        margin: 10,
        paddingHorizontal: 10
    },
    historyText:{
        fontSize: FontSize.SMALL,
        color: colors.grey_4f,
        fontWeight: '400',
        marginHorizontal: 10,
        paddingHorizontal: 10
    },
    cap1:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey26,
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'center',
        paddingHorizontal: 10
    },
    cap2:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey_7b,
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'center',
        paddingHorizontal: 10
    },
    searchInput :{
       height: 40,
       margin: 20, 
       flexDirection:'row',
       justifyContent: 'center',
       alignItems: 'center',
       borderColor: colors.orange,
       borderWidth: 0.75,
       borderRadius:20,
       paddingHorizontal: 10,
       backgroundColor: '#FFFAEE'
      },
    searchHistoryItem :{
       height: 40,
       marginBottom: 20, 
       flexDirection:'row',
       alignItems: 'center',
       paddingHorizontal: 10,
       borderBottomWidth: 0.75,
       borderBottomColor: colors.grey_co,
       width: dimensWidth(374)
      },
})