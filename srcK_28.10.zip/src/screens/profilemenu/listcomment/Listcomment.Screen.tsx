import { ActivityIndicator, FlatList, RefreshControl, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import React, { useCallback, useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { RootState } from 'stories/index'
import { getlistcommentDocs } from 'stories/listcomment/reducer'
import NoDataView from 'components/NoDataView'
import { arrayIsEmpty, format_dd_mm_yy, isNullOrUndefined } from 'helpers/Functions'
import { FontFamily, FontSize } from 'helpers/Constants'
import colors from 'helpers/Colors'
import TextCusTom from 'components/TextCusTom'
import FastImageCustom from 'components/FastImageCustom'
import { useFocusEffect } from '@react-navigation/native'
import { getAutoLoginMobile } from 'stories/dashboard/reducer'
import MainContainer from 'components/MainContainer'

const renderFooter = (loading: boolean,Offset: number) => {
  if(Offset < 20 || !loading  ) return null
  return (
      <View style={{
          padding: 10,
          justifyContent: 'center',
          alignItems: 'center',
          flexDirection: 'row',
      }}>
              <ActivityIndicator color="blue" style={{ marginLeft: 8 }} />
      </View>
  );
};
const CommentDocItem = ({item, index, gotoDetail}: any) => {
  const formatCreateDate = format_dd_mm_yy(item?.Created)
  const isOdd = index % 2;
  let customColor = 'white'
  if(item?.status === 'Đã phê duyệt'){
    customColor = colors.green
  }else if(item?.status === 'Chờ phê duyệt'){
    customColor = colors.light_blue
  }else{
    customColor =colors.pink
  }
  return (
      <TouchableOpacity style={[styles.itemContainer,!isOdd && {backgroundColor: colors.white_blue }]} onPress={() => gotoDetail(item)}>
      <View>
      <FastImageCustom urlOnline={ item?.Thumbnail} styleImg={styles.itemThumbnail}/>
      </View>
      <View style={styles.itemChildRight}>
      <View style={styles.flexDirectionRow}>
      <TextCusTom i18nKey={item?.Title} style={[styles.textContent,{flex: 1, marginRight: 5}]} numberOfLines={1}/>
      <TextCusTom i18nKey={formatCreateDate} style={styles.textContentSmall} numberOfLines={1}/>
      </View>
      <View style={styles.flexDirectionRow}>
      <TextCusTom i18nKey={item?.Title} style={[styles.textContentSmall,{flex: 1, marginRight: 5}]} numberOfLines={1}/>
      <View style={{
        height: 20,
        width: 110,
        backgroundColor:customColor,
        justifyContent: 'center',
        alignItems: 'center'
      }}>
      <TextCusTom i18nKey={item?.status} style={styles.textContentSmall} numberOfLines={1}/>
      </View>
      </View>
      </View>
      </TouchableOpacity>
        )
}

const listcommentDocsScreen = ({navigation}: any) => {
  const {languages,languagesText } = useSelector((state: RootState) => state.languages);
  const { listcommentDocs} = useSelector((state: RootState) => state.listcomment);
  const {isLoading, totalRecord} = listcommentDocs;
  const dispatch = useDispatch<any>();

  const [listcommentDocsState, setlistcommentDocsState] = useState([])
  const [Offset, setOffset] = useState(0)
  const [isRefresh, setIsRefresh] = useState(false)
  const [flatListReady, setFlatListReady] = useState(false)
  useEffect(() => {
    const langId = languagesText === 'EN' ? 1033 :1066
    dispatch(getlistcommentDocs({langId, Offset}));
  }, [languagesText,Offset])
  useFocusEffect(
    React.useCallback(() => {
      const langId = languagesText === 'EN' ? 1033 :1066
      dispatch(getlistcommentDocs({langId, Offset}));
    }, [languagesText, Offset])
  );
  useEffect(() => {
    if(!isNullOrUndefined(listcommentDocs.data)){
      setlistcommentDocsState(listcommentDocs.data);
      // alert(listcommentDocs.data.length)
    }
  }, [listcommentDocs])

  const gotoDetailPress = useCallback(
    (item: any) => {
      dispatch(getAutoLoginMobile());
      navigation.navigate({
        name: "DetailScreen",
        params: {item},
      });
    },
  [],
  )
  const handleLoadmore = async() => {
    if (listcommentDocs.data.length < totalRecord && !isLoading && flatListReady) {
        setOffset(listcommentDocs.data.length);
    }
   }
  const onRefresh = useCallback(() => {
    if (!isLoading) {
        setIsRefresh(true)
        setOffset(0);
        const langId = languagesText === 'EN' ? 1033 :1066
        dispatch(getlistcommentDocs({langId, Offset: 0}));
    }
}, [languagesText])
  useEffect(() => {
    if(!isLoading) setIsRefresh(false)
  }, [isLoading])

  const _scrolled = () =>{
    setFlatListReady(true)
    }
    const backPress = useCallback(
      () => {
        dispatch(setIsShowBottomSheetAction(true))
        setTimeout(() => {
          navigation.goBack(); 
        }, 100);
      },
    [],
    )
    return (
    <MainContainer title={languages.list_comments}  BackPressCustom={backPress}>
      {!arrayIsEmpty(listcommentDocsState) ?
                            <FlatList
                                contentContainerStyle={{
                                    paddingBottom: 20,
                                    marginBottom:20,
                                }}
                                onScroll={_scrolled}
                                extraData={listcommentDocsState}
                                data={listcommentDocsState}
                                renderItem={({ item, index }) => (
                                    <CommentDocItem
                                        item={item}
                                        index={index}
                                        gotoDetail={gotoDetailPress}
                                    />
                                )}
                                refreshControl={
                                  <RefreshControl refreshing={isRefresh} onRefresh={onRefresh} tintColor='#0054AE' />
                                }
                                keyExtractor={(item, index) => String(index)}
                                showsVerticalScrollIndicator={false}
                                onEndReached={handleLoadmore}
                                ListFooterComponent={renderFooter(isLoading, Offset)}
                                onEndReachedThreshold={0.5} />
                            : <NoDataView /> 
                        }
    </MainContainer>
  )
}

export default React.memo(listcommentDocsScreen)

const styles = StyleSheet.create({
  container:{
    flex: 1,
    backgroundColor: colors.white
  },
  itemContainer:{
    height: 70,
    flexDirection: 'row',
    padding: 10,
    alignItems: 'center',
    backgroundColor: colors.white
  },
  textTitle: { color: colors.black_121, fontSize: FontSize.LARGE,fontWeight: '400', fontFamily: FontFamily.HERITAGE_REGULAR },
  textContent: { color: colors.black_121, fontSize: FontSize.SMALL,fontWeight: '400', fontFamily: FontFamily.HERITAGE_REGULAR },
  textContentSmall: { color: colors.black_7b, fontSize: FontSize.SMALL1,fontWeight: '400', fontFamily: FontFamily.HERITAGE_REGULAR },
  itemThumbnail: {
    height: 42,
    width: 32,
    margin: 10,
    borderRadius: 0
  },
  flexDirectionRow:{
    flexDirection: 'row',
    flex: 1,
    justifyContent: 'space-between'
  },
  itemChildRight: {
    flex: 1,
    alignItems: 'center'
   }
})