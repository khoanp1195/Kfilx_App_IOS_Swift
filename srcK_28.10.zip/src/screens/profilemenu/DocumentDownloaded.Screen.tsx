import { ActivityIndicator, FlatList, RefreshControl, StyleSheet, Text, View } from 'react-native'
import React, { useCallback, useEffect, useState } from 'react'
import Header from 'components/Header'
import { useDispatch, useSelector } from 'react-redux'
import { RootState } from 'stories/index'
import NoDataView from 'components/NoDataView'
import { arrayIsEmpty, format_dd_mm_yy, format_dd_mm_yyyy_hh_mm, format_yy_mm_mm_dd_hh, isNullOrUndefined } from 'helpers/Functions'
import { BASE_URL, FontFamily, FontSize, dimnensHeight } from 'helpers/Constants'
import colors from 'helpers/Colors'
import TextCusTom from 'components/TextCusTom'
import FastImageCustom from 'components/FastImageCustom'
import { useFocusEffect } from '@react-navigation/native'
import { TouchableOpacity } from 'react-native-gesture-handler'
import { getAutoLoginMobile } from 'stories/dashboard/reducer'
import MainContainer from 'components/MainContainer'
import HeaderWebView from 'components/HeaderWebView'


const DocumentViewItem = ({gotoDetail, item}: any) => {
  const formatDate = format_dd_mm_yy(item?.PublishDate)
return (
  <View style={styles.itemContainer}>
      <TouchableOpacity onPress={() =>gotoDetail(item)}>
      <FastImageCustom urlOnline={item?.Thumbnail} styleImg={styles.imgThumbnail}/>
      </TouchableOpacity>
    <TextCusTom i18nKey={item?.FileTitle} style={styles.cap1} numberOfLines={1}/>
    <TextCusTom i18nKey={formatDate} style={styles.cap1}/>
  </View>
)
}


const documentDownloadedScreen = ({navigation}: any) => {
  const {languages,languagesText } = useSelector((state: RootState) => state.languages);
  const { documentDownloadedList} = useSelector((state: RootState) => state.dashboard);
  const dispatch = useDispatch<any>();

  const [documentDownloadedState, setdocumentDownloadedState] = useState([])
  const [Offset, setOffset] = useState(0)
  const [isRefresh, setIsRefresh] = useState(false)
  const [flatListReady, setFlatListReady] = useState(false)

  useEffect(() => {
    if(!isNullOrUndefined(documentDownloadedList)){
      setdocumentDownloadedState(documentDownloadedList);
      // alert(documentDownloadedList.length)
    }
  }, [documentDownloadedList])

  const gotoDetailPress = useCallback(
    (item: any) => {
      
      dispatch(getAutoLoginMobile());
      navigation.navigate({
        name: "DocumentDownloadedDetailScreen",
        params: {item},
      });
    },
    [],
  )
    
    return (
      <MainContainer title={languages.downloadedDocs}>
       {!arrayIsEmpty(documentDownloadedState) ?
                            <FlatList
                                contentContainerStyle={{
                                   margin: 20
                                }}
                                numColumns={2}
                                extraData={documentDownloadedState}
                                data={documentDownloadedState}
                                renderItem={({ item }) => (
                                  <DocumentViewItem item={item} gotoDetail={gotoDetailPress} />
                                )}
                                keyExtractor={(item, index) => String(index)}
                                showsVerticalScrollIndicator={false}
                                onEndReachedThreshold={0.5} />
                            : <NoDataView />
                        }
      </MainContainer>
  )
}

export default React.memo(documentDownloadedScreen)

const styles = StyleSheet.create({
  container:{
    flex: 1,
    backgroundColor: colors.white
  },
  textTitle: { color: colors.black_121, fontSize: FontSize.LARGE,fontWeight: '400', fontFamily: FontFamily.HERITAGE_REGULAR },
  textContent: { color: colors.black_121, fontSize: FontSize.SMALL,fontWeight: '400', fontFamily: FontFamily.HERITAGE_REGULAR },
  textContentSmall: { color: colors.black_7b, fontSize: FontSize.SMALL1,fontWeight: '400', fontFamily: FontFamily.HERITAGE_REGULAR },
  itemThumbnail: {
    height: 42,
    width: 32,
    margin: 10,
    borderRadius: 0
  },
  flexDirectionRow:{
    flexDirection: 'row',
    flex: 1,
    justifyContent: 'space-between'
  },
  itemChildRight: {
    flex: 1,
    alignItems: 'center'
   },
   itemContainer:{
    width: 160,
    height: 250,
    marginLeft: 20,
},
 imgThumbnail:{
    height: 200,
    width: 160,
    borderRadius: 3,
    backgroundColor: colors.white
},
cap1:{
    fontSize: FontSize.SMALL,
    color: colors.text_grey26,
    fontWeight: '400',
    marginTop: 7,
    textAlign: 'center'
}
})