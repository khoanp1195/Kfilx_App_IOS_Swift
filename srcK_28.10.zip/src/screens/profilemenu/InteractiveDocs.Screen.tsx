import { ActivityIndicator, FlatList, RefreshControl, StyleSheet, Text, View } from 'react-native'
import React, { useCallback, useEffect, useState } from 'react'
import Header from 'components/Header'
import { useDispatch, useSelector } from 'react-redux'
import { RootState } from 'stories/index'
import { getinteractiveDocs } from 'stories/profilemenu/reducer'
import NoDataView from 'components/NoDataView'
import { arrayIsEmpty, format_dd_mm_yy, format_dd_mm_yyyy_hh_mm, format_yy_mm_mm_dd_hh, isNullOrUndefined } from 'helpers/Functions'
import { BASE_URL, FontFamily, FontSize, dimnensHeight } from 'helpers/Constants'
import colors from 'helpers/Colors'
import TextCusTom from 'components/TextCusTom'
import FastImageCustom from 'components/FastImageCustom'
import { useFocusEffect } from '@react-navigation/native'
import { getAutoLoginMobile, setIsShowBottomSheetAction } from 'stories/dashboard/reducer'
import { TouchableOpacity } from 'react-native-gesture-handler'
import MainContainer from 'components/MainContainer'

const renderFooter = (loading: boolean,Offset: number) => {
  if(Offset < 20 || !loading  ) return null
  return (
      <View style={{
          padding: 10,
          justifyContent: 'center',
          alignItems: 'center',
          flexDirection: 'row',
      }}>
              <ActivityIndicator color="blue" style={{ marginLeft: 8 }} />
      </View>
  );
};
const InteractiveDocItem = ({item, index, gotoDetail}: any) => {
  const formatCreateDate = format_dd_mm_yy(item?.Created)
  const formatFromDate = format_yy_mm_mm_dd_hh(item?.Created)
  const isOdd = index % 2;
  return (
    <TouchableOpacity style={[styles.itemContainer,!isOdd && {backgroundColor: colors.white_blue }]} onPress={() => gotoDetail(item)}>
      <View>
      <FastImageCustom urlOnline={ item?.Thumbnail} styleImg={styles.itemThumbnail}/>
      </View>
      <View style={styles.itemChildRight}>
      <View style={styles.flexDirectionRow}>
      <TextCusTom i18nKey={item?.Title} style={[styles.textContent,{flex: 1, marginRight: 5}]} numberOfLines={1}/>
      <TextCusTom i18nKey={formatCreateDate} style={styles.textContentSmall} numberOfLines={1}/>
      </View>
      <View style={styles.flexDirectionRow}>
      <TextCusTom i18nKey={item?.Title} style={[styles.textContentSmall,{flex: 1, marginRight: 5}]} numberOfLines={1}/>
      <TextCusTom i18nKey={formatFromDate} style={styles.textContentSmall} numberOfLines={1}/>
      </View>
      </View>
    </TouchableOpacity>
  )
}

const InteractiveDocsScreen = ({navigation}: any) => {
  const {languages,languagesText } = useSelector((state: RootState) => state.languages);
  const { interactiveDocs} = useSelector((state: RootState) => state.profilemenu);
  const {isLoading, totalRecord} = interactiveDocs;
  const dispatch = useDispatch<any>();

  const [interactiveDocsState, setInteractiveDocsState] = useState([])
  const [Offset, setOffset] = useState(0)
  const [isRefresh, setIsRefresh] = useState(false)
  const [flatListReady, setFlatListReady] = useState(false)

  useFocusEffect(
    React.useCallback(() => {
      const langId = languagesText === 'EN' ? 1033 :1066
      dispatch(getinteractiveDocs({langId, Offset}));
    }, [languagesText, Offset])
  );
  useEffect(() => {
    if(!isNullOrUndefined(interactiveDocs.data)){
      setInteractiveDocsState(interactiveDocs.data);
      // alert(interactiveDocs.data.length)
    }
  }, [interactiveDocs])

  const gotoDetailPress = useCallback(
    (item: any) => {
      dispatch(getAutoLoginMobile());
      navigation.navigate({
        name: "DetailScreen",
        params: {item},
      });
    },
  [],
  )
  const handleLoadmore = async() => {
    if (interactiveDocs.data.length < totalRecord && !isLoading && flatListReady) {
        setOffset(interactiveDocs.data.length);
    }
   }
  const onRefresh = useCallback(() => {
    if (!isLoading) {
        setIsRefresh(true)
        setOffset(0);
        const langId = languagesText === 'EN' ? 1033 :1066
        dispatch(getinteractiveDocs({langId, Offset: 0}));
    }
}, [languagesText])
  useEffect(() => {
    if(!isLoading) setIsRefresh(false)
  }, [isLoading])

  const _scrolled = () =>{
    setFlatListReady(true)
    }
    const backPress = useCallback(
      () => {
        dispatch(setIsShowBottomSheetAction(true))
        setTimeout(() => {
          navigation.goBack(); 
        }, 100);
      },
    [],
    )
    return (
    <MainContainer title={languages.docs_interaction} BackPressCustom={backPress}>
      <>
      {!arrayIsEmpty(interactiveDocsState) ?
                            <FlatList
                                contentContainerStyle={{
                                    paddingBottom: 30,
                                }}
                                onScroll={_scrolled}
                                extraData={interactiveDocsState}
                                data={interactiveDocsState}
                                renderItem={({ item, index }) => (
                                    <InteractiveDocItem
                                        item={item}
                                        index={index}
                                        gotoDetail={gotoDetailPress}
                                    />
                                )}
                                refreshControl={
                                  <RefreshControl refreshing={isRefresh} onRefresh={onRefresh} tintColor='#0054AE' />
                                }
                                keyExtractor={(item, index) => String(index)}
                                showsVerticalScrollIndicator={false}
                                onEndReached={handleLoadmore}
                                ListFooterComponent={renderFooter(isLoading, Offset)}
                                onEndReachedThreshold={0.5} />
                            : <NoDataView />
                        }
      </>
    </MainContainer>
  )
}

export default React.memo(InteractiveDocsScreen)

const styles = StyleSheet.create({
  container:{
    flex: 1,
    backgroundColor: colors.white
  },
  itemContainer:{
    height: 70,
    flexDirection: 'row',
    padding: 10,
    alignItems: 'center',
    backgroundColor: colors.white
  },
  textTitle: { color: colors.black_121, fontSize: FontSize.LARGE,fontWeight: '400', fontFamily: FontFamily.HERITAGE_REGULAR },
  textContent: { color: colors.black_121, fontSize: FontSize.SMALL,fontWeight: '400', fontFamily: FontFamily.HERITAGE_REGULAR },
  textContentSmall: { color: colors.black_7b, fontSize: FontSize.SMALL1,fontWeight: '400', fontFamily: FontFamily.HERITAGE_REGULAR },
  itemThumbnail: {
    height: 42,
    width: 32,
    margin: 10,
    borderRadius: 0
  },
  flexDirectionRow:{
    flexDirection: 'row',
    flex: 1,
    justifyContent: 'space-between'
  },
  itemChildRight: {
    flex: 1,
    alignItems: 'center'
   }
})