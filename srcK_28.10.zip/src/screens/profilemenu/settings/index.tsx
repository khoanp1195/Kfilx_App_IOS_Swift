import { useFocusEffect } from '@react-navigation/native';
import Header from 'components/Header';
import TextCusTom from 'components/TextCusTom';
import colors from 'helpers/Colors';
import { FontFamily, FontSize } from 'helpers/Constants';
import { arrayIsEmpty } from 'helpers/Functions';
import React, { useCallback, useEffect, useState } from 'react';
import { View, Switch, StyleSheet, FlatList } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from 'stories/index';
import { getConfigNotification, postSaveUserConfigNotification } from 'stories/settings/reducer';
import uuid from 'react-native-uuid';
import MainContainer from 'components/MainContainer';
import { setIsShowBottomSheetAction } from 'stories/dashboard/reducer';

const SettingItem = ({ item, index, toggleSwitchNoti, toggleSwitchEmail }: any) => {
    const { Title, id, isEnabledEmail, isEnabledNoti, switch_email } = item;
    const isOdd = index % 2
    return (
        <View style={[styles.settingItem, { backgroundColor: isOdd ? colors.light_grayish : colors.white_blue }]}>
            <TextCusTom style={styles.itemTitle} i18nKey={Title} numberOfLines={2} />
            <View style={styles.viewRight}>
                <View style={{ marginRight: 5, width: 70 }}>
                    <Switch
                        trackColor={{ false: colors.grey_da, true: colors.blue_switch_on }}
                        thumbColor={colors.white}
                        onValueChange={() => toggleSwitchNoti(item)}
                        value={isEnabledNoti}
                    />
                </View>
                <View style={{ width: 70 }}>
                    <Switch
                        trackColor={{ false: colors.grey_da, true: colors.blue_switch_on }}
                        thumbColor={colors.white}
                        onValueChange={() => toggleSwitchEmail(item)}
                        value={isEnabledEmail}
                        disabled={switch_email}
                    />
                </View>
            </View>
        </View>
    )
};
const HeaderSetting = () => {

    return (
        <View style={styles.headerContainer}>
            <TextCusTom i18nKey={'Notifications'} style={styles.textHeader} />
            <TextCusTom i18nKey={'Email'} style={styles.textHeader} />
        </View>
    )
};
const App = ({navigation}: any) => {
    const {languages,languagesText } = useSelector((state: RootState) => state.languages);
    const {configSettings } = useSelector((state: RootState) => state.settings);
    const [setingData, setSetingData] = useState([]);
    const dispatch = useDispatch<any>();
    const {NotifyCategoryId, EmailCategoryId} = configSettings
    useFocusEffect(
        React.useCallback(() => {
          const langId = languagesText === 'EN' ? 1033 :1066
          dispatch(getConfigNotification(langId));
        }, [languagesText])
      );
        useEffect(() => {
        if(!arrayIsEmpty(configSettings.data)){
            const isEnabledNoti = NotifyCategoryId > 0

            const newData = configSettings.data.map((it: any) => {
                const newIt ={...it,id:uuid.v4().toString(), switch_email: it.IsConfig !== 3 ? true : false,isEnabledNoti:isEnabledNoti, isEnabledEmail:  it.IsConfig > 2 ? true : false}
                return newIt;
            })
            setSetingData(newData);
        }
        }, [configSettings])
        
    const toggleSwitchNoti = useCallback((item: any) => {
        const {id,ID} = item;
        const data = setingData.map(it => {
            const newIt = it.id === id ? { ...it, isEnabledNoti: !it.isEnabledNoti } : it
            return newIt
        })
        setSetingData(data);
        dispatch(postSaveUserConfigNotification({NotifyCategoryId:NotifyCategoryId +ID, EmailCategoryId : EmailCategoryId }))
    },
        [setingData],
    )
    const toggleSwitchEmail = useCallback((item: any) => {
        const {id, ID} = item;
        const data = setingData.map(it => {
            const newIt = it.id === id ? { ...it, isEnabledEmail: !it.isEnabledEmail } : it
            return newIt
        })
        dispatch(postSaveUserConfigNotification({NotifyCategoryId:NotifyCategoryId, EmailCategoryId : EmailCategoryId + ID}))
        setSetingData(data);
    }, [setingData],
    )

    const backPress = useCallback(
        () => {
          dispatch(setIsShowBottomSheetAction(true))
          setTimeout(() => {
            navigation.goBack(); 
          }, 100);
        },
      [],
      )
      return (
      <MainContainer title={languages.setting_remind_noti} BackPressCustom={backPress}>
            <HeaderSetting />
            <FlatList
                data={setingData}
                extraData={setingData}
                renderItem={({ item, index }) => (
                    <SettingItem
                        item={item} index={index}
                        toggleSwitchEmail={(id) => toggleSwitchEmail(id)}
                        toggleSwitchNoti={(id) => toggleSwitchNoti(id)} />
                )
                }

                keyExtractor={item => item.id}
            />
        </MainContainer>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
    },
    settingItem: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        height: 70,
        paddingHorizontal: 15
    },
    viewLeft: {
    },
    viewRight: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    itemTitle: {
        flex: 1,
        color: colors.black_121,
        fontSize: FontSize.SMALL,
        fontWeight: '400',
        fontFamily: FontFamily.HERITAGE_REGULAR,
    },
    textHeader: {
        color: colors.black_121,
        fontSize: FontSize.SMALL,
        fontWeight: '400',
        fontFamily: FontFamily.HERITAGE_REGULAR,
        width: 70,
        textAlign: 'center'
    },
    headerContainer: {
        paddingTop: 10,
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
    }
});

export default App;