import React, { useCallback, useState } from 'react';
import { View, Switch, StyleSheet, FlatList } from 'react-native';
import { WINDOW_WIDTH } from '@gorhom/bottom-sheet';
import Header from 'components/Header';
import TextCusTom from 'components/TextCusTom';
import colors from 'helpers/Colors';
import { FontFamily, FontSize } from 'helpers/Constants';

import { TouchableOpacity } from 'react-native-gesture-handler';
import { useSelector } from 'react-redux';
import { RootState } from 'stories/index';
import AllNotificaitonScreen from './AllNotificaitonScreen'
import UnReadNotificaitonScreen from './UnReadNotificaitonScreen'
import MainContainer from 'components/MainContainer';

const TopTab = ({activeTab,onChangeActiveStatus, unread, all}: any) => {

    return (
        <View style={styles.headerContainer}>
            <TouchableOpacity style={[styles.tabView,activeTab === 1 && {backgroundColor:colors.white}]} onPress={() => onChangeActiveStatus(1)} >
            <TextCusTom i18nKey={all} style={[styles.textHeader,activeTab === 1 && {color: colors.DarkCyan}]} />
            </TouchableOpacity>
            <TouchableOpacity style={[styles.tabView,activeTab === 2 && {backgroundColor:colors.white}]}onPress={() => onChangeActiveStatus(2)} >
            <TextCusTom i18nKey={unread} style={[styles.textHeader,activeTab === 2 && {color: colors.DarkCyan}]} />
            </TouchableOpacity>
        </View>
    )
};
const App = () => {
    const {languages } = useSelector((state: RootState) => state.languages);
    const [activeStatus, setactiveStatus] = useState(1)
    const onChangeActiveStatus = useCallback(
      (status) => {
        setactiveStatus(status)
      },
      [activeStatus],
    )
    
    return (
        <View style={styles.container}>
            <Header title={languages.notification} />
            <TopTab activeTab={activeStatus} onChangeActiveStatus={onChangeActiveStatus} unread={languages.unread} all={languages.all}/>
          <MainContainer isShowLeftButton={false}>
          {
            activeStatus === 1 ?
            <AllNotificaitonScreen />
            :
            <UnReadNotificaitonScreen />
           }
          </MainContainer>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor: colors.white
    },

    textHeader: {
        color: colors.black_121,
        fontSize: FontSize.SMALL,
        fontWeight: '400',
        fontFamily: FontFamily.HERITAGE_REGULAR,
        paddingTop: 5
    },
    headerContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent:'center',
        height: 40,
        backgroundColor: colors.light_grayish,
        marginVertical: 10,
        marginHorizontal: 15,
        borderRadius: 30,
    },
    tabView: {
        width: WINDOW_WIDTH /2 -20,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 30,
        margin: 2,
        height: 34,
    }
});

export default App;