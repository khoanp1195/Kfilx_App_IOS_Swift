import { WINDOW_WIDTH } from '@gorhom/bottom-sheet';
import { useFocusEffect } from '@react-navigation/native';
import NoDataView from 'components/NoDataView';
import TextCusTom from 'components/TextCusTom';
import colors from 'helpers/Colors';
import { FontFamily, FontSize, windowWidth } from 'helpers/Constants';
import { arrayIsEmpty, isNullOrUndefined } from 'helpers/Functions';
import React, { useCallback, useEffect, useState } from 'react';
import { View, Switch, StyleSheet, FlatList, RefreshControl, ActivityIndicator } from 'react-native';
import FastImage from 'react-native-fast-image';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from 'stories/index';
import { getUnreadNotificationList } from 'stories/notifications/reducer';
import HTML from "react-native-render-html";

const renderFooter = (loading: boolean,Offset: number) => {
    if(Offset < 20 || !loading  ) return null
    return (
        <View style={{
            padding: 10,
            justifyContent: 'center',
            alignItems: 'center',
            flexDirection: 'row',
        }}>
                <ActivityIndicator color="blue" style={{ marginLeft: 8 }} />
        </View>
    );
  };
  const NotificationListItem = ({ item, index, langId }: any) => {
    const { Content,ActionTime } = item;
    const isOdd = index % 2
    const customHTMLElementModels = {
        label: {
            contentModel: 'flow', // Set the content model as 'flow' or 'block' as appropriate
            isOpaque: true, // Set to true if this element contains its own children
        },
    };
    return (
        <View style={[styles.NotificationListItem, { backgroundColor: isOdd ? colors.light_grayish : colors.white_blue }]}>
            <FastImage source={require('assets/images/icon_notification.png')} style={styles.iconNotification}/>
            <View style={styles.viewRight}>
            <HTML source={{html: langId !== 'EN'?item.Content:item.ContentEN}} contentWidth={windowWidth}
                        // @ts-ignore
                          customHTMLElementModels={customHTMLElementModels}
                          ignoredDomTags={['label']}
                    />
            <TextCusTom style={styles.itemTitle} i18nKey={ActionTime } numberOfLines={2} />
            </View>
        </View>
    )
};

const App = () => {
    const {languages,languagesText } = useSelector((state: RootState) => state.languages);
    const {unreadNotificationList, } = useSelector((state: RootState) => state.notification);
    const dispatch = useDispatch<any>();
    const [isRefresh, setIsRefresh] = useState(false)
    const {isLoading, totalRecord} = unreadNotificationList
    const [notificationListState, setnotificationListState] = useState([])
    const [Offset, setOffset] = useState(0)

    useFocusEffect(
        React.useCallback(() => {
          dispatch(getUnreadNotificationList(Offset));
        }, [Offset])
      );
      useEffect(() => {
        if(!isNullOrUndefined(unreadNotificationList.data)){
          setnotificationListState(unreadNotificationList.data);
        }
      }, [unreadNotificationList])
      const handleLoadmore = async() => {
        if (unreadNotificationList.data.length < totalRecord && !isLoading) {
            setOffset(unreadNotificationList.data.length);
        }
       }
      const onRefresh = useCallback(() => {
        if (!isLoading) {
            setIsRefresh(true)
            setOffset(0);
           dispatch(getUnreadNotificationList(0));
        }
    }, [languagesText])

    return (
         <>
              {
                arrayIsEmpty(notificationListState) ?
                <NoDataView />
                :
                <FlatList
                contentContainerStyle={{paddingBottom: 30}}
                data={notificationListState}
                extraData={notificationListState}
                renderItem={({ item, index }) => (
                    <NotificationListItem
                        item={item} index={index}
                        langId ={languagesText}
                        />
                )
                }
                refreshControl={
                    <RefreshControl refreshing={isRefresh} onRefresh={onRefresh} tintColor='#0054AE' />
                  }
                  onEndReached={handleLoadmore}
                  ListFooterComponent={renderFooter(isLoading, Offset)}
                  onEndReachedThreshold={0.5}
                keyExtractor={item => item.ID}
            />
              }
         </>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
    },
    NotificationListItem: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        height: 70,
        paddingHorizontal: 15
    },
    viewLeft: {
    },
    viewRight: {
   
    },
    itemTitle: {
        color: colors.black_121,
        fontSize: FontSize.SMALL,
        fontWeight: '400',
        fontFamily: FontFamily.HERITAGE_REGULAR,
        marginTop: 5,
        marginRight: 20
    },
    iconNotification:{
        height:32,
        width:32,
        marginRight:10,
        marginLeft: 20
    },

});

export default App;