
import React, { useCallback, useEffect, useState } from 'react';
import { FlatList, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { WebView } from 'react-native-webview';
import Header from 'components/Header'
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from 'redux-thunk';
import { getAutoLoginMobile } from 'stories/dashboard/reducer';
import { RootState } from 'stories/index';
import colors from 'helpers/Colors';
import { arrayIsEmpty, checkIsEmpty, format_dd_mm_yy, isNullOrUndefined } from 'helpers/Functions';
import { BASE_URL, FontSize, dimensWidth } from 'helpers/Constants';
import NoDataView from 'components/NoDataView';
import uuid from 'react-native-uuid';
import TextCusTom from 'components/TextCusTom';
import FastImageCustom from 'components/FastImageCustom';
import FastImage from 'react-native-fast-image';
import MainContainer from 'components/MainContainer';
import { addPositionStayFavourite, getlistFavouriteDocs } from 'stories/favourite/reducer';
import { WINDOW_WIDTH } from '@gorhom/bottom-sheet';

type Props = {
    navigation: any
    route: any
}

const FavouriteDocumentViewItem = ({gotoDetail, item}: any) => {

  return (
    <View style={styles.itemContainer}>
        <TouchableOpacity onPress={() =>gotoDetail(item)} style={styles.itemTouchContainer}>
        <FastImage source={require('assets/images/favorite.png')} style={styles.imgThumbnail} resizeMode={ FastImage.resizeMode.contain}/>
        </TouchableOpacity>
      <TextCusTom i18nKey={item?.Title} style={styles.cap1} numberOfLines={1}/>
      <TextCusTom i18nKey={item?.Description} style={styles.cap2} numberOfLines={2}/>
    </View>
  )
}

const FavouriteScreen = ({route, navigation}: Props) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const {languages,languagesText } = useSelector((state: RootState) => state.languages);
    const {listFavouriteDocs} = useSelector((state: RootState) => state.favourite);
    const [listFavouriteDocsState, setlistFavouriteDocsState] = useState([])

    useEffect(() => {
        const langId = languagesText === 'EN' ? 1033 :1066
        const Offset = 0
     dispatch(getlistFavouriteDocs())
    }, [languagesText])
    const gotoDetailPress = useCallback(
      (item: any) => {
        dispatch(addPositionStayFavourite(item))
      },
    [listFavouriteDocs],
    )
    useEffect(() => {
      if(!isNullOrUndefined(listFavouriteDocs)){
        setlistFavouriteDocsState(listFavouriteDocs.filter(it => !it.ParentId));
        // alert(listFavouriteDocs.data.length)
      }
    }, [listFavouriteDocs])

  return (
    <MainContainer title={languages.bottomtab_favourite}>
       <View style={styles.container}>
       {!arrayIsEmpty(listFavouriteDocsState) ? (
<FlatList
contentContainerStyle={styles.containerFlatList}
data={listFavouriteDocsState}
extraData={listFavouriteDocsState}
numColumns={2}
renderItem={({ item }) => (
  <FavouriteDocumentViewItem item={item} gotoDetail={gotoDetailPress} />
)}
showsHorizontalScrollIndicator={false}
keyExtractor={(item: any, index) => uuid.v4().toString() }
/>
) : (
<NoDataView />
)}
       </View>
      </MainContainer>
  );
}

export default FavouriteScreen

const styles = StyleSheet.create({
  container:{
     flex: 1,
  },
    containerFlatList:{
    marginTop: 20,
    },
    itemContainer:{
        width: WINDOW_WIDTH / 2,
        alignItems: 'center',
    },
    itemTouchContainer:{
        width: dimensWidth(120),
        height: dimensWidth(120),
        marginLeft: 20,
        marginBottom: 20,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#E2F9FF',
    },
    imgThumbnail:{
        height: 74,
        width: 55,
        borderRadius: 3,
    },
    cap1:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey26,
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'center',
        paddingHorizontal: 10
    },
    cap2:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey_7b,
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'center',
        paddingHorizontal: 10
    }
})