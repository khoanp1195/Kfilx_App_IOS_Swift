import React, { useEffect } from 'react';
import { useDispatch, useSelector} from "react-redux";
import FavouriteScreen from "./FavouriteScreen";
import FavouriteDetail from "./FavouriteDetail";
import { removeAllPositionStayFavourite } from 'stories/favourite/reducer';
import { ThunkDispatch } from 'redux-thunk';
import { useFocusEffect } from '@react-navigation/native';

const RootFavouriteScreen= ({navigation, route}: any) =>{
    const {positionStayFavourite} = useSelector((state: any) => state.favourite);
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();

  useFocusEffect(
    React.useCallback(() => {
     dispatch(removeAllPositionStayFavourite())
    }, [])
  );
  return(
    <>
    {
      positionStayFavourite.length === 0 ?
      <FavouriteScreen  navigation={navigation} route={route}/>
      :
      <FavouriteDetail navigation={navigation} route={route}/>
    }
  </>
  )
}
export default RootFavouriteScreen
