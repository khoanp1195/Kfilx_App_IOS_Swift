
import React, { useCallback, useEffect, useState } from 'react';
import { Dimensions, FlatList, StyleSheet, Animated, TouchableOpacity, View,TouchableWithoutFeedback, RefreshControl, ActivityIndicator } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from 'redux-thunk';
import { getAutoLoginMobile } from 'stories/dashboard/reducer';
import { RootState } from 'stories/index';
import colors from 'helpers/Colors';
import { arrayIsEmpty, checkIsEmpty, format_dd_mm_yy, isNullOrUndefined } from 'helpers/Functions';
import { BASE_URL, FontSize, dimensWidth } from 'helpers/Constants';
import HeaderWebView from 'components/HeaderWebView';
import { addPositionStayFavourite, getListDocumentFavourite, removeLastPositionStayFavourite } from 'stories/favourite/reducer';
import NoDataView from 'components/NoDataView';
import uuid from 'react-native-uuid';
import TextCusTom from 'components/TextCusTom';
import FastImageCustom from 'components/FastImageCustom';
import FastImage from 'react-native-fast-image';
import { WINDOW_WIDTH } from '@gorhom/bottom-sheet';
import { RightIcon } from 'assets/svg';
import MainContainer from 'components/MainContainer';
// import Animated from 'react-native-reanimated';

type Props = {
    navigation: any
    route: any
}
const renderFooter = (loading: boolean,Offset: number) => {
  if(Offset < 20 || !loading  ) return null
  return (
      <View style={{
          padding: 10,
          justifyContent: 'center',
          alignItems: 'center',
          flexDirection: 'row',
      }}>
              <ActivityIndicator color="blue" style={{ marginLeft: 8 }} />
      </View>
  );
};
const LeftMenuItem = ({gotoDetail, item, index}: any) => {
 
  return (
    <TouchableOpacity onPress={() =>gotoDetail(item)}>

        <View style={styles.itemLeftMenu}>
        <FastImageCustom urlOnline={item?.Thumbnail} styleImg={styles.imgThumbnailLeftMenu}/>
        <View style={[styles.leftMenu]}>
        <TextCusTom i18nKey={item?.Title} style={[styles.textLeftMenu]} numberOfLines={1}/>
        <RightIcon />
        </View>
        </View>
    </TouchableOpacity>

  )
}
const FavouriteSnareItem = ({gotoDetail, item, index}: any) => {
    const formatDate = format_dd_mm_yy(item?.Created)
    const isOdd = index % 2
  return (
    <TouchableOpacity onPress={() =>gotoDetail(item)}>
    <View style={[styles.itemContainer,!isOdd && {marginRight: dimensWidth(0)}]}>
        <View style={styles.itemChildContainer}>
        <FastImageCustom urlOnline={item?.Thumbnail} styleImg={styles.imgThumbnail} resizeMode={FastImage.resizeMode.stretch}/>
        </View>
     <>
     <TextCusTom i18nKey={item?.ResourceTitle} style={[styles.cap1]} numberOfLines={2}/>
      <TextCusTom i18nKey={formatDate} style={[styles.cap2]} numberOfLines={2}/>
     </>
    </View>
    </TouchableOpacity>

  )
}
const FavouriteNotSnareItem = ({gotoDetail, item, index}: any) => {
    const formatDate = format_dd_mm_yy(item?.Created)
    const isOdd = index % 2
  return (
    <View style={[styles.itemNotSnareContainer,!isOdd && {backgroundColor:colors.light_cyan}]}>
        <TouchableOpacity onPress={() =>gotoDetail(item)}>
        <FastImageCustom urlOnline={item?.Thumbnail} styleImg={styles.imgThumbnailNotSnare} resizeMode={FastImage.resizeMode.stretch}/>
        </TouchableOpacity>
     <View style={{flex: 1,}}>
     <View style={styles.rowBetween}>
     <TextCusTom i18nKey={item?.Title} style={styles.cap1} numberOfLines={1}/>
     </View>
     <View style={styles.rowBetween}>
     <TextCusTom i18nKey={item?.ResourceTitle} style={styles.contentNotSnare} numberOfLines={2}/>
     <TextCusTom i18nKey={formatDate} style={styles.cap2} numberOfLines={2}/>
     </View>
     </View>
    </View>
  )
}

const FavouriteDetailScreen = ({route, navigation}: Props) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const {languages,languagesText } = useSelector((state: RootState) => state.languages);
    const {listDocumentFavourite,positionStayFavourite,listFavouriteDocs} = useSelector((state: RootState) => state.favourite);
    const [listDocumentFavouriteState, setlistDocumentFavouriteState] = useState([])
    const [isShowDrawview, setIsShowDrawview] = useState(false);
    const [isSnare, setIsSNare] = useState(true);
    const current = new Animated.Value(0);
    const [progress, setProgress] = useState(new Animated.Value(0));
    const [listLeftMenu, setlistLeftMenu] = useState([])
    const [titleHeader, setTitleHeader] = useState("") 
    const [Offset, setOffset] = useState(0)
    const [isRefresh, setIsRefresh] = useState(false)
    const [folderIdState, setFolderIdState] = useState(0)
    const {isLoading, totalRecord} = listDocumentFavourite;

    const fetchData = useCallback(
      ( Offset: any,FolderId: number) => {
        dispatch(getListDocumentFavourite({Offset,FolderId}))
      },
    [],
    )

    useEffect(() => {
        if(positionStayFavourite.length > 0 &&  !isNullOrUndefined(listFavouriteDocs)) {
          const FolderId = positionStayFavourite[positionStayFavourite.length-1].ID
          setFolderIdState(FolderId)
          setTitleHeader(positionStayFavourite[positionStayFavourite.length-1].Title)
          setlistLeftMenu(listFavouriteDocs.filter((it: any) => it.ParentId === FolderId))
          fetchData( Offset, FolderId)
        }
    }, [languagesText, positionStayFavourite,listFavouriteDocs])
    
    const handleClickLeftMenu = useCallback(
        (item: any) => {
          dispatch(addPositionStayFavourite(item))
          setIsShowDrawview(false)
        },
      [],
      )
    const backPress = useCallback(
        () => {
          dispatch(removeLastPositionStayFavourite())
          setIsShowDrawview(false)
        },
      [positionStayFavourite],
      )
    const gotoDetailPress = useCallback(
        (item: any) => {
          dispatch(getAutoLoginMobile());
          navigation.navigate({
            name: "DetailScreen",
            params: {item},
          });
        },
      [],
      )

      useEffect(() => {
        if(!arrayIsEmpty(listDocumentFavourite.data)){
          setlistDocumentFavouriteState(listDocumentFavourite.data)
        }
      }, [listDocumentFavourite])

    
      const handlePressDrawView = useCallback(
        () => {
          if(isShowDrawview){
            setIsShowDrawview(false)
          }else{
            setIsShowDrawview(true)
          }
          Animated.parallel([
            Animated.timing(current, {
                toValue:  0,
                duration:300,
                useNativeDriver:false,
            }),
        Animated.timing(progress, {
            toValue:1,
            duration:300,
            useNativeDriver:false
        })
        ]).start(()=>{
          isShowDrawview ? progress.setValue(0) : progress.setValue(1) 
        })

        },
        [isShowDrawview],
      )
      const handleCloseDrawView = useCallback(
        () => {
          setIsShowDrawview(false)
        },
        [],
      )
      const handleLoadmore = async() => {
        if (listFavouriteDocs.length < totalRecord && !isLoading) {
            setOffset(listFavouriteDocs.length);
        }
       }
      const onRefresh = useCallback(() => {
        if (!isLoading) {
            setIsRefresh(true)
            setOffset(0);
            fetchData(languagesText,0,folderIdState)
        }
    }, [languagesText])

      const progressAnim=progress.interpolate({
        inputRange:[0, 1],
        outputRange:["0%", "80%"],
    });

    const drawWidth={
        width:progressAnim
    }
  return (
      <MainContainer BackPressCustom={backPress}>
        <HeaderWebView title={titleHeader} onPressAvatar={handlePressDrawView} isSnare={isSnare} onNnareChange ={() => setIsSNare(!isSnare)}/>
       <View style={styles.container}>

{ isShowDrawview&&
   <View  style={styles.drawView}>
   <Animated.View style={[styles.aniamtedView, drawWidth]}>
    {listLeftMenu.length> 0 ?
    <FlatList
    contentContainerStyle={{flexGrow: 1}}
   data={listLeftMenu}
   extraData={listLeftMenu}
   showsVerticalScrollIndicator={false}
   renderItem={({ item ,index}) => (
   <LeftMenuItem item={item} gotoDetail={handleClickLeftMenu} index={index}/>
   )}
   showsHorizontalScrollIndicator={false}
   keyExtractor={(item: any, index) => uuid.v4().toString() }
   />
   :
      <NoDataView />}
    </Animated.View>
    <TouchableWithoutFeedback style={styles.closeDrawView}  onPress={handleCloseDrawView}>
      <View style={styles.closeDrawView}/>
    </TouchableWithoutFeedback>
    </View>
}
<View>

{isSnare ?
  <FlatList
  key={'snare'}
contentContainerStyle={styles.containerFlatList}
data={listDocumentFavouriteState}
showsVerticalScrollIndicator={false}
extraData={listDocumentFavouriteState}
numColumns={2}
renderItem={({ item,index }) => (
<FavouriteSnareItem item={item} gotoDetail={gotoDetailPress} index={index}/>
)}
showsHorizontalScrollIndicator={false}
keyExtractor={(item: any, index) => uuid.v4().toString() }
/>
:
<FlatList
 key={'not_snare'}
data={listDocumentFavouriteState}
extraData={listDocumentFavouriteState}
showsVerticalScrollIndicator={false}
renderItem={({ item ,index}) => (
<FavouriteNotSnareItem item={item} gotoDetail={gotoDetailPress} index={index}/>
)}
keyExtractor={(item: any, index) => uuid.v4().toString() }
refreshControl={
  <RefreshControl refreshing={isRefresh} onRefresh={onRefresh} tintColor='#0054AE' />
}
onEndReached={handleLoadmore}
ListFooterComponent={renderFooter(isLoading, Offset)}
onEndReachedThreshold={0.5} />
}
</View>
       </View>
  </MainContainer>
  );
}

export default FavouriteDetailScreen

const styles = StyleSheet.create({
  container:{
    flex: 1,
 },
    containerFlatList:{
      flexGrow: 1,
     marginTop: 20,
     paddingBottom: 20
    },
    itemLeftMenu:{
      flexDirection:'row',
        justifyContent: 'center',
        alignItems: 'center',
        paddingLeft: 20,
        paddingTop: 10
    },
    imgThumbnailLeftMenu:{
      height:20,
      width: 20,
      borderRadius: 3,
  },
  textLeftMenu:{
    fontSize: FontSize.SMALL,
    color: colors.text_grey_7b,
    fontWeight: '400',
    marginTop: 7,
    flex: 1,
    marginBottom: 10
},
leftMenu:{
  flexDirection:'row',
    flex: 1,
    borderBottomWidth:0.5,
    borderBottomColor: colors.grey_co,
    paddingRight: 20
},
    itemContainer:{
        width: WINDOW_WIDTH / 2,
        marginBottom: 20,
        justifyContent: 'center',
        alignItems: 'center',
    },
    viewItemContent:{
    },
    itemChildContainer:{
        width: dimensWidth(160),
        height:dimensWidth(200),
        justifyContent: 'center',
        alignItems: 'center',
    },
    itemNotSnareContainer:{
        paddingStart: 20,
        paddingBottom: 10,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection:'row',
        backgroundColor: colors.white
    },
    rowBetween:{
      justifyContent: 'space-between',
      alignItems: 'center',
      flexDirection:'row'
    },
    imgThumbnail:{
      width: dimensWidth(160),
      height:dimensWidth(200),
    },
    imgThumbnailNotSnare:{
        height: 42,
        width: 32,
        borderRadius: 3,
    },
    cap1:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey26,
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'center',
        paddingHorizontal: 20,
    },
    cap2:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey_7b,
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'center',
    },

    contentNotSnare:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey26,
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'left',
        paddingLeft:10,
        flex: 1,
    },
    drawView: {
      flex: 1,
      zIndex: 999,
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.333333)',
      justifyContent: 'center',
      flexDirection:'row'
    },
    aniamtedView:{
      flex:4,
      backgroundColor: colors.white,
      zIndex: 9999,
    },
    closeDrawView:{
      flex: 1,
      zIndex: 99,
      backgroundColor:'transparent'
    }
})