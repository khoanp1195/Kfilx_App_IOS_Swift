import { BASE_URL, subsiteStore } from "../../config/constants";
import DeviceInfo from "react-native-device-info";
import axios from "axios";
import RNFS from "react-native-fs"; // Import RNFetchBlob if you still need it
import { PermissionsAndroid, Platform } from 'react-native';
import RNFetchBlob from 'react-native-fetch-blob';

async function checkAndRequestStoragePermissions() {
    // Kiểm tra xem quyền READ_EXTERNAL_STORAGE đã được cấp chưa
    const readStorageGranted = await PermissionsAndroid.check(PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE);

    // Kiểm tra xem quyền WRITE_EXTERNAL_STORAGE đã được cấp chưa
    const writeStorageGranted = await PermissionsAndroid.check(PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE);

    if (!readStorageGranted || !writeStorageGranted) {
        // Nếu một hoặc cả hai quyền chưa được cấp, thì yêu cầu chúng từ người dùng
        try {
            const granted = await PermissionsAndroid.requestMultiple([
                PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE,
                PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
            ]);

            if (
                granted[PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE] === PermissionsAndroid.RESULTS.GRANTED &&
                granted[PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE] === PermissionsAndroid.RESULTS.GRANTED
            ) {
                console.log('Quyền truy cập lưu trữ đã được cấp.');
                // Gọi hàm để thực hiện tác vụ liên quan đến lưu trữ ở đây
                return true;
            } else {
                console.log('Không cấp quyền truy cập lưu trữ.');
                return false;
            }
        } catch (err) {

            console.warn(err);
            return false;
        }
    } else {
        console.log('Ứng dụng đã có quyền truy cập lưu trữ.');
        return true;
        // Gọi hàm để thực hiện tác vụ liên quan đến lưu trữ ở đây
    }
}
const downloadPDF = async (document: any, guid: any) => {
    try {
        // const isPermission = checkAndRequestStoragePermissions();
        if (true) {
            const fileInfo = {
                Title: document.FileTitle,
                Url: document.FileUrl,
                ID: document.FileID,
            };

            const files = [fileInfo];

            const deviceInfo = {
                DeviceOS: DeviceInfo.getSystemName(),
                DeviceOSVersion: DeviceInfo.getSystemVersion(),
                DeviceModel: DeviceInfo.getModel(),
                DeviceName: '',
            };
            deviceInfo.DeviceName = await DeviceInfo.getDeviceName();
            const metaObj = {
                Title: document.Title,
                Description: '',
                ResourceUrl: document.Url,
                ResourceCategoryId: document.ResourceCategoryId,
                ResourcesubCategoryId: document.ResourceSubCategoryId,
                ResourceId: document.PrimaryKey,
                PostTime: new Date(),
                UserAgent: '',
                FlgUpdateData: 1,
                AppName: 'Mobile Android',
                Platform: `${deviceInfo.DeviceOS} ${deviceInfo.DeviceOSVersion}`,
                CodeName: deviceInfo.DeviceModel,
                DeviceName: deviceInfo.DeviceName,
                IP: '',
            };

            const encodedFiles = encodeURIComponent(JSON.stringify(files));
            const encodedMetaObj = encodeURIComponent(JSON.stringify(metaObj));

            const url =
                `/api/download.ashx?func=download` +
                `&tbl=documentattachfiles` +
                `&data=${encodedFiles}` +
                `&code=${document.Title.replace('_', '')}` +
                `&isarchive=${document.IsArchived > 0 ? String(document.IsArchived) : ''}` +
                `&byurl=1` +
                `&MetaObj=${encodedMetaObj}` +
                `&ispilot=${document.IsPilot ? '1' : '0'}`;

            const downloadURL = `https://vnadmsuatportal.vuthao.com/psd${url}`;
            const response = await axios.get(downloadURL, {
                responseType: 'arraybuffer',
            });
            // const { fs, config } = RNFetchBlob;
            // const { dirs } = RNFetchBlob.fs;
            // const downloadDir = Platform.OS == 'ios' ? dirs.DocumentDir : dirs.DownloadDir
            const filePath = `${RNFS.DocumentDirectoryPath}/${guid}.pdf`;
            // await RNFS.mkdir(`${downloadDir}`);
            await RNFS.writeFile(filePath, response.request._response, 'base64');
            return filePath;
        }
    } catch (error) {
        console.error(error);
        return '';
    }
};

export default downloadPDF;
