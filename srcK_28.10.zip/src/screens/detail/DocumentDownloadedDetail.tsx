
import React from 'react';
import {StyleSheet, View } from 'react-native';
import { WebView } from 'react-native-webview';
import colors from 'helpers/Colors';
import { isNullOrUndefined } from 'helpers/Functions';
import HeaderWebView from 'components/HeaderWebView';
import MainContainer from 'components/MainContainer';

type Props = {
    navigation: any
    route: any
}
// ...
const DashboardDetail = ({route, navigation}: Props) => {
    const {item} = route.params
 
  return (
    <View style={{ flex: 1,backgroundColor: colors.white }}>
        <MainContainer>
        <HeaderWebView title={item?.Title} isRight={false} isLeft={false}/>
        {/* <DocumentPdfTypeScreen item={item} /> */}
        {
          !isNullOrUndefined(item.path) &&
          <WebView source={{ uri:  decodeURIComponent("file://" + item.path) }} 
          style={{flex: 1 }}
          setUseWideViewPort={true}
          javaScriptEnabled={true}
          allowFileAccess={true}
          originWhitelist={['*']}
          // @ts-ignore
          setSupportMultipleWindows={false}
          />
         }
        </MainContainer>

    </View>
  );
}

export default DashboardDetail

const styles = StyleSheet.create({})