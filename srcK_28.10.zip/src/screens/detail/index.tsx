
import React, { useCallback, useEffect, useState } from 'react';
import { Alert, Platform, StyleSheet, View } from 'react-native';
import { WebView } from 'react-native-webview';
import Header from 'components/Header'
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from 'redux-thunk';
import { setDocumentsDownloadedListAction } from 'stories/dashboard/reducer';
import { RootState } from 'stories/index';
import colors from 'helpers/Colors';
import { arrayIsEmpty, checkAndRequestStoragePermissions, checkIsEmpty, checkMimeTypeFiles, getCurrentTimeFormatted, getExtension } from 'helpers/Functions';
import { BASE_URL } from 'helpers/Constants';
import HeaderWebView from 'components/HeaderWebView';
import RNFetchBlob from 'react-native-fetch-blob';
import { getDataViewDetailOffline } from './getDataViewDetailOffline';
import PDFView from 'react-native-view-pdf';
import LoadingView from 'components/LoadingView';

type Props = {
    navigation: any
    route: any
}
// ...
const DashboardDetail = ({route, navigation}: Props) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const {languages,languagesText } = useSelector((state: RootState) => state.languages);
    const {autoId, documentDownloadedList, htmlString } = useSelector((state: RootState) => state.dashboard);
    const [autoIdState, setAutoIdState] = useState(null)
    const [isDownloading, setIsDownloading] = useState(false)
    const {item} = route.params
    const downloadFile = async () => {
      const dataAttach = {
        Url: BASE_URL + item.Url
      }
      const { fs, config } = RNFetchBlob;
      const { dirs } = RNFetchBlob.fs;
      const downloadDir = dirs.DocumentDir
      const typeFile = getExtension(dataAttach?.Url)
      const mimeType = checkMimeTypeFiles(dataAttach?.Url);
      const filename = dataAttach?.Url.substring(dataAttach?.Url.lastIndexOf('/') + 1, dataAttach?.Url.length)
      const localPath = `${downloadDir}/${filename}`
      const options = {
        fileCache: true,
        // useDownloadManager: false,
        // notification: true,
        // mediaScannable: true,
        mime: mimeType,
        title: `${filename}`,
        path: localPath,
        description: 'Downloading file...',
      };
      const configOptions = {
        fileCache: options.fileCache,
        title: options.title,
        path: options.path,
        appendExt: typeFile,
      };
  
      config(configOptions)
        .fetch('GET', encodeURI(dataAttach?.Url))
        .then((res) => {
          alert("Tải tệp thành công!")
          RNFetchBlob.fs.writeFile(options.path, res.data, 'base64');
          RNFetchBlob.ios.previewDocument(options.path);
        })
        .catch((error) => {
          alert("Tải tệp thất bại!")
        });
    };
    useEffect(() => {
      setAutoIdState(autoId)
    }, [autoId])
    const downloadFiles = useCallback(
    async  (item: any) => {
      const isAllowFile = await checkAndRequestStoragePermissions();
      if(isAllowFile){
        setIsDownloading(true)
        let newData: any = documentDownloadedList;
        const langId = languagesText === 'EN' ? 1033 :1066
        const checkIsNotExistOrEmpty = (data: any) =>{
          if(arrayIsEmpty(data)) return true
          if(data.find((it: any) => it?.ID === item?.ID)){
            return false
          }
          return true
        }
        if(checkIsNotExistOrEmpty(newData)){
          getDataViewDetailOffline(item, langId).then(value => {
            newData = [{
              modified: getCurrentTimeFormatted(),
              path: value.path,  
              ...item
            }, ...newData];
            dispatch(setDocumentsDownloadedListAction(newData));
            Alert.alert(languages.notification,languages.download_completed)
            setIsDownloading(false)
      }).catch(e => {
        setIsDownloading(false)
        Alert.alert(languages.notification,languages.dowload_error)
      });
        }else{
          setIsDownloading(false)
          Alert.alert(languages.notification,languages.file_exist)
        }   
      }
      },
    [documentDownloadedList,languagesText,languages,item],
    )

  return (
    <View style={{ flex: 1,backgroundColor: colors.white }}>
        <Header /> 
        <HeaderWebView title={item?.Title} isRight={false} isLeft={false}/>
        {
          !checkIsEmpty(autoIdState)   &&
          <WebView 
          source={{ uri: `${BASE_URL}/psd/frontend/pages/VNADetailVB.aspx?rid=${item?.DocumentId}&gid=1&cid=3&Mobile=1&autoid=${autoIdState}&lang=${languagesText.toLowerCase()}` }} 
            style={{flex: 1 }}
          setUseWideViewPort={true}
          javaScriptEnabled={true}
          allowFileAccess={true}
          originWhitelist={['*']}
          // @ts-ignore
          setSupportMultipleWindows={false}
          onShouldStartLoadWithRequest={request => {           
            console.log('requestrequest',request);
             
            if (request.url.includes('download.ashx?func=download&tbl=documentattachfiles&data=')) {
            
              downloadFiles(route.params.item)
                return false;
            } else return true; 
        }}
          />
        }
  <LoadingView isLoading={isDownloading} />
    </View>
  );
}

export default DashboardDetail

const styles = StyleSheet.create({})