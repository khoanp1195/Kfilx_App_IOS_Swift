
import { Model } from '@nozbe/watermelondb';
import { field, writer } from '@nozbe/watermelondb/decorators';
import { TABLE } from '../contains';

export default class HomeFormModel extends Model {
    static table = TABLE.HOMEFORM;
    // @ts-ignore
    @field('notificationCount') notificationCount: unknown;
    // @ts-ignore
    @field('documentNewList') documentNewList: unknown;
    // @ts-ignore
    @field('recentlyViewedDocs') recentlyViewedDocs: unknown;
    // @ts-ignore
    @field('documentFavoriteList') documentFavoriteList: unknown;
    // @ts-ignore
    @field('documentMostViewList') documentMostViewList: unknown;
    // @ts-ignore
    @field('documentDownloadedList') documentDownloadedList: unknown;
    // @ts-ignore
    @writer async delete() {
        await super.destroyPermanently();
    }
    // @ts-ignore
    @writer async updateForm(body) {
        await this.update(form => {
            form.notificationCount = body.notificationCount;
            form.documentNewList = body.documentNewList;
            form.recentlyViewedDocs = body.recentlyViewedDocs;
            form.documentFavoriteList = body.documentFavoriteList;
            form.documentMostViewList = body.documentMostViewList;
            form.documentDownloadedList = body.documentDownloadedList;
        });
    }
}
