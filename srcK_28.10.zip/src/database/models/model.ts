import { Model } from '@nozbe/watermelondb';

export default class Home extends Model {
    static table = 'homeform';
}
