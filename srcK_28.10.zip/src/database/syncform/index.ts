
import { TABLE } from 'database/contains';
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from 'stories/index';
import { database } from '../../../App';
import { AppState } from 'react-native';
import { syncFormDashboardAction } from 'stories/dashboard/reducer';
import { checkIsEmpty, getTimeSyncForm, setTimeSyncForm } from 'helpers/Functions';
const SyncForm = () => {

    const { isAuth } = useSelector((state: RootState) => state.login);
    const dispatch = useDispatch<any>()
    const { notificationCount, recentlyViewedDocs, documentNewList, documentMostViewList, documentFavoriteList, documentDownloadedList } = useSelector((state: RootState) => state.dashboard);

    useEffect(() => {
        const createForm = async () => {
            const watermelonsCollection = database.get(TABLE.HOMEFORM);
            if (!watermelonsCollection) {
                await database.action(async () => {
                    watermelonsCollection.create((it: any) => {
                        it.documentNewList = ""
                        it.recentlyViewedDocs = ""
                        it.documentFavoriteList = ""
                        it.documentMostViewList = ""
                        it.documentDownloadedList = ""
                    });
                });
            }
        }
        createForm()
    }, [])

    useEffect(() => {
        const saveHomeForm = async () => {
            await database.write(async (tx) => {
                // Tìm phần tử đầu tiên trong cơ sở dữ liệu
                const watermelonsCollection = database.get(TABLE.HOMEFORM);
                const allRecords = await watermelonsCollection.query().fetch();
                // console.log('allRecordsallRecords', allRecords[0].documentNewList);

                if (allRecords.length > 0) {
                    const firstRecord = allRecords[0];

                    const arrayToSaveDocumentNewList = JSON.stringify(documentNewList);
                    const arrayToSaveRecentlyViewedDocs = JSON.stringify(recentlyViewedDocs);
                    const arrayToSaveDocumentFavoriteList = JSON.stringify(documentFavoriteList);
                    const arrayToSaveDocumentMostViewList = JSON.stringify(documentMostViewList);
                    const arrayToSaveDocumentDownloadedList = JSON.stringify(documentDownloadedList);

                    await firstRecord.update((record: any) => {
                        record.notificationCount = notificationCount;
                        record.documentNewList = arrayToSaveDocumentNewList;
                        record.recentlyViewedDocs = arrayToSaveRecentlyViewedDocs; // Đảm bảo bạn đã thay đổi giá trị này nếu cần
                        record.documentFavoriteList = arrayToSaveDocumentFavoriteList;
                        record.documentMostViewList = arrayToSaveDocumentMostViewList;
                        record.documentDownloadedList = arrayToSaveDocumentDownloadedList;
                    });

                }
            });
        }

        if (!checkIsEmpty(documentFavoriteList)) saveHomeForm();
    }, [documentMostViewList, documentNewList, documentDownloadedList, documentFavoriteList, notificationCount, recentlyViewedDocs]);

    const syncFormRequestApi = async () => {
        try {
            const allRecords: any = await database.get(TABLE.HOMEFORM).query().fetch();

            // Nếu bạn có nhiều bản ghi, bạn có thể sử dụng map để chuyển đổi chúng thành một mảng
            // Thực hiện phân tích mỗi bản ghi thành một đối tượng JavaScript
            const data = {
                documentNewList: JSON.parse(allRecords[0].documentNewList), // Thay field1 bằng tên trường thực tế của bạn
                recentlyViewedDocs: JSON.parse(allRecords[0].recentlyViewedDocs), // Thay field2 bằng tên trường thực tế của bạn
                documentFavoriteList: JSON.parse(allRecords[0].documentFavoriteList), // Thay field2 bằng tên trường thực tế của bạn
                documentMostViewList: JSON.parse(allRecords[0].documentMostViewList), // Thay field2 bằng tên trường thực tế của bạn
                documentDownloadedList: JSON.parse(allRecords[0].documentDownloadedList) // Thay field2 bằng tên trường thực tế của bạn
                // Thêm các trường khác nếu cần
            };
            console.log('datadatadata', data);

            dispatch(syncFormDashboardAction(data))
        } catch (error) {
            console.error('Error fetching and parsing data:', error);
        }
    };

    const syncFormStatusState = () => {
        syncFormRequestApi();
    };

    const syncFormAppState = async () => {
        try {
            const modified = await getTimeSyncForm();
            const milisecond = new Date() - new Date(modified);
            if (milisecond / 1000 > 3600) {
                syncFormRequestApi();
                setTimeSyncForm(new Date());
            }
        } catch (error) {
            //
        }
    };

    useEffect(() => {
        if (isAuth) {
            syncFormStatusState();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isAuth]);
    useEffect(() => {
        const subscription = AppState.addEventListener('change', nextAppState => {
            if (nextAppState === 'active') {
                syncFormAppState();
            }
        });

        return () => {
            subscription.remove();
        };
    }, []);

    return null;
}
export default SyncForm;