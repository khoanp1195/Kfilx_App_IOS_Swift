const TABLE = {
    HOMEFORM: 'HOMEFORM',
};

export { TABLE };
