import { appSchema, tableSchema } from '@nozbe/watermelondb';

import HomeFormSchema from './HomeFormSchema';

export const mySchema = appSchema({
  version: 1,
  // @ts-ignore
  tables: [tableSchema(HomeFormSchema)],
});
