import { TABLE } from '../contains';

const HomeFormSchema = {
    name: TABLE.HOMEFORM,
    columns: [
        { name: 'notificationCount', type: 'string' },
        { name: 'documentNewList', type: 'string' },
        { name: 'recentlyViewedDocs', type: 'string' },
        { name: 'documentFavoriteList', type: 'string' },
        { name: 'documentMostViewList', type: 'string' },
        { name: 'documentDownloadedList', type: 'string' },
    ],
};

export default HomeFormSchema;
