import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { BASE_URL, RESONSE_STATUS_SUCCESS } from 'helpers/Constants';
import { isNullOrUndefined } from 'helpers/Functions';

const getUsername = async () => {
  return await AsyncStorage.getItem('userName');
}
const getPassword = async () => {
  return await AsyncStorage.getItem('password')
}

export const callLogin = async (username: any, password: any) => {
  let data = new FormData();
  const jsonData = {
    UserName: username,
    Password: password,
  };
  data.append('data', JSON.stringify(jsonData));
  const response: any = await post(
    `/psd/api/ApiMobile.ashx?func=AdfsLogin`,
    data,
  );
  if (
    response.data.data != null &&
    response.data.data.includes('Login Success')
  ) {
    return response.data;
  } else {
    const response2: any = await post(
      `/psd/api/ApiMobile.ashx?func=AdfsLogin`,
      data,
    );
    if (
      response2.data.data != null &&
      response2.data.data.includes('Login Success')
    ) {
      return response2.data;
    } else {
      throw 101;
    }
  }
}
export const get = async (url: String) => {
  const response = await axios({
    method: 'get',
    url: BASE_URL + url,
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
    },
  });
  console.log('response', response);

  if (response.data.mess.Key == "998") {
    callLogin(await getUsername(), await getPassword()).then(_ => {
      get(url);
    });
  }
  return response;
};

export const post = async (url: String, data: any) => {
  var body = new FormData();
  body.append('data', JSON.stringify(data));
  const response = await axios({
    method: 'post',
    url: BASE_URL + url,
    data: body,
    headers: {
      Accept: 'application/json',
      'Content-Type': 'multipart/form-data',
    },
  });
  console.log('response', response);
  if (response.data.mess.Key == "998") {
    const userName = getUsername()
    const pass = getPassword()
    callLogin(userName, pass).then(_ => {
      post(url, data);
    });
  }
  return response;
};
export const getHTML = async (LCID: number, langid: number, data: any) => {
  const res = await post(
    `/psd/api/detail.ashx?tbl=document&func=viewoffline&LCID=${LCID}&langid=${langid}`,
    data
  );

  if (!isNullOrUndefined(res)) {
    if (res.data.status === RESONSE_STATUS_SUCCESS) {
      console.log("res.data.data", res.data.data)
      return res.data.data;
    } else {
      return null;
    }
  } else {
    return null;
  }
}