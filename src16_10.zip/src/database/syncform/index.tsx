
import { TABLE } from 'database/contains';
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from 'stories/index';
import { database } from '../../../App';
import { AppState } from 'react-native';
import { syncFormDashboardAction } from 'stories/dashboard/reducer';
import { checkIsEmpty, getTimeSyncForm, setTimeSyncForm } from 'helpers/Functions';
const SyncForm = () => {

    const { isAuth } = useSelector((state: RootState) => state.login);
    const dispatch = useDispatch<any>()
    const { notificationCount, recentlyViewedDocs, documentNewList, documentMostViewList, documentFavoriteList } = useSelector((state: RootState) => state.dashboard);

    useEffect(() => {
        const createForm = async () => {
            const watermelonsCollection = database.get(TABLE.TASKFORM);
            await database.action(async () => {
                watermelonsCollection.create((it: any) => {
                    it.documentNewList = ""
                    it.recentlyViewedDocs = ""
                    it.documentFavoriteList = ""
                    it.documentMostViewList = ""
                });
            });
        }
        createForm()
    }, [])

    useEffect(() => {
        const saveTaskForm = async () => {
            await database.write(async (tx) => {
                // Tìm phần tử đầu tiên trong cơ sở dữ liệu
                const watermelonsCollection = database.get(TABLE.TASKFORM);
                const allRecords = await watermelonsCollection.query().fetch();
                // console.log('allRecordsallRecords', allRecords[0].documentNewList);

                if (allRecords.length > 0) {
                    const firstRecord = allRecords[0];

                    const arrayToSaveDocumentNewList = JSON.stringify(documentNewList);
                    const arrayToSaveRecentlyViewedDocs = JSON.stringify(recentlyViewedDocs);
                    const arrayToSaveDocumentFavoriteList = JSON.stringify(documentFavoriteList);
                    const arrayToSaveDocumentMostViewList = JSON.stringify(documentMostViewList);

                    await firstRecord.update((record: any) => {
                        record.notificationCount = notificationCount;
                        record.documentNewList = arrayToSaveDocumentNewList;
                        record.recentlyViewedDocs = arrayToSaveRecentlyViewedDocs; // Đảm bảo bạn đã thay đổi giá trị này nếu cần
                        record.documentFavoriteList = arrayToSaveDocumentFavoriteList;
                        record.documentMostViewList = arrayToSaveDocumentMostViewList;
                    });

                }
            });
        }

        if (!checkIsEmpty(documentFavoriteList)) saveTaskForm();
    }, [documentMostViewList, documentNewList, documentFavoriteList, notificationCount, recentlyViewedDocs]);

    const syncFormRequestApi = async () => {
        try {
            const allRecords: any = await database.get(TABLE.TASKFORM).query().fetch();

            // Nếu bạn có nhiều bản ghi, bạn có thể sử dụng map để chuyển đổi chúng thành một mảng
            // Thực hiện phân tích mỗi bản ghi thành một đối tượng JavaScript
            const data = {
                documentNewList: allRecords[0].documentNewList ? JSON.parse(allRecords[0].documentNewList) : [], // Thay field1 bằng tên trường thực tế của bạn
                recentlyViewedDocs: allRecords[0].recentlyViewedDocs ? JSON.parse(allRecords[0].recentlyViewedDocs) : [], // Thay field2 bằng tên trường thực tế của bạn
                documentFavoriteList: allRecords[0].documentFavoriteList ? JSON.parse(allRecords[0].documentFavoriteList) : [], // Thay field2 bằng tên trường thực tế của bạn
                documentMostViewList: allRecords[0].documentMostViewList ? JSON.parse(allRecords[0].documentMostViewList) : [], // Thay field2 bằng tên trường thực tế của bạn
                // Thêm các trường khác nếu cần
            };

            dispatch(syncFormDashboardAction(data))
        } catch (error) {
            console.error('Error fetching and parsing data:', error);
        }
    };

    const syncFormStatusState = () => {
        syncFormRequestApi();
    };

    const syncFormAppState = async () => {
        try {
            const modified = await getTimeSyncForm();
            const milisecond = new Date() - new Date(modified);
            if (milisecond / 1000 > 3600) {
                syncFormRequestApi();
                setTimeSyncForm(new Date());
            }
        } catch (error) {
            //
        }
    };

    useEffect(() => {
        if (isAuth) {
            syncFormStatusState();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isAuth]);
    useEffect(() => {
        const subscription = AppState.addEventListener('change', nextAppState => {
            if (nextAppState === 'active') {
                syncFormAppState();
            }
        });

        return () => {
            subscription.remove();
        };
    }, []);

    return null;
}
export default SyncForm;