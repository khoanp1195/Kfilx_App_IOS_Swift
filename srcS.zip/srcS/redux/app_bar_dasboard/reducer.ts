import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    isHomePage:true,
    isChildCategory:false,
    isChildFavorite:false,
    indexTab:0
};

const appBarSlice = createSlice({
    name: 'appbar',
    initialState,
    reducers: {
        setHomePageState: (state, action) => {
            state.isHomePage= action.payload;
        },
        setChildCategory:(state, action) => {
            state.isChildCategory= action.payload;
        },
        setChildFavorite:(state, action) => {
            state.isChildFavorite= action.payload;
        },
        setIndexTab:(state, action) => {
            state.indexTab= action.payload;
        },
    },
});

export const {
    setHomePageState,
    setChildCategory ,
    setChildFavorite,
    setIndexTab
} = appBarSlice.actions;
const {reducer}=appBarSlice;
export default reducer;
