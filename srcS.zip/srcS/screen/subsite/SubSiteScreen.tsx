import React, {useEffect, useMemo, useRef, useState} from "react";
import BottomSheet from "@gorhom/bottom-sheet";
import {useDispatch, useSelector} from "react-redux";
import {FlatList, Image, StyleSheet, Text, TouchableOpacity, View} from "react-native";
import {hideSubSite} from "../../redux/subsite/reducer";
import {SubSite} from "services/database/models/SubSite";

export const SubSiteScreen = () => {
    const bottomSheetRef = useRef<BottomSheet>(null);
    const snapPoints = useMemo(() => ['90%'], []);
    const {isVisibleSubSite} = useSelector((state: any) => state.sub_site);
    const dispatch = useDispatch();

    // @ts-ignore
    const currentLanguage = useSelector((state) => state.languages.currentLanguage);
    // @ts-ignore
    const translations = useSelector((state) => state.languages.translations);
    const currentTranslations = translations[currentLanguage];
    const [listSite,setListSite]=useState();
    useEffect(() => {
        SubSite.getAll().then(value=>{
            // @ts-ignore
            setListSite(value);
        })
    }, []);
    useEffect(() => {
        // @ts-ignore
        bottomSheetRef.current.snapToPosition(0)
    }, [isVisibleSubSite]);
    const handleSheetChanges = (index: number) => {
        if (index == -1)
            dispatch(hideSubSite());
    }
    return <BottomSheet
        ref={bottomSheetRef}
        index={isVisibleSubSite ? 0 : -1}
        snapPoints={snapPoints}
        onChange={handleSheetChanges}
        enablePanDownToClose={true}
        containerStyle={isVisibleSubSite && styles.containerStyle}
        backgroundStyle={styles.bottomSheetStyle}
    >
        <View style={styles.topContainer}>
            <TouchableOpacity onPress={() => {
                dispatch(hideSubSite());
            }}>
                <Image
                    style={styles.image}
                    source={require('assets/images/icon_arrow.png')}
                    resizeMode="contain"
                    // @ts-ignore
                    transform={[{rotate: '180deg'}]}
                />
            </TouchableOpacity>
            <Text style={styles.centeredText}>{currentTranslations.subsite}</Text>
            <TouchableOpacity onPress={() => {
                // @ts-ignore
                bottomSheetRef.current.snapToPosition(-1)
            }}>
                <Text style={styles.rightText}>{currentTranslations.close}</Text>
            </TouchableOpacity>
        </View>
        {
            listSite!= undefined &&<FlatList
             data={listSite}
             renderItem={({item, index}) => (
                 <TouchableOpacity>
                     <View style={{padding:10}}>
                         <Text>{currentLanguage=='en'?item.TitleEN:item.Title}</Text>
                         <Text>{item.SubSite}</Text>
                     </View>
                 </TouchableOpacity>
             )}/>
        }

    </BottomSheet>
}
const styles = StyleSheet.create({

    image: {
        height: 20,
        wight: 20,
    },
    accountname: {
        fontFamily: 'heritage_regular',
        lineHeight: 15,
    },
    fullname: {
        color: 'black',
        fontSize: 16,
        fontFamily: 'heritage_regular',
        lineHeight: 20,
    },
    infor: {
        flexDirection: 'column'
    },
    parentBorder: {
        alignItems: 'center'
    },
    cardDoc: {
        flexDirection: 'column',
        padding: 10,
        backgroundColor: 'white',
        borderRadius: 6,
        width: "90%",
        marginTop: 25
    },
    cardInfo: {
        flexDirection: 'column',
        padding: 10,
        backgroundColor: 'white',
        borderRadius: 6,
        width: "90%",
    },
    parentBorderContainer: {
        flexDirection: 'row',
        padding: 10,
        backgroundColor: 'white',
        borderRadius: 6,
    },

    containerStyle: {
        backgroundColor: 'rgba(128, 128, 128, 0.6)'
    },
    bottomSheetStyle: {
        backgroundColor: '#F2F3F7',
        borderRadius: 12
    },
    topContainer: {
        flexDirection: 'row', // Arrange children in a row
        alignItems: 'center', // Center vertically
        padding: 16,
    },
    centeredText: {
        flex: 1,
        fontFamily: 'heritage_regular',
        lineHeight: 15,
    },
    rightText: {
        textAlign: 'right',
        fontFamily: 'heritage_regular',
        lineHeight: 15,
    },
});
