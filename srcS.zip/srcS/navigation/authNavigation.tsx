import React, { useEffect } from "react";
import LoginScreen from "../screen/login/LoginScreen";
import {TabsScreen} from "../screen/tab/TabScreen";
import {AppNavigationContainer} from "navigation/appNavigationContainer";
import {useSelector} from "react-redux";
import {View} from "react-native";
import PERMISSIONS, {requestMultiple} from "react-native-permissions";
export const AuthNavigation = () => {
    const isAuth = useSelector((state: any) => state.auth.isAuth);
    return (
        <View style={{flex: 1}}>{!isAuth ? <LoginScreen /> : <AppNavigationContainer />}</View>
);
};
