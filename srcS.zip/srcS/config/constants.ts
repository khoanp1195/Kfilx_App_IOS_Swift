import {Dimensions} from 'react-native';
const DEV_URL = 'https://vnadmsuatportal.vuthao.com';
const UAT_URL = '';
const MIG_url = ''; /// UAT MIG
const LIVE_url = ''; // LIVE
export const BASE_URL = DEV_URL;
export const subsiteStore = {
    subsite: 'psd', // Initial value is an empty string

    getSubsite: function () {
        return this.subsite;
    },

    setSubsite: function (newSubsite: string) {
        this.subsite = newSubsite;
    },
};
export const currentUserStore = {
    currentUser: {
        ImagePath: "",
        AccountName: "",
        FullName: "",
        DefaultLanguageid: 0,
        DepartmentTitle: "",
        DepartmentTitleEN: "",
        Email: "",
        Mobile: "",
        PositionTitleEN: "",
        PositionTitle: "",
        NotifyCategoryId:0,
        EmailCategoryId:0,
        TopUsedKey: "",
        DefaultSite:"",
        LastSite:""
    },
    getCurrentUser: function () {
        return this.currentUser;
    },
    setCurrentUser: function (newSubsite:any) {
        this.currentUser = newSubsite;
    },
};

export const RESONSE_STATUS_SUCCESS = 'SUCCESS';
export const RESONSE_STATUS_NONE = 'NONE';
export const RESONSE_STATUS_ERROR = 'ERR';
