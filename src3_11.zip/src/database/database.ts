import SQLiteAdapter from "@nozbe/watermelondb/adapters/sqlite";
import {appSchema, Database} from "@nozbe/watermelondb";
import DocumentRecently from "./models/DocumentRecently";
import {Document} from "./models/Document";
import {ConfigNotification} from "./models/ConfigNotification";
import schema from "./schema";
import {DocumentInteractive} from "./models/DocumentInteractive";
import {Comment} from "./models/Comment";
import {DocumentAreaCategory} from "./models/DocumentAreaCategory";
import {FavoriteFolder} from "./models/FavoriteFolder";
import {DocumentType} from "./models/DocumentType";
import {DocumentCategory} from "./models/DocumentCategory";
import DocumentOffline from "./models/DocumentOffline";
import {SearchHistory} from "./models/SearchHistory";
import { DocumentFavorite } from "./models/DocumentFavorite";
import {Notify} from "./models/Notify";
// import {SubSite} from "./models/SubSite";
import {StandardDoc} from "./models/StandardDoc";

const adapter = new SQLiteAdapter({
    schema:schema,
    dbName: 'myDatabase',
});
// @ts-ignore
export const database = new Database({
    adapter: adapter,
    modelClasses: [
        Document,
        DocumentRecently,
        ConfigNotification,
        DocumentInteractive,
        Comment,
        DocumentAreaCategory,
        FavoriteFolder,
        DocumentType,
        DocumentCategory,
        DocumentOffline,
        SearchHistory,
        DocumentFavorite,
        Notify,
        // SubSite,
        StandardDoc
    ],
    // @ts-ignore
    actionsEnabled: true,
})
