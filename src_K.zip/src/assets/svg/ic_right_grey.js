import * as React from "react";
import Svg, { Path } from "react-native-svg";

function SvgComponent(props) {
  const { color = "#BCBCBC" } = props;
  return (
    <Svg
      width={8}
      height={13}
      viewBox="0 0 8 13"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        d="M1.055.783l-.601.585a.364.364 0 00-.12.269c0 .1.04.19.12.268L5.18 6.5.454 11.094a.364.364 0 00-.12.27c0 .1.04.19.12.268l.601.584a.385.385 0 00.553 0L7.213 6.77a.365.365 0 00.12-.27c0-.1-.04-.19-.12-.268L1.608.783a.385.385 0 00-.553 0z"
        fill={color}
      />
    </Svg>
  );
}

export default SvgComponent;
