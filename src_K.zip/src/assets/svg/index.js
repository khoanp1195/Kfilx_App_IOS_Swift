import UserGreyIcon from "./ic_user_grey.js";
import PasswordGreyIcon from "./ic_password_grey.js";
import HideGreyIcon from "./ic_hide_grey.js";
import ClearTextRedIcon from "./ic_clear_text_red.js";
import BottomTabCategoryIcon from "./ic_bottomtab_category.js";
import BottomTabFavouriteIcon from "./ic_bottomtab_favourite.js";
import BottomTabHomeIcon from "./ic_bottomtab_home.js";
import BottomTabSearchIcon from "./ic_bottomtab_search.js";
import NotificationIcon from "./ic_notification.js";
import BackIcon from "./ic_back.js";
import RightIcon from "./ic_right_grey.js";
import InteractiveIcon from "./ic_interactive.js";
import CommentIcon from "./ic_comment.js";
import OfflineIcon from "./ic_offline_doc.js";
import LanguageIcon from "./ic_language.js";
import VersionIcon from "./ic_version.js";
import LogoutRedIcon from "./ic_logout_red.js";
import SettingIcon from "./ic_setting.js";
import SnareIcon from "./ic_snare.js";
import DrawViewIcon from "./ic_draw_view.js";
import NineBoxIcon from "./nine_box.js";

export {
  SnareIcon,
  NineBoxIcon,
  DrawViewIcon,
  LogoutRedIcon,
  SettingIcon,
  VersionIcon,
  LanguageIcon,
  OfflineIcon,
  CommentIcon,
  InteractiveIcon,
  UserGreyIcon,
  HideGreyIcon,
  PasswordGreyIcon,
  ClearTextRedIcon,
  BottomTabCategoryIcon,
  BottomTabHomeIcon,
  BottomTabSearchIcon,
  BottomTabFavouriteIcon,
  NotificationIcon,
  BackIcon,
  RightIcon,
};
