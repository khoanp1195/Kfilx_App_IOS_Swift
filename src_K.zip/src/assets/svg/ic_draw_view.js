import * as React from "react";
import Svg, { Path } from "react-native-svg";

function SvgComponent(props) {
  return (
    <Svg
      width={26}
      height={18}
      viewBox="0 0 26 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M25.2.9a.9.9 0 01-.9.9H.9A.9.9 0 11.9 0h23.4a.9.9 0 01.9.9zm-4.5 7.2H.9a.9.9 0 100 1.8h19.8a.9.9 0 100-1.8zM.9 16.2h11.7a.9.9 0 110 1.8H.9a.9.9 0 110-1.8z"
        fill="#fff"
      />
    </Svg>
  );
}

export default SvgComponent;
