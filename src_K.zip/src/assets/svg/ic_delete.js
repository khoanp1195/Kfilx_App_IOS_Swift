import * as React from "react";
import Svg, { Path } from "react-native-svg";

function SvgComponent(props) {
  return (
    <Svg
      width={16}
      height={16}
      viewBox="0 0 16 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        d="M8.884 8l6.933-6.933a.625.625 0 10-.884-.884L8 7.116 1.067.183a.625.625 0 10-.884.884L7.116 8 .183 14.933a.625.625 0 10.884.884L8 8.884l6.933 6.933a.623.623 0 00.884 0 .625.625 0 000-.884L8.884 8z"
        fill="#7B7B7B"
      />
    </Svg>
  );
}

export default SvgComponent;
