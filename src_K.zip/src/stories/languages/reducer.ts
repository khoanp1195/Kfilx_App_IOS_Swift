import { createSlice, } from '@reduxjs/toolkit';
import { DEFAULT_LANGUAGE_TEXT } from 'helpers/Constants';

const languagesSlice = createSlice({
  name: 'languages',
  initialState: {
    languages: require("../../languages/en").default,
    languagesText: DEFAULT_LANGUAGE_TEXT.ENGLISH
  },
  reducers: {
    setLanguagesAction(state, action) {
      const isEng = action.payload === DEFAULT_LANGUAGE_TEXT.ENGLISH
      return {
        ...state,
        languages: isEng ? require("../../languages/en").default : require("../../languages/vi").default,
        languagesText: action.payload
      };
    },
  },
  extraReducers: builder => {

  },
});
export const { setLanguagesAction } = languagesSlice.actions;
const { reducer } = languagesSlice;
export default reducer;
