import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { get } from '../../services/ApiServices';
import { BASE_URL, RESONSE_STATUS_SUCCESS } from 'helpers/Constants';
import { isNullOrUndefined } from 'helpers/Functions';
import { Alert } from 'react-native';

export const getUnReadNotify = createAsyncThunk(
  'dashboard/getUnReadNotify',
  async () => {
    const res = await get(
      `/psd/API/ApiMobile.ashx?func=GetUnReadNotify&Params=Offset%2CLimit%2CisCount&Offset=0&Limit=0&isCount=1`,
    );

    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data;
      }
    }

    return null;
  },
);
export const getViewDocumentNew = createAsyncThunk(
  'dashboard/getViewDocumentNew',
  async (LangId: number) => {
    const res = await get(
      `/psd/API/ApiMobile.ashx?func=GetViewDocumentNew&LangId=${LangId}&Params=LangId%2COffset%2CLimit&Offset=0&Limit=5`,
    );

    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data;
      }
    }

    return null;
  },
);
export const getDocumentMostView = createAsyncThunk(
  'dashboard/getDocumentMostView',
  async (LangId: number) => {
    const res = await get(
      `/psd/API/ApiMobile.ashx?func=GetDocumentMostView&LangId=${LangId}&Params=LangId%2CCategoryId%2COffset%2CLimit&CategoryId=5&Offset=0&Limit=5`,
    );

    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data;
      }
    }

    return null;
  },
);
export const getDocumentFavorite = createAsyncThunk(
  'dashboard/getDocumentFavorite',
  async (LangId: number) => {
    const res = await get(
      `/psd/API/ApiMobile.ashx?func=GetDocumentFavorite&LangId=${LangId}&Params=Offset%2CLimit&Offset=0&Limit=5`,
    );

    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data.Data;
      }
    }

    return null;
  },
);

export const getAutoLoginMobile = createAsyncThunk(
  'dashboard/getAutoLoginMobile',
  async () => {
    const res = await get('/psd/API/User.ashx?func=mobileAutoLoginWeb',
    );
    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data;
      }
    }
    return null;
  },
);

const dashBoardSlice = createSlice({
  name: 'dashboard',
  initialState: {
    notificationCount: 0,
    documentNewList: [],
    documentMostViewList: [],
    documentFavoriteList: [],
    recentlyViewedDocs: [],
    isLoading: false,
    autoId: null,
    isShowBottomSheet: false,
    isShowBottomSheetAccount: false,
  },
  reducers: {
    syncFormDashboardAction(state, action) {
      console.log('syncFormDashboardActionnnn:', action.payload);

      return {
        ...state,
        documentNewList: action.payload.documentNewList,
        notificationCount: action.payload.notificationCount,
        recentlyViewedDocs: action.payload.recentlyViewedDocs,
        documentMostViewList: action.payload.documentMostViewList,
        documentFavoriteList: action.payload.documentFavoriteList
      };
    },
    setRecentlyViewedDocsAction(state, action) {
      return {
        ...state,
        recentlyViewedDocs: action.payload
      }
    },
    setIsShowBottomSheetAction(state, action) {
      return {
        ...state,
        isShowBottomSheet: action.payload
      }
    },
    setIsShowBottomSheetAccountAction(state, action) {
      return {
        ...state,
        isShowBottomSheetAccount: action.payload
      }
    },
  },
  extraReducers: builder => {
    builder.
      addCase(getUnReadNotify.fulfilled, (state: any, action) => {
        state.notificationCount = action.payload;
      })
      .addCase(getViewDocumentNew.fulfilled, (state: any, action) => {
        state.documentNewList = action.payload;
      })
      .addCase(getDocumentFavorite.fulfilled, (state: any, action) => {
        state.documentFavoriteList = action.payload;
      })
      .addCase(getDocumentMostView.fulfilled, (state: any, action) => {
        state.documentMostViewList = action.payload;
      })
      .addCase(getAutoLoginMobile.fulfilled, (state: any, action) => {
        state.autoId = action.payload;
      });
  }
});
export const { syncFormDashboardAction, setRecentlyViewedDocsAction, setIsShowBottomSheetAccountAction, setIsShowBottomSheetAction } = dashBoardSlice.actions;

const { reducer } = dashBoardSlice;
export default reducer;
