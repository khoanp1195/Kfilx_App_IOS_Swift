import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { RESONSE_STATUS_SUCCESS } from 'helpers/Constants';
import { isNullOrUndefined } from 'helpers/Functions';
import { get, post } from '../../services/ApiServices';

export const getConfigNotification = createAsyncThunk(
    'settings/getConfigNotification',
    async ({ langId, Offset }: any) => {
        const res = await get(
            `/psd/api/ApiMobile.ashx?func=GetConfigNotification`,
        );

        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return {
                    data: res.data.data.Data,
                    totalRecord: res.data.data.MoreInfo[0].totalRecord,
                    Offset
                };
            }
        }
    },
);
export const postSaveUserConfigNotification = createAsyncThunk(
    'settings/postSaveUserConfigNotification',
    async ({ NotifyCategoryId, EmailCategoryId }: any) => {
        const data = { NotifyCategoryId: NotifyCategoryId, EmailCategoryId: EmailCategoryId }
        const res = await post(
            `/psd/api/ApiMobile.ashx?func=SaveUserConfigNotification&enc=RSA`, data
        );

        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return true;
            }
        }
    },
);
const settingsSlice = createSlice({
    name: 'settings',
    initialState: {
        configNotifications: [],
        isLoading: false
    },
    reducers: {
        resetConfigNotifications(state, action) {
            return {
                ...state,
                configNotifications: [],
                isLoading: false
            };
        },
    },
    extraReducers: builder => {
        builder.
            addCase(getConfigNotification.pending, (state: any, action: any) => {
                state.isLoading = true
            }).
            addCase(getConfigNotification.fulfilled, (state: any, action: any) => {
                state.configNotifications = action.payload;
                state.isLoading = false
            }).
            addCase(getConfigNotification.rejected, (state: any, action: any) => {
                state.isLoading = false
            }).
            addCase(postSaveUserConfigNotification.fulfilled, (state: any, action: any) => {

            })
    }
});
export const { resetConfigNotifications } = settingsSlice.actions;
const { reducer } = settingsSlice;
export default reducer;
