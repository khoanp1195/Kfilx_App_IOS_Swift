import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { RESONSE_STATUS_SUCCESS } from 'helpers/Constants';
import { isNullOrUndefined } from 'helpers/Functions';
import { get, post } from '../../services/ApiServices';

export const getConfigNotification = createAsyncThunk(
    'settings/getConfigNotification',
    async ({ langId, Offset }: any) => {
        const res = await get(
            `/psd/api/ApiMobile.ashx?func=GetConfigNotification`,
        );
        console.log('settings_Log', res);

        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return {
                    data: res.data.data.Data,
                    EmailCategoryId: res.data.data.MoreInfo[0].EmailCategoryId,
                    NotifyCategoryId: res.data.data.MoreInfo[0].NotifyCategoryId,
                };
            }
        }
    },
);
export const postSaveUserConfigNotification = createAsyncThunk(
    'settings/postSaveUserConfigNotification',
    async ({ NotifyCategoryId, EmailCategoryId }: any) => {
        const res = await get(
            `https://vnadmsuatportal.vuthao.com/psd/api/ApiMobile.ashx?func=SaveUserConfigNotification&data={"Parameters":{"NotifyCategoryId":${NotifyCategoryId},"EmailCategoryId":${EmailCategoryId}}}`
        );
        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return true;
            }
        }
    },
);
const settingsSlice = createSlice({
    name: 'settings',
    initialState: {
        configSettings: {
            data: [],
            NotifyCategoryId: null,
            EmailCategoryId: null
        },
        isLoading: false
    },
    reducers: {
        resetConfigSettings(state, action) {
            return {
                ...state,
                configSettings: {
                    data: [],
                    NotifyCategoryId: null,
                    EmailCategoryId: null
                },
                isLoading: false
            };
        },
    },
    extraReducers: builder => {
        builder.
            addCase(getConfigNotification.pending, (state: any, action: any) => {
                state.isLoading = true
            }).
            addCase(getConfigNotification.fulfilled, (state: any, action: any) => {
                state.configSettings = {
                    data: action.payload.data,
                    EmailCategoryId: action.payload.EmailCategoryId,
                    NotifyCategoryId: action.payload.NotifyCategoryId,

                };
                state.isLoading = false
            }).
            addCase(getConfigNotification.rejected, (state: any, action: any) => {
                state.isLoading = false
            }).
            addCase(postSaveUserConfigNotification.fulfilled, (state: any, action: any) => {

            })
    }
});
export const { resetConfigSettings } = settingsSlice.actions;
const { reducer } = settingsSlice;
export default reducer;
