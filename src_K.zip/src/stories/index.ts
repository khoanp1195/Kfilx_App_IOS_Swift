import loginReducer from './login/reducer';
import dashBoardReducer from './dashboard/reducer';
import languagesReducer from './languages/reducer';
import profilemenuReducer from './profilemenu/reducer';
import listcommentReducer from './listcomment/reducer';
import categoryReducer from './category/reducer';
import settingsReducer from './settings/reducer';
import {
  combineReducers,
  configureStore,
  getDefaultMiddleware,
} from '@reduxjs/toolkit';
import { createSelectorHook, useDispatch } from 'react-redux';
import { persistReducer, persistStore } from 'redux-persist';
import { PersistedState } from 'redux-persist/es/types';
import AsyncStorage from '@react-native-async-storage/async-storage';

import 'react-native-gesture-handler';
const PersistVersion = 1;
const persistConfig: any = {
  key: 'VnaDcm',
  storage: AsyncStorage,
  whitelist: ['login', 'languages',],
  blacklist: [],
  version: PersistVersion,
  migrate: (state: PersistedState) => {
    if (PersistVersion !== state?._persist.version) {
      return Promise.resolve(null as unknown as PersistedState);
    }
    return Promise.resolve(state);
  },
};
const rootReducer = combineReducers({
  login: loginReducer,
  dashboard: dashBoardReducer,
  languages: languagesReducer,
  profilemenu: profilemenuReducer,
  listcomment: listcommentReducer,
  category: categoryReducer,
  settings: settingsReducer,
});
const persistedReducer = persistReducer(persistConfig, rootReducer);

const store = configureStore({
  devTools: process.env.NODE_ENV === 'development',
  reducer: persistedReducer,
  // @see httpss://redux-toolkit.js.org/usage/usage-guide#use-with-redux-persist
  middleware: getDefaultMiddleware({
    serializableCheck: false,
  }),
});
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
export const useAppSelector = createSelectorHook<RootState>();
export const useAppDispatch = () => useDispatch<AppDispatch>();
export const persistor = persistStore(store);
export default store;
