import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { RESONSE_STATUS_SUCCESS } from 'helpers/Constants';
import { isNullOrUndefined } from 'helpers/Functions';
import { get } from '../../services/ApiServices';
import { Alert } from 'react-native';

export const getlistCategoryDocs = createAsyncThunk(
    'category/getlistCategoryDocs',
    async ({ langId, Offset }: any) => {
        const res = await get(
            `/psd/API/ApiMobile.ashx?func=GetDocumentAreaCategory&LangId=${langId}&Params=LangId%2COffset%2CLimit&Offset=0&Limit=20`,
        );
        console.log('ressssss GetDocumentAreaCategory', res.data);

        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return {
                    data: res.data.data,
                    Offset
                };
            }
        }
    },
);
const listCategorySlice = createSlice({
    name: 'category',
    initialState: {
        listCategoryDocs: {
            data: [],
            isLoading: false,
            totalRecord: 0
        }
    },
    reducers: {
        resetListCategoryAction(state, action) {
            return {
                ...state,
                listCategoryDocs: {
                    data: [],
                    isLoading: false,
                    totalRecord: 0
                }
            };
        },
    },
    extraReducers: builder => {
        builder.
            addCase(getlistCategoryDocs.pending, (state: any, action: any) => {
                state.listCategoryDocs.isLoading = true
            }).
            addCase(getlistCategoryDocs.fulfilled, (state: any, action: any) => {
                const { Offset } = action.payload
                state.listCategoryDocs = {
                    data: Offset === 0 ? action.payload.data : state.listCategoryDocs.data.concat(action.payload.data),
                    totalRecord: action.payload.totalRecord,
                    isLoading: false,
                }
            }).
            addCase(getlistCategoryDocs.rejected, (state: any, action: any) => {
                state.listCategoryDocs.isLoading = false
            })
    }
});
export const { resetListCategoryAction } = listCategorySlice.actions;
const { reducer } = listCategorySlice;
export default reducer;
