import { TABLE } from './contains';

const TaskFormSchema = {
    name: TABLE.TASKFORM,
    columns: [
        { name: 'notificationCount', type: 'string' },
        { name: 'documentNewList', type: 'string' },
        { name: 'recentlyViewedDocs', type: 'string' },
        { name: 'documentFavoriteList', type: 'string' },
        { name: 'documentMostViewList', type: 'string' },
    ],
};

export default TaskFormSchema;
