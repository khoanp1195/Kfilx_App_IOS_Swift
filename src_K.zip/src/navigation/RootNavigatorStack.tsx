import React from 'react';
import {View, TouchableOpacity} from 'react-native';
import {createStackNavigator} from '@react-navigation/stack';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {BottomTabCategoryIcon, BottomTabFavouriteIcon, BottomTabHomeIcon, BottomTabSearchIcon, UserGreyIcon} from 'assets/svg/index';
import styles from './RootContainer.Style';
import DashboardScreen from '../screens/dashboard/Dashboard.Screen';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from 'stories/index';
import TextCusTom from 'components/TextCusTom';
import DashboardDetailScreen from '../screens/dashboard/DashboardDetail';
import InteractiveDocsScreen from '../screens/profilemenu/InteractiveDocs.Screen';
import ListcommentScreen from '../screens/profilemenu/listcomment/Listcomment.Screen';
import { SCREEN_HEIGHT } from '@gorhom/bottom-sheet';
import { dimnensHeight } from 'helpers/Constants';
import SettingsScreen from '../screens/settings/index';
import CategoryScreen from '../screens/category';
import CategoryDetailScreen from '../screens/category/CategoryDetail';
import NotificationsScreen from '../screens/notifications';
import OfflineDocsScreen from '../screens/offinedocs';

const Stack = createStackNavigator();
const BottomStack = createBottomTabNavigator();

const renderTabIcon = (isFocused: Boolean, label: String, languages: any) => {
  switch (label) {
    case languages.tab_home:
      return <BottomTabHomeIcon focused={isFocused} />;
    case languages.bottomtab_category:
      return <BottomTabCategoryIcon focused={isFocused} />;
    case languages.bottomtab_search:
      return <BottomTabSearchIcon focused={isFocused} />;
    default:
      return <BottomTabFavouriteIcon focused={isFocused} />;
  }
};
function MyTabBar({state, descriptors, navigation, languages}: any) {
  return (
    <TouchableOpacity style={[styles.viewTabBottomBar,SCREEN_HEIGHT > 800 && {height: dimnensHeight(85)}]}>
      {state.routes.map((route: any, index: number) => {
        const {options} = descriptors[route.key];
        const label =
          options.tabBarLabel !== undefined
            ? options.tabBarLabel
            : options.title !== undefined
            ? options.title
            : route.name;

        const isFocused = state.index === index;

        const onPress = () => {
          const event = navigation.emit({
            type: 'tabPress',
            target: route.key,
            canPreventDefault: true,
          });

          if (!isFocused && !event.defaultPrevented) {
            // The `merge: true` option makes sure that the params inside the tab screen are preserved
            navigation.navigate({name: route.name, merge: true});
          }
        };

        const onLongPress = () => {
          navigation.emit({
            type: 'tabLongPress',
            target: route.key,
          });
        };

        return (
          <TouchableOpacity
            key={label}
            activeOpacity={1}
            accessibilityRole="button"
            accessibilityState={
              isFocused ? {selected: true} : {selected: false}
            }
            accessibilityLabel={options.tabBarAccessibilityLabel}
            testID={options.tabBarTestID}
            onPress={onPress}
            onLongPress={onLongPress}
            style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
            <View style={styles.tabBarIconView}>
              {renderTabIcon(isFocused, label,languages)}
            </View>
            <TextCusTom
              style={
                isFocused
                  ? styles.tabBarLabelActive
                  : styles.tabBarLabelInActive
              }>
              {label}
            </TextCusTom>
          </TouchableOpacity>
        );
      })}
    </TouchableOpacity>
  );
}
function AppBottomStack() {
  const {languages, } = useSelector((state: RootState) => state.languages);
  return (
    <BottomStack.Navigator
    screenOptions={{
        headerShown: false,
      }}
      tabBar={props => {
        return <MyTabBar {...props} languages={languages}/>;
      }}>
      <BottomStack.Screen
        name={languages.tab_home}
        component={HomeStack}
      />

      <BottomStack.Screen
        name={languages.bottomtab_category}
        component={CategoryStack}
      />
      <BottomStack.Screen
        name={languages.bottomtab_search}
        component={CategoryStack}
      />
 
      <BottomStack.Screen
        name={languages.bottomtab_favourite}
        component={CategoryStack}
      />
    </BottomStack.Navigator>
  );
}

function HomeStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        options={{headerShown: false}}
        name="DashboardScreen"
        component={DashboardScreen}
      />
    </Stack.Navigator>
  );
}

function CategoryStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        options={{headerShown: false}}
        name="CategoryScreen"
        component={CategoryScreen}
        initialParams={{type: 'Tab'}}
      />
          <Stack.Screen
        options={{headerShown: false}}
        name="CategoryDetailScreen"
        component={CategoryDetailScreen}
        initialParams={{type: 'Tab'}}
      />
    </Stack.Navigator>
  );
}
function VBDiStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        options={{headerShown: false}}
        name="VBDiScreen"
        component={DashboardScreen}
        initialParams={{type: 'Tab'}}
      />
    </Stack.Navigator>
  );
}

export default function RootNavigatorStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        options={{headerShown: false}}
        name="AppBottomStack"
        component={AppBottomStack}
      />
          <Stack.Screen
        options={{headerShown: false}}
        name="DashboardDetailScreen"
        component={DashboardDetailScreen}
      />
          <Stack.Screen
        options={{headerShown: false}}
        name="InteractiveDocsScreen"
        component={InteractiveDocsScreen}
      />
          <Stack.Screen
        options={{headerShown: false}}
        name="ListcommentScreen"
        component={ListcommentScreen}
      />
          <Stack.Screen
        options={{headerShown: false}}
        name="SettingsScreen"
        component={SettingsScreen}
      />
          <Stack.Screen
        options={{headerShown: false}}
        name="NotificationsScreen"
        component={NotificationsScreen}
      />
          <Stack.Screen
        options={{headerShown: false}}
        name="OfflineDocsScreen"
        component={OfflineDocsScreen}
      />

    </Stack.Navigator>
  );
}
