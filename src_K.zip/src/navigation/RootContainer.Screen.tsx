import React, {useState, useEffect} from 'react';
import styles from './RootContainer.Style';
import {View, StatusBar, Alert} from 'react-native';
import {
  createNavigationContainerRef,
} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import LoginScreen from 'screens/login/Login.Screen';
import {useSelector} from 'react-redux';
import DrawerNavigatorStack from './RootNavigatorStack';
export type StackParamList = {
  LoginScreen: undefined;
  DrawerNavigatorStack: undefined;
};
import {RootState} from '~/stories';
import colors from 'helpers/Colors';
import { SCREEN_HEIGHT } from '@gorhom/bottom-sheet';

export const navigationRef = createNavigationContainerRef();
export const navigate = (name: any, params: any) => {
  if (navigationRef.isReady()) {
    navigationRef.navigate(name, params);
  }
};

const Stack = createStackNavigator<StackParamList>();

const RootContainerScreen = () => {
  const {isAuth} = useSelector((state: RootState) => state.login);
  // alert(SCREEN_HEIGHT)
  return (
              <View style={[styles.mainContainer,SCREEN_HEIGHT > 800 && {marginTop: 30}]}>
              {/* <StatusBar backgroundColor={colors.white} translucent barStyle="light-content"/> */}
      {isAuth ? (
          <DrawerNavigatorStack />
      ) : (
        <>
          <Stack.Navigator
            initialRouteName="LoginScreen"
            screenOptions={{
              headerShown: false,
            }}>
            <Stack.Screen
              name="LoginScreen"
              component={LoginScreen}
              options={{gestureEnabled: true, gestureDirection: 'horizontal'}}
            />
          </Stack.Navigator>
          
        </>
      )}
      </View>
  );
};

export default RootContainerScreen;
