import React, {FC} from 'react';
import {
  StyleSheet,
  Text,
  View,
} from 'react-native';
import {FontSize} from 'helpers/Constants';
import colors from '../helpers/Colors';
import FastImage from 'react-native-fast-image';

interface Props {
  onRetryPress?: () => any;
}

const NoDataView: FC<Props> = (props: Props) => {
  return (
    <View style={styles.viewNoData}>
      <FastImage  style={{ width: 242, height: 150 }}
        source={require('assets/images/nodata.png')}
        resizeMode={FastImage.resizeMode.contain}/>
      <Text style={styles.textNoData}>Không có dữ liệu</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  viewNoData: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  textNoData: {
    fontSize: FontSize.SMALL,
    color: colors.DarkCyan,
    fontWeight: '400',
    marginTop: 10
  },
});

export default React.memo(NoDataView);
