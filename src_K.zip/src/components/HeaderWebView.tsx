import { DrawViewIcon, NineBoxIcon, NotificationIcon, SnareIcon } from 'assets/svg';
import React from 'react';
import { StyleSheet, View, TouchableOpacity } from 'react-native';
import FastImageCustom from './FastImageCustom';
import { FontSize, } from 'helpers/Constants';
import TextCusTom from './TextCusTom';
import colors from 'helpers/Colors';
import { isOptionalChain } from 'typescript';

const HeaderWithAvatar: any = ({ children,onPressAvatar = () =>{}, urlOnline, notificationCount = '0', title,isSnare,onNnareChange, ...props }: any) => {
   const isDisplayNotification = notificationCount !== '0';
    return (
        <View style={styles.container}>
            <TouchableOpacity onPress={onPressAvatar}>
            <DrawViewIcon />
            </TouchableOpacity>
            <TextCusTom allowFontScaling={false} {...props} i18nKey={title} style={styles.textTitle} />
            <TouchableOpacity style={styles.viewRight} onPress={onNnareChange}>
                {isSnare ? <SnareIcon /> : <NineBoxIcon />}
            </TouchableOpacity>
        </View>
    );
};
const styles = StyleSheet.create({
    container: { flexDirection: 'row', alignItems: 'center', height: 55, backgroundColor: colors.DarkCyan, paddingHorizontal: 15 },
    textTitle: { fontSize: FontSize.LARGE_X, fontWeight: '700', color: colors.white, marginLeft: 15 },
    viewRight: { flex: 1, alignItems: 'flex-end' },
    viewNotification: { backgroundColor: colors.red, height: 20, width: 20, borderRadius: 10, position: 'absolute', right: -7, top: -5, justifyContent: 'center', alignItems: 'center' },
    textNotification: { color: colors.white, fontSize: 12, }
});
export default React.memo(HeaderWithAvatar);
