import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { View, StyleSheet } from 'react-native';
import BottomSheet, { TouchableOpacity } from '@gorhom/bottom-sheet';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from 'stories/index';
import { setIsShowBottomSheetAccountAction, setIsShowBottomSheetAction, syncFormDashboardAction } from 'stories/dashboard/reducer';
import TextCusTom from './TextCusTom';
import { DEFAULT_LANGUAGE_TEXT, FontFamily, FontSize } from 'helpers/Constants';
import colors from 'helpers/Colors';
import { CommentIcon, InteractiveIcon, LanguageIcon, LogoutRedIcon, OfflineIcon, RightIcon, SettingIcon, VersionIcon } from 'assets/svg';
import { setLanguagesAction } from 'stories/languages/reducer';
import FastImageCustom from './FastImageCustom';
import { logoutAction } from 'stories/login/reducer';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { database } from '../../App';
import { TABLE } from 'database/contains';
import { useNavigation } from '@react-navigation/native';
import DeviceInfo from 'react-native-device-info';
import { isNullOrUndefined } from 'helpers/Functions';

const BottomSheetCustom = ({navigation}: any) => {
    const {isShowBottomSheet} = useSelector((state: RootState) => state.dashboard);
    const {languages,languagesText } = useSelector((state: RootState) => state.languages);
    const [versionApp, setVersionApp] = useState('1.0')
    const dispatch = useDispatch<any>();
  // ref
  const bottomSheetRef = useRef<BottomSheet>(null);
  // variables
  const snapPoints = useMemo(() => ['1%', '98%'], []);
useEffect(() => {
  let version = DeviceInfo.getVersion();
  if(!isNullOrUndefined(version)) setVersionApp(version);
}, [])

  // callbacks
  const handleSheetChanges = useCallback((index: number) => {
    if(index === 0) dispatch(setIsShowBottomSheetAction(false));
  }, []);
  const onCloseBottomSheet = useCallback(
    () => {
        dispatch(setIsShowBottomSheetAction(false))
    },
    [],
  )
  const isLangueEn = useMemo(() => languagesText === DEFAULT_LANGUAGE_TEXT.ENGLISH, [languagesText])
  const isLangueVi = useMemo(() => languagesText === DEFAULT_LANGUAGE_TEXT.VIETNAM, [languagesText])
  const onSwitchLangue = useCallback(
    (languages: string) => {
      dispatch(setLanguagesAction(languages))
      dispatch(setIsShowBottomSheetAction(false))

    },
    [languagesText],
  )
  
  const logOutPress = useCallback(
   async () => {
    const removeForm = async () => {
        try {
            const data = {
                documentNewList: [],
                recentlyViewedDocs: [],
                documentFavoriteList: [],
                documentMostViewList: [],
            };
            dispatch(syncFormDashboardAction(data))
            await database.write(async (tx) => {
                // Tìm phần tử đầu tiên trong cơ sở dữ liệu
                const watermelonsCollection = database.get(TABLE.TASKFORM);
                const allRecords = await watermelonsCollection.query().fetch();
                if (allRecords.length > 0) {
                    const firstRecord = allRecords[0];
                    await firstRecord.update((record: any) => {
                        record.notificationCount = "";
                        record.documentNewList = "";
                        record.recentlyViewedDocs = ""; // Đảm bảo bạn đã thay đổi giá trị này nếu cần
                        record.documentFavoriteList = "";
                        record.documentMostViewList = "";
                    });

                }
            });

        } catch (error) {
            console.error('removeForm error: ', error);
        }
    };

    onCloseBottomSheet();
        await AsyncStorage.removeItem('username')
        await AsyncStorage.removeItem('password')
         removeForm();
      dispatch(logoutAction(null))
    },
    [],
  )
    const onNavigateInteractiveScreen = useCallback(
      () => {
        navigation.navigate("InteractiveDocsScreen", {});
      },
      [],
    )
    
    const onNavigateListcommentScreen = useCallback(
      () => {
        navigation.navigate("ListcommentScreen", {});
      },
      [],
    )
    
    const onNavigateSettingsScreen = useCallback(
      () => {
        navigation.navigate("SettingsScreen", {});
      },
      [],
    )
 
    const onNavigateOfflineDocsScreen = useCallback(
      () => {
        navigation.navigate("OfflineDocsScreen", {});
      },
      [],
    )
 
  const CardMargin = ()  =>{
    return <View style={styles.cardMargin}/>
  }
  const ItemComponent = ({title = '',onPress = () =>{},IconView = null, isLastItem = false,textRight}: any)  => {
    return   (
        <TouchableOpacity onPress={()=>{
          dispatch(setIsShowBottomSheetAction(false));
          onPress();
        }} >
    <View style={styles.flexDirectionRowBetween}>
    {IconView}
    <View style={[styles.flexDirectionRowChildeBetween,isLastItem && {borderBottomWidth: 0}]}>
    <TextCusTom i18nKey={title} style={styles.itemTitle}/>
    {!isNullOrUndefined(textRight) ?  <TextCusTom i18nKey={textRight} style={styles.textRight}/> :<RightIcon />}
    </View>
         </View>
    </TouchableOpacity>
    )
    
  }
  // renders
  if(!isShowBottomSheet) return null
  return (
      <View style={styles.container}>
      <BottomSheet
        ref={bottomSheetRef}
        index={1}
        snapPoints={snapPoints}
        onChange={handleSheetChanges}
      >
        {/* card */}
      <View style={styles.contentContainer}>
      <View style={styles.flexDirectionRowBetween}>
            <View />
            <TextCusTom i18nKey={languages.account} style={styles.textTitle}/>
           <TouchableOpacity onPress={onCloseBottomSheet}>
           <TextCusTom i18nKey={languages.close} style={styles.textClose}/>
           </TouchableOpacity>
        </View>
        <View>
        <CardMargin />

      <View style={styles.itemContainer}>
      <View  style={{flexDirection: 'row', paddingHorizontal: 10, paddingTop: 10}}>
        
      <TouchableOpacity onPress={() =>dispatch(setIsShowBottomSheetAccountAction(true))}>
            <FastImageCustom styleImg={{marginLeft: 10}} urlOnline={'https://kenh14cdn.com/203336854389633024/2023/8/24/qg-1692841944596899107413.jpg'} />
            </TouchableOpacity>
           <View>
           <TextCusTom allowFontScaling={false} i18nKey={'Tạ Nguyễn Vân Anh'} style={styles.textUserName} />   
           <TextCusTom allowFontScaling={false} i18nKey={'vananhtn@vietnamairlines.com'} style={styles.textEmail} />   
           </View>
      </View>
                {/* item */}
                <TouchableOpacity style={styles.itemContainerServiceClient}>
       <View style={styles.flexDirectionRowBetween}>
       <View style={[styles.flexDirectionRowChildeBetween,{borderBottomWidth: 0}]}>
       <TextCusTom i18nKey={languages.offline_docs} style={styles.itemTitle}/>
       <RightIcon />
       </View>
            </View>
       </TouchableOpacity>
      </View>

      <CardMargin />
      <View  style={styles.itemContainer} >
      <ItemComponent title={languages.docs_interaction} onPress={onNavigateInteractiveScreen} IconView={<InteractiveIcon />}/>
      <ItemComponent title={languages.list_comments} onPress={onNavigateListcommentScreen} IconView={<CommentIcon />}/>
      <ItemComponent title={languages.version} textRight={versionApp.toString()} isLastItem={true}/>
      </View>

      <CardMargin />
      <View  style={styles.itemContainer} >
      <ItemComponent title={languages.setting_remind_noti} onPress={onNavigateSettingsScreen} IconView={<SettingIcon />}/>
      <View style={styles.flexDirectionRowBetween}>
<LanguageIcon />

<View style={[styles.flexDirectionRowChildeBetween,{paddingBottom: 10}]}>
<TextCusTom i18nKey={languages.language} style={styles.itemTitle}/>
<View style={styles.viewLanguege}>
<TouchableOpacity style={isLangueEn ? styles.viewActiveLanguege : styles.viewInactiveLanguege} onPress={() => onSwitchLangue(DEFAULT_LANGUAGE_TEXT.ENGLISH)}>
<TextCusTom i18nKey={DEFAULT_LANGUAGE_TEXT.ENGLISH} style={isLangueEn ? styles.textActiveLanguege : styles.textInactiveLanguege}/>
</TouchableOpacity>
<TouchableOpacity style={isLangueVi ? styles.viewActiveLanguege : styles.viewInactiveLanguege} onPress={() => onSwitchLangue(DEFAULT_LANGUAGE_TEXT.VIETNAM)}>
<TextCusTom i18nKey={DEFAULT_LANGUAGE_TEXT.VIETNAM} style={isLangueVi ? styles.textActiveLanguege : styles.textInactiveLanguege}/>
</TouchableOpacity>
</View>
</View>
</View>
      <ItemComponent title={languages.text_offline} IconView={<OfflineIcon />} onPress={onNavigateOfflineDocsScreen} isLastItem={true}/>
      </View>
        </View>
             {/* card */}
             <CardMargin />


{/* item */}
<TouchableOpacity style={[styles.itemContainer]} onPress={logOutPress}>
<View style={styles.flexDirectionRowBetween}>
<LogoutRedIcon />
<View style={[styles.flexDirectionRowChildeBetween,{borderBottomWidth: 0}]}>
<TextCusTom i18nKey={languages.logout} style={styles.textLogOut}/>
</View>
</View>
</TouchableOpacity>
      </View>
      </BottomSheet> 
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
    marginBottom: -20,
    zIndex: 99,
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  cardMargin: {height:30, backgroundColor: colors.light_grayish,  },
  contentContainer: {
    flex: 1,
    backgroundColor: colors.light_grayish,
    paddingHorizontal: 15
  },
  flexDirectionRow: {
    flexDirection: 'row',
    justifyContent: 'center'
  },
  flexDirectionRowBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 10,
    paddingTop: 10,
  },
  flexDirectionRowChildeBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    flex: 1,
    borderBottomColor: colors.grey_co,
    borderBottomWidth: 1,
     marginLeft: 10,
     paddingRight: 10,
     paddingBottom: 10
  },
  textTitle:{
    marginLeft: 50,
    fontSize: FontSize.LARGE,
    color: colors.black,
    fontWeight: '700',
    fontFamily: FontFamily.HERITAGE_BOLD,
  },
  textClose:{
    fontSize: FontSize.SMALL,
    color: colors.black,
    fontWeight: '400',
    fontFamily: FontFamily.HERITAGE_REGULAR,
  },
  itemTitle:{
    fontSize: FontSize.SMALL,
    color: colors.text_grey26,
    fontWeight: '400',
    fontFamily: FontFamily.HERITAGE_REGULAR,
  },
  textRight:{
    fontSize: FontSize.SMALL,
    color: colors.blue,
    fontWeight: '400',
    fontFamily: FontFamily.HERITAGE_REGULAR,
  },
  itemContainer:{
    backgroundColor: colors.white,
    borderRadius: 5
  },
  itemContainerServiceClient:{
    backgroundColor: colors.white,
    borderRadius: 5,
    borderWidth:1,
    borderColor: colors.DarkCyan,
    marginHorizontal: 10,
    marginVertical: 5,  
    overflow: 'hidden'
  },
  viewLanguege: {
    flexDirection: 'row',
    justifyContent: 'center',
    borderRadius:1,
    borderWidth: 0.5,
    borderColor: colors.DarkCyan,
    height: 22,
    width: 80,
    alignItems: 'center',
    padding: 2,
  },
  textInactiveLanguege:{
    fontSize: FontSize.SMALL,
    color: colors.text_grey9E,
    fontWeight: '400',
    fontFamily: FontFamily.HERITAGE_REGULAR,
  },
  textActiveLanguege:{
    fontSize: FontSize.SMALL,
    color: colors.white,
    fontWeight: '400',
    fontFamily: FontFamily.HERITAGE_REGULAR,
  },
  viewInactiveLanguege:{
   width: 36,
   backgroundColor:colors.white,
   borderRadius: 1,
   justifyContent: 'center',
   alignItems: 'center',
  },
  viewActiveLanguege:{
    width: 36,
   backgroundColor:colors.orange,
   borderRadius: 1,
   justifyContent: 'center',
   alignItems: 'center',
  },
  textLogOut:{
    fontSize: FontSize.SMALL,
    color: colors.red,
    fontWeight: '400',
    fontFamily: FontFamily.HERITAGE_REGULAR,
  },
  textUserName:{
    flex: 1,
    marginLeft: 10,
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: '400',
    fontFamily: FontFamily.HERITAGE_BOLD,
  },
  textEmail:{
    flex: 1,
    marginLeft: 10,
    fontSize: FontSize.SMALL,
    color: colors.text_grey_7e,
    fontWeight: '400',
    fontFamily: FontFamily.HERITAGE_BOLD,
  },
});

export default BottomSheetCustom;