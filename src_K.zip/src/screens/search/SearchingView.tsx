
import React, { useCallback, useEffect, useState } from 'react';
import { FlatList, StyleSheet, Text, TouchableOpacity, View, Keyboard, AppState, Alert } from 'react-native';
import { WebView } from 'react-native-webview';
import Header from 'components/Header'
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from 'redux-thunk';
import { getAutoLoginMobile } from 'stories/dashboard/reducer';
import { RootState } from 'stories/index';
import colors from 'helpers/Colors';
import { arrayIsEmpty, checkIsEmpty, format_dd_mm_yy, isNullOrUndefined } from 'helpers/Functions';
import { BASE_URL, FontSize, dimensWidth } from 'helpers/Constants';
import { getlistCategoryDocs } from 'stories/category/reducer';
import NoDataView from 'components/NoDataView';
import uuid from 'react-native-uuid';
import TextCusTom from 'components/TextCusTom';
import FastImageCustom from 'components/FastImageCustom';
import FastImage from 'react-native-fast-image';
import TextInputCustom from 'components/TextInputCustom';
import { DeleteIcon, SearchIcon, TimeIcon } from 'assets/svg';
import { addNewSearchText, setSearchText } from 'stories/search/reducer';

type Props = {
    navigation: any
    route: any
}

const DocumentViewItem = ({gotoDetail, item}: any) => {
    const formatDate = format_dd_mm_yy(item?.PublishDate)
    let imageObj = JSON.parse(item?.Image);
    
  return (
    <View style={styles.itemContainer}>
        <TouchableOpacity onPress={() =>gotoDetail(item)}>
        <FastImageCustom urlOnline={imageObj?.Path} styleImg={styles.imgThumbnail}/>
        </TouchableOpacity>
      <TextCusTom i18nKey={item?.Title} style={styles.cap1} numberOfLines={1}/>
      <TextCusTom i18nKey={item?.Description} style={styles.cap2} numberOfLines={2}/>
    </View>
  )
}

const CategoryScreen = ({route, navigation}: Props) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const {languages,languagesText } = useSelector((state: RootState) => state.languages);
    const {SearchList, searchText} = useSelector((state: RootState) => state.search);

    const [dataSearch, setDataSearch] = useState<any>([])
    const {autoId } = useSelector((state: RootState) => state.dashboard);
    const [autoIdState, setAutoIdState] = useState(null)
    const [isShowWebView, setIsShowWebView] = useState(false)

    useEffect(() => {
      setAutoIdState(autoId)
    }, [autoId])

    useEffect(() => {
        
       if(!arrayIsEmpty(SearchList)){
        function sortByDate(a: any, b: any) {
            if (a.createdDate < b.createdDate) {
                return 1;
            }
            if (a.createdDate > b.createdDate) {
                return -1;
            }
            return 0;
        }

             const data = SearchList.slice(0,10).sort(sortByDate);
        setDataSearch(data);
     
       }
     }, [SearchList])

    useEffect(() => {
        const keyboardDidShowListener = Keyboard.addListener(
          'keyboardDidShow',
          () => {
           setIsShowWebView(false)
          }
        );
        const keyboardDidHideListener = Keyboard.addListener(
          'keyboardDidHide',
          () => {
          setIsShowWebView(true)
          onPressSearch()
          // navigation.goBack();
          }
        );
    
        return () => {
          setIsShowWebView(false)
          keyboardDidHideListener.remove();
          keyboardDidShowListener.remove();
        };
      }, []);

    const onChangeSearch = useCallback(
      (text: any) => {
        dispatch(setSearchText(text))
      },
      [searchText],
    )
    const onPressSearch = useCallback(
      () => {
     if(!checkIsEmpty(searchText)){
      let data = []
      if(arrayIsEmpty(SearchList)){
        data = [{title:searchText, createdDate: new Date(), searchCount: 0}];
      }else{
        const isExistText = SearchList.find((it: any) => it?.title === searchText)
        if(!isExistText){
            data = [{title:searchText, createdDate: new Date(), searchCount: 0},...SearchList];
        }else{
          data = SearchList.map((it: any) =>{
             const newIT =  it?.title === searchText ? {...it, createdDate: new Date(),searchCount : it.searchCount + 1 } : {...it, createdDate: new Date()}
              return newIT
          })
        }
        dispatch(addNewSearchText(data))
      }
      Keyboard.dismiss();
     }
      },
      [searchText,SearchList],
    )
    const onPressCancel = useCallback(
      () => {
        dispatch(setSearchText(""))
        navigation.goBack();
        Keyboard.dismiss();
      },
      [],
    )
    const onPressDelete = useCallback(
      (text: string) => {
        const data = SearchList.filter((it: any) =>it.title !== text);
        dispatch(addNewSearchText(data))
      },
      [SearchList],
    )
    
    const onPressHistoryItem = useCallback(
      (text: any) => {
        dispatch(setSearchText(text))
      },
      [SearchList],
    )
    
  return (
    <View style={{ flex: 1,backgroundColor: colors.white }}>

       <View style={styles.container}>
       <View style={styles.rowView}>
       <View style={styles.searchInput}>
          <TouchableOpacity onPress={onPressSearch}>
          <SearchIcon />
          </TouchableOpacity>
        <TextInputCustom autoFocus value={searchText} onChangeText={onChangeSearch} placeholder={languages.search_hint} style={{flex:1, marginLeft: 10}}/>
        </View>
       <TouchableOpacity onPress={onPressCancel}>
       <TextCusTom i18nKey={languages.cancel} style={styles.cancel} numberOfLines={1}/>
       </TouchableOpacity>
       </View>
{
  isShowWebView ?
  <WebView source={{ uri: `${BASE_URL}/psd/frontend/pages/VNASearchDocument.aspx?kwd=${searchText}&searchunittype=0&gid=1&autoid=fbf0af4d-ea47-4108-a2e5-8c568008751f&lang=${languagesText.toLowerCase().toString()}` }} style={{flex: 1 ,backgroundColor: colors.white }}/>
:
      <FlatList
      contentContainerStyle={styles.containerFlatList}
      data={dataSearch}
      extraData={dataSearch}
      renderItem={({ item }) => (
        <View style={styles.searchHistoryItem}>
                <TimeIcon />
              <TouchableOpacity onPress={() =>onPressHistoryItem(item.title)} style={{flex:1}}>
              <TextCusTom i18nKey={item.title} style={styles.historyText}/>
              </TouchableOpacity>
             <TouchableOpacity onPress={() => onPressDelete(item.title)}>
             <DeleteIcon />
             </TouchableOpacity>
              </View>
      )}
      showsHorizontalScrollIndicator={false}
      keyExtractor={(item: any, index) => uuid.v4().toString() }
      />
      
}
        
       </View>
    </View>
  );
}

export default CategoryScreen

const styles = StyleSheet.create({
  container:{
    flex: 1,backgroundColor: colors.white 
  },
    containerFlatList:{
    marginTop: 20,
    alignItems: 'center',
    flex: 1
    },
    itemContainer:{
        width: 160,
        marginLeft: 20,
        marginBottom: 20,
        justifyContent: 'center',
        alignItems: 'center'
    },
    imgThumbnail:{
        height: 120,
        width: 120,
        borderRadius: 3,
        backgroundColor: '#E2F9FF'
    },
    trend:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey26,
        fontWeight: '400',
        margin: 10,
        paddingHorizontal: 10
    },
    historyText:{
        fontSize: FontSize.SMALL,
        color: colors.grey_4f,
        fontWeight: '400',
        marginHorizontal: 10,
        paddingHorizontal: 10
    },
    cap1:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey26,
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'center',
        paddingHorizontal: 10
    },
    cap2:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey_7b,
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'center',
        paddingHorizontal: 10
    },
    searchInput :{
        flex: 1,
       height: 40,
       margin: 20, 
       flexDirection:'row',
       justifyContent: 'center',
       alignItems: 'center',
       borderColor: colors.orange,
       borderWidth: 0.75,
       borderRadius:20,
       paddingHorizontal: 10,
       backgroundColor: '#FFFAEE',

      },
    searchHistoryItem :{
       height: 40,
       marginBottom: 20, 
       flexDirection:'row',
       alignItems: 'center',
       paddingHorizontal: 10,
       width: dimensWidth(374),
      },
      cancel:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey26,
        fontWeight: '400',
        marginRight: 10,
    },
    rowView:{
        flexDirection:'row',
        justifyContent: 'center',
        alignItems: 'center',
      },
})