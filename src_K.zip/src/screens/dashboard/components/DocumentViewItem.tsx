import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import TextCusTom from 'components/TextCusTom'
import FastImageCustom from 'components/FastImageCustom'
import { FontSize } from 'helpers/Constants'
import colors from 'helpers/Colors'
import { format_dd_mm_yy } from 'helpers/Functions'
import { TouchableOpacity } from 'react-native-gesture-handler'

const DocumentViewItem = ({gotoDetail, item}: any) => {
    const formatDate = format_dd_mm_yy(item?.PublishDate)
  return (
    <View style={styles.itemContainer}>
        <TouchableOpacity onPress={() =>gotoDetail(item)}>
        <FastImageCustom urlOnline={item?.Thumbnail} styleImg={styles.imgThumbnail}/>
        </TouchableOpacity>
      <TextCusTom i18nKey={item?.FileTitle} style={styles.cap1} numberOfLines={1}/>
      <TextCusTom i18nKey={formatDate} style={styles.cap1}/>
    </View>
  )
}

export default DocumentViewItem

const styles = StyleSheet.create({
    itemContainer:{
        width: 160,
        height: 250,
        marginLeft: 20,
    },
    imgThumbnail:{
        height: 200,
        width: 160,
        borderRadius: 3,
        backgroundColor: colors.white
    },
    cap1:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey26,
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'center'
    }
})