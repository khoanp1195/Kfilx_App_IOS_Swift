
import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { WebView } from 'react-native-webview';
import Header from 'components/Header'
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from 'redux-thunk';
import { getAutoLoginMobile } from 'stories/dashboard/reducer';
import { RootState } from 'stories/index';
import colors from 'helpers/Colors';
import { checkIsEmpty } from 'helpers/Functions';
import { BASE_URL } from 'helpers/Constants';
import HeaderWebView from 'components/HeaderWebView';

type Props = {
    navigation: any
    route: any
}
// ...
const DashboardDetail = ({route, navigation}: Props) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const {languages,languagesText } = useSelector((state: RootState) => state.languages);
    const {autoId } = useSelector((state: RootState) => state.dashboard);
    const [autoIdState, setAutoIdState] = useState(null)
    const {id} = route.params

    useEffect(() => {
      setAutoIdState(autoId)
    }, [autoId])

  return (
    <View style={{ flex: 1,backgroundColor: colors.white }}>
        <Header />
        <HeaderWebView title={'Quyền lợi hội viên'}/>
        {
          !checkIsEmpty(autoIdState) &&
          <WebView source={{ uri: `${BASE_URL}/psd/frontend/pages/VNADetailVB.aspx?rid=${id}&gid=1&cid=3&Mobile=1&autoid=${autoIdState}&lang=${languagesText.toLowerCase()}` }} style={{flex: 1, }}/>
        }
    </View>
  );
}

export default DashboardDetail

const styles = StyleSheet.create({})