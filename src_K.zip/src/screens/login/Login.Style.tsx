import {StyleSheet} from 'react-native';
import {FontFamily, FontSize, dimensWidth, windowHeight, windowWidth} from 'helpers/Constants';
import colors from 'helpers/Colors';

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  text: {
    fontSize: FontSize.MEDIUM,
  },
  bg_login: {
    flex: 1,
    alignItems: 'center',
    justifyContent:  'center',
    width: windowWidth,
    height: windowHeight,
    backgroundColor: '#fff',
    paddingTop: 40
  },
  logoPetrolimex: {
    marginBottom: 80,
    marginTop: 80,
    resizeMode: 'cover',
  },
  containerTextInput: {
    flexDirection: 'row',
    alignItems: 'center',
    height: dimensWidth(42),
    width: dimensWidth(345),
    backgroundColor: '#fff',
    borderColor: '#E5E5E5',
    paddingLeft: 18,
    borderRadius: 1,
    borderWidth:1,
    marginTop: 10,
    paddingRight: 10
  },
  userNameInput: {
    paddingHorizontal: 10,
    flex: 1,
  },
  textWarning: {
    marginHorizontal:80,
    fontSize: 16,
    marginVertical: 10,
    color: colors.red,
    fontFamily: FontFamily.HERITAGE_REGULAR,
    textAlign: 'center'
  },
  textHaveNoAccount: {
    fontSize: 16,
    marginVertical: 10,
    color: colors.text_grey26,
    fontFamily: FontFamily.HERITAGE_REGULAR,
  },
  vnaImage:{
    height:35,
    width:260,
    position:'absolute',
    left: 100
  },
  vnaBackgroundImage: {
    height:225,
    width:469,
    rotation: 8,
    translateX: 8
  }
});
export default styles;
