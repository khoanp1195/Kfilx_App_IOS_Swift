
import React, { useCallback, useEffect, useState } from 'react';
import { Dimensions, FlatList, StyleSheet, Animated, TouchableOpacity, View,TouchableWithoutFeedback } from 'react-native';
import { WebView } from 'react-native-webview';
import Header from 'components/Header'
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from 'redux-thunk';
import { getAutoLoginMobile } from 'stories/dashboard/reducer';
import { RootState } from 'stories/index';
import colors from 'helpers/Colors';
import { arrayIsEmpty, checkIsEmpty, format_dd_mm_yy, isNullOrUndefined } from 'helpers/Functions';
import { BASE_URL, FontSize, dimensWidth } from 'helpers/Constants';
import HeaderWebView from 'components/HeaderWebView';
import { getlistCategoryDocs } from 'stories/category/reducer';
import NoDataView from 'components/NoDataView';
import uuid from 'react-native-uuid';
import TextCusTom from 'components/TextCusTom';
import FastImageCustom from 'components/FastImageCustom';
import FastImage from 'react-native-fast-image';
import { WINDOW_WIDTH } from '@gorhom/bottom-sheet';
// import Animated from 'react-native-reanimated';

type Props = {
    navigation: any
    route: any
}

const CategorySnareItem = ({gotoDetail, item, index}: any) => {
    const formatDate = format_dd_mm_yy(item?.PublishDate)
    let imageObj = JSON.parse(item?.Image);
    const isOdd = index % 2
  return (
    <TouchableOpacity onPress={() =>gotoDetail(item)}>

    <View style={[styles.itemContainer,!isOdd && {marginRight: dimensWidth(0)}]}>
        <View style={styles.itemChildContainer}>
        <FastImageCustom urlOnline={imageObj?.Path} styleImg={styles.imgThumbnail}/>
        </View>
      <TextCusTom i18nKey={item?.Title} style={[styles.cap1,{width: dimensWidth(120)}]} numberOfLines={1}/>
      <TextCusTom i18nKey={item?.Description} style={[styles.cap2,{width: dimensWidth(120)}]} numberOfLines={2}/>
    </View>
    </TouchableOpacity>

  )
}
const CategoryNotSnareItem = ({gotoDetail, item, index}: any) => {
    const formatDate = format_dd_mm_yy(item?.IssueDate)
    let imageObj = JSON.parse(item?.Image);
    const isOdd = index % 2
  return (
    <View style={[styles.itemNotSnareContainer,!isOdd && {backgroundColor:colors.light_cyan}]}>
        <TouchableOpacity onPress={() =>gotoDetail(item)}>
        <FastImageCustom urlOnline={imageObj?.Path} styleImg={styles.imgThumbnailNotSnare}/>
        </TouchableOpacity>
     <View style={{flex: 1,}}>
     <View style={styles.rowBetween}>
     <TextCusTom i18nKey={item?.Title} style={styles.cap1} numberOfLines={1}/>
     </View>
     <View style={styles.rowBetween}>
     <TextCusTom i18nKey={item?.StorageCode} style={styles.contentNotSnare} numberOfLines={2}/>
     <TextCusTom i18nKey={formatDate} style={styles.cap2} numberOfLines={2}/>
     </View>
     </View>
    </View>
  )
}

const CategoryDetailScreen = ({route, navigation}: Props) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const {languages,languagesText } = useSelector((state: RootState) => state.languages);
    const {listCategoryDocs} = useSelector((state: RootState) => state.category);
    const [listCategoryDocsState, setlistCategoryDocsState] = useState([])
    const [isShowDrawview, setIsShowDrawview] = useState(false);
    const [isSnare, setIsSNare] = useState(true);
    const current = new Animated.Value(0);
    const [progress, setProgress] = useState(new Animated.Value(0));
    useEffect(() => {
        const langId = languagesText === 'EN' ? 1033 :1066
        const Offset = 0
     dispatch(getlistCategoryDocs({langId, Offset}))
    }, [languagesText])
    const gotoDetailPress = useCallback(
        (item: any) => {
          dispatch(getAutoLoginMobile());
          navigation.navigate({
            name: "DashboardDetailScreen",
            params: {id: item?.ID},
          });
        },
      [],
      )
      useEffect(() => {
        if(!isNullOrUndefined(listCategoryDocs.data)){
          setlistCategoryDocsState(listCategoryDocs.data);
          // alert(listCategoryDocs.data.length)
        }
      }, [listCategoryDocs])

    
      const handlePressDrawView = useCallback(
        () => {
          if(isShowDrawview){
            setIsShowDrawview(false)
          }else{
            setIsShowDrawview(true)
          }
          Animated.parallel([
            Animated.timing(current, {
                toValue:  0,
                duration:300,
                useNativeDriver:false,
            }),
        Animated.timing(progress, {
            toValue:1,
            duration:300,
            useNativeDriver:false
        })
        ]).start(()=>{
          isShowDrawview ? progress.setValue(0) : progress.setValue(1) 
        })

        },
        [isShowDrawview],
      )
      const handleCloseDrawView = useCallback(
        () => {
          setIsShowDrawview(false)
        },
        [],
      )
      

      const progressAnim=progress.interpolate({
        inputRange:[0, 1],
        outputRange:["0%", "80%"],
    });

    const drawWidth={
        width:progressAnim
    }
  return (
    <View style={{ flex: 1,backgroundColor: colors.white }}>
        <Header title={languages.tab_category}/>
        <HeaderWebView title={'Dịch vụ mặt đất / Check in'} onPressAvatar={handlePressDrawView} isSnare={isSnare} onNnareChange ={() => setIsSNare(!isSnare)}/>
       <View style={styles.container}>

{ isShowDrawview&&
   <View  style={styles.drawView}>
   <Animated.View style={[styles.aniamtedView, drawWidth]}>
    <NoDataView />
    </Animated.View>
    <TouchableWithoutFeedback style={styles.closeDrawView}  onPress={handleCloseDrawView}>
      <View style={styles.closeDrawView}/>
    </TouchableWithoutFeedback>
    </View>
}
<View>

{isSnare ?
  <FlatList
  key={'snare'}
contentContainerStyle={styles.containerFlatList}
data={listCategoryDocsState}
showsVerticalScrollIndicator={false}
extraData={listCategoryDocsState}
numColumns={2}
renderItem={({ item,index }) => (
<CategorySnareItem item={item} gotoDetail={gotoDetailPress} index={index}/>
)}
showsHorizontalScrollIndicator={false}
keyExtractor={(item: any, index) => uuid.v4().toString() }
/>
:
<FlatList
 key={'not_snare'}
data={listCategoryDocsState}
extraData={listCategoryDocsState}
showsVerticalScrollIndicator={false}
renderItem={({ item ,index}) => (
<CategoryNotSnareItem item={item} gotoDetail={gotoDetailPress} index={index}/>
)}
showsHorizontalScrollIndicator={false}
keyExtractor={(item: any, index) => uuid.v4().toString() }
/>
}
</View>
       </View>
    </View>
  );
}

export default CategoryDetailScreen

const styles = StyleSheet.create({
  container:{
    flex: 1,backgroundColor: colors.bg_app_color 
  },
    containerFlatList:{
    marginTop: 20,
    },
    itemContainer:{
        width: WINDOW_WIDTH / 2,
        marginBottom: 20,
        justifyContent: 'center',
        alignItems: 'center',
    },
    itemChildContainer:{
        width: dimensWidth(120),
        height:dimensWidth(120),
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: colors.light_cyan,
        borderRadius: 10
    },
    itemNotSnareContainer:{
        paddingStart: 20,
        paddingBottom: 10,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection:'row',
        backgroundColor: colors.white
    },
    rowBetween:{
      justifyContent: 'space-between',
      alignItems: 'center',
      flexDirection:'row'
    },
    imgThumbnail:{
        height: dimensWidth(74),
        width: dimensWidth(74),
        borderRadius: 3,
    },
    imgThumbnailNotSnare:{
        height: 32,
        width: 42,
        borderRadius: 3,
    },
    cap1:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey26,
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'left',
        paddingLeft:10,
        flex: 1,
    },
    cap2:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey_7b,
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'right',
        flex: 1,
        paddingRight: 10
    },
    contentNotSnare:{
        fontSize: FontSize.SMALL,
        color: colors.blue,
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'left',
        paddingLeft:10,
        flex: 1,
    },
    drawView: {
      flex: 1,
      zIndex: 999,
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.333333)',
      justifyContent: 'center',
      flexDirection:'row'
    },
    aniamtedView:{
      flex:4,
      backgroundColor: colors.white,
      zIndex: 9999,
    },
    closeDrawView:{
      flex: 1,
      zIndex: 99,
      backgroundColor:'transparent'
    }
})