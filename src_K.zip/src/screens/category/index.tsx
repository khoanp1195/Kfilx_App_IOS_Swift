
import React, { useCallback, useEffect, useState } from 'react';
import { FlatList, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { WebView } from 'react-native-webview';
import Header from 'components/Header'
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from 'redux-thunk';
import { getAutoLoginMobile } from 'stories/dashboard/reducer';
import { RootState } from 'stories/index';
import colors from 'helpers/Colors';
import { arrayIsEmpty, checkIsEmpty, format_dd_mm_yy, isNullOrUndefined } from 'helpers/Functions';
import { BASE_URL, FontSize } from 'helpers/Constants';
import { getlistCategoryDocs } from 'stories/category/reducer';
import NoDataView from 'components/NoDataView';
import uuid from 'react-native-uuid';
import TextCusTom from 'components/TextCusTom';
import FastImageCustom from 'components/FastImageCustom';
import FastImage from 'react-native-fast-image';

type Props = {
    navigation: any
    route: any
}

const DocumentViewItem = ({gotoDetail, item}: any) => {
    const formatDate = format_dd_mm_yy(item?.PublishDate)
    let imageObj = JSON.parse(item?.Image);
    
  return (
    <View style={styles.itemContainer}>
        <TouchableOpacity onPress={() =>gotoDetail(item)}>
        <FastImageCustom urlOnline={imageObj?.Path} styleImg={styles.imgThumbnail}/>
        </TouchableOpacity>
      <TextCusTom i18nKey={item?.Title} style={styles.cap1} numberOfLines={1}/>
      <TextCusTom i18nKey={item?.Description} style={styles.cap2} numberOfLines={2}/>
    </View>
  )
}

const CategoryScreen = ({route, navigation}: Props) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const {languages,languagesText } = useSelector((state: RootState) => state.languages);
    const {listCategoryDocs} = useSelector((state: RootState) => state.category);
    const [listCategoryDocsState, setlistCategoryDocsState] = useState([])

    useEffect(() => {
        const langId = languagesText === 'EN' ? 1033 :1066
        const Offset = 0
     dispatch(getlistCategoryDocs({langId, Offset}))
    }, [languagesText])
    const gotoDetailPress = useCallback(
      (item: any) => {
        dispatch(getAutoLoginMobile());
        navigation.navigate({
          name: "CategoryDetailScreen",
          params: {ID: item?.ID, data: listCategoryDocs.data},
        });
      },
    [listCategoryDocs],
    )
    useEffect(() => {
      if(!isNullOrUndefined(listCategoryDocs.data)){
        setlistCategoryDocsState(listCategoryDocs.data.filter(it => it.ParentId === 0));
        // alert(listCategoryDocs.data.length)
      }
    }, [listCategoryDocs])

  return (
    <View style={{ flex: 1,backgroundColor: colors.white }}>
        <Header title={languages.tab_category}/>
       <View style={styles.container}>
       {!arrayIsEmpty(listCategoryDocsState) ? (
<FlatList
contentContainerStyle={styles.containerFlatList}
data={listCategoryDocsState}
extraData={listCategoryDocsState}
numColumns={2}
renderItem={({ item }) => (
  <DocumentViewItem item={item} gotoDetail={gotoDetailPress} />
)}
showsHorizontalScrollIndicator={false}
keyExtractor={(item: any, index) => uuid.v4().toString() }
/>
) : (
<NoDataView />
)}
       </View>
    </View>
  );
}

export default CategoryScreen

const styles = StyleSheet.create({
  container:{
    flex: 1,backgroundColor: colors.bg_app_color 
  },
    containerFlatList:{
    marginTop: 20
    },
    itemContainer:{
        width: 160,
        marginLeft: 20,
        marginBottom: 20,
        justifyContent: 'center',
        alignItems: 'center'
    },
    imgThumbnail:{
        height: 120,
        width: 120,
        borderRadius: 3,
        backgroundColor: '#E2F9FF'
    },
    cap1:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey26,
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'center',
        paddingHorizontal: 10
    },
    cap2:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey_7b,
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'center',
        paddingHorizontal: 10
    }
})