import { useFocusEffect } from '@react-navigation/native';
import Header from 'components/Header';
import TextCusTom from 'components/TextCusTom';
import colors from 'helpers/Colors';
import { FontFamily, FontSize } from 'helpers/Constants';
import React, { useCallback, useState } from 'react';
import { View, Switch, StyleSheet, FlatList } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from 'stories/index';
import { getConfigNotification } from 'stories/settings/reducer';
const DATA = [
    {
        id: 'bd7acbea-c1b1',
        title: 'Văn bản đã theo dõi có thay đổi',
        isEnabledNoti: false,
        isEnabledEmail: false,
    },
    {
        id: '2323-asdsa-23',
        title: 'Văn bản đã thêm vào danh sách yêu thích có thay đổi',
        isEnabledNoti: false,
        isEnabledEmail: false,
    },
    {
        id: 'bd96-145571e23s9d72',
        title: 'Văn bản được chia sẻ',
        isEnabledNoti: false,
        isEnabledEmail: false,
    },
    {
        id: '123sdsds',
        title: 'Bộ lọc được chia sẻ',
        isEnabledNoti: false,
        isEnabledEmail: false,
    },
    {
        id: '58694a0f-3da5571e29d72',
        title: 'Bình luận được phản hồi',
        isEnabledNoti: false,
        isEnabledEmail: false,
    },
    {
        id: 'Văn bản đã thêm vào danh sách yêu thích có thay đổi',
        title: 'Bình luận được phê duyệt',
        isEnabledNoti: false,
        isEnabledEmail: false,
    },
    {
        id: '58694a6-145571e29d72',
        title: 'Tag bình luận',
        isEnabledNoti: false,
        isEnabledEmail: false,
    },
];
const SettingItem = ({ item, index, toggleSwitchNoti, toggleSwitchEmail }: any) => {
    const { title, id, isEnabledEmail, isEnabledNoti } = item;
    const isOdd = index % 2
    return (
        <View style={[styles.settingItem, { backgroundColor: isOdd ? colors.light_grayish : colors.white_blue }]}>
            <TextCusTom style={styles.itemTitle} i18nKey={title + title} numberOfLines={2} />
            <View style={styles.viewRight}>
                <View style={{ marginRight: 5, width: 70 }}>
                    <Switch
                        trackColor={{ false: colors.blue_switch_on, true: colors.blue_switch_on }}
                        thumbColor={colors.white}
                        onValueChange={() => toggleSwitchNoti(id)}
                        value={isEnabledNoti}
                    />
                </View>
                <View style={{ width: 70 }}>
                    <Switch
                        trackColor={{ false: colors.grey_da, true: colors.blue_switch_on }}
                        thumbColor={colors.white}
                        onValueChange={() => toggleSwitchEmail(id)}
                        value={isEnabledEmail}
                    />
                </View>
            </View>
        </View>
    )
};
const HeaderSetting = () => {

    return (
        <View style={styles.headerContainer}>
            <TextCusTom i18nKey={'Notifications'} style={styles.textHeader} />
            <TextCusTom i18nKey={'Email'} style={styles.textHeader} />
        </View>
    )
};
const App = () => {
    const {languages,languagesText } = useSelector((state: RootState) => state.languages);
    const [setingData, setSetingData] = useState(DATA);
    const dispatch = useDispatch<any>();

    useFocusEffect(
        React.useCallback(() => {
          const langId = languagesText === 'EN' ? 1033 :1066
          dispatch(getConfigNotification(langId));
        }, [languagesText])
      );

    const toggleSwitchNoti = useCallback((id: string) => {
        const data = setingData.map(it => {
            const newIt = it.id === id ? { ...it, isEnabledNoti: !it.isEnabledNoti } : it
            return newIt
        })
        setSetingData(data);
    },
        [setingData],
    )
    const toggleSwitchEmail = useCallback((id: string) => {
        const data = setingData.map(it => {
            const newIt = it.id === id ? { ...it, isEnabledEmail: !it.isEnabledEmail } : it
            return newIt
        })
        setSetingData(data);
    }, [setingData],
    )

    return (
        <View style={styles.container}>
            <Header title={languages.notification} />
            <HeaderSetting />
            <FlatList
                data={setingData}
                extraData={setingData}
                renderItem={({ item, index }) => (
                    <SettingItem
                        item={item} index={index}
                        toggleSwitchEmail={(id) => toggleSwitchEmail(id)}
                        toggleSwitchNoti={(id) => toggleSwitchNoti(id)} />
                )
                }

                keyExtractor={item => item.id}
            />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
    },
    settingItem: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        height: 70,
        paddingHorizontal: 15
    },
    viewLeft: {
    },
    viewRight: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    itemTitle: {
        flex: 1,
        color: colors.black_121,
        fontSize: FontSize.SMALL,
        fontWeight: '400',
        fontFamily: FontFamily.HERITAGE_REGULAR,
    },
    textHeader: {
        color: colors.black_121,
        fontSize: FontSize.SMALL,
        fontWeight: '400',
        fontFamily: FontFamily.HERITAGE_REGULAR,
        width: 70,
        textAlign: 'center'
    },
    headerContainer: {
        paddingTop: 10,
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
    }
});

export default App;